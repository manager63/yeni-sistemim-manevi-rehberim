import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/contexts/AuthContext";
import {
  Shield,
  Users,
  DollarSign,
  Settings,
  BarChart,
  FileText,
  Upload,
  Download,
  Edit,
  Trash2,
  Plus,
  Save,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Globe,
  Database,
  Image,
  Video,
  Mail,
  Bell,
} from "lucide-react";

const AdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect if not admin
  useEffect(() => {
    if (!user || !user.isAdmin) {
      navigate("/");
    }
  }, [user, navigate]);

  const [activeUsers, setActiveUsers] = useState(245);
  const [totalRevenue, setTotalRevenue] = useState(12450);
  const [monthlyGrowth, setMonthlyGrowth] = useState(18.5);

  // Mock data for demonstration
  const [users, setUsers] = useState([
    {
      id: "1",
      name: "Ahmet Yılmaz",
      email: "ahmet@example.com",
      level: 3,
      teamSize: 15,
      earnings: 450,
      isActive: true,
      joinDate: "2024-01-15",
    },
    {
      id: "2",
      name: "Fatma Özkan",
      email: "fatma@example.com",
      level: 2,
      teamSize: 8,
      earnings: 220,
      isActive: true,
      joinDate: "2024-02-01",
    },
    {
      id: "3",
      name: "Mehmet Kara",
      email: "mehmet@example.com",
      level: 1,
      teamSize: 3,
      earnings: 50,
      isActive: false,
      joinDate: "2024-03-10",
    },
  ]);

  const [products, setProducts] = useState([
    {
      id: "1",
      name: "Manevi Gelişim Rehberi",
      price: 29.99,
      stock: 100,
      category: "E-kitap",
      isActive: true,
    },
    {
      id: "2",
      name: "Zikir Meditasyon Seti",
      price: 49.99,
      stock: 50,
      category: "Audio",
      isActive: true,
    },
  ]);

  const [mlmSettings, setMlmSettings] = useState({
    sponsorCommission: 10,
    matchingBonus: 5,
    recommendationBonus: 15,
    salesCommission: 20,
    monthlyFee: 10,
    yearlyFee: 100,
    maxDepth: 7,
  });

  const [dailyContent, setDailyContent] = useState({
    quote: "Allah'a yakın olmak istiyorsan, insanlara yakın ol.",
    author: "Hz. Ali",
    prayer: "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا",
    prayerTranslation: "Allah'ım! Seninle sabahladık, seninle akşamladık",
  });

  const handleUserUpdate = (userId: string, updates: any) => {
    setUsers(
      users.map((user) =>
        user.id === userId ? { ...user, ...updates } : user,
      ),
    );
  };

  const handleUserDelete = (userId: string) => {
    setUsers(users.filter((user) => user.id !== userId));
  };

  const handleProductUpdate = (productId: string, updates: any) => {
    setProducts(
      products.map((product) =>
        product.id === productId ? { ...product, ...updates } : product,
      ),
    );
  };

  const handleContentUpdate = () => {
    // Simulate API call to update daily content
    console.log("Daily content updated:", dailyContent);
    alert("Günlük içerik başarıyla güncellendi!");
  };

  const handleSettingsUpdate = () => {
    // Simulate API call to update MLM settings
    console.log("MLM settings updated:", mlmSettings);
    alert("MLM ayarları başarıyla güncellendi!");
  };

  const dashboardStats = [
    {
      title: "Aktif Kullanıcılar",
      value: activeUsers.toLocaleString(),
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      change: "+12% bu ay",
    },
    {
      title: "Toplam Gelir",
      value: `$${totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: "+25% bu ay",
    },
    {
      title: "Büyüme Oranı",
      value: `%${monthlyGrowth}`,
      icon: TrendingUp,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      change: "Son 30 gün",
    },
    {
      title: "Sistem Durumu",
      value: "Çevrimiçi",
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: "99.9% uptime",
    },
  ];

  if (!user || !user.isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-spiritual-gradient rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Admin Kontrol Paneli
              </h1>
              <p className="text-gray-600">
                Sistem yönetimi ve kontrol merkezi
              </p>
            </div>
          </div>

          {/* Dashboard Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {dashboardStats.map((stat, index) => (
              <Card key={index} className="bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-full ${stat.bgColor}`}>
                      <stat.icon className={`w-6 h-6 ${stat.color}`} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">{stat.title}</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {stat.value}
                      </p>
                      <p className="text-xs text-gray-500">{stat.change}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="users">Kullanıcılar</TabsTrigger>
            <TabsTrigger value="content">İçerik</TabsTrigger>
            <TabsTrigger value="products">Ürünler</TabsTrigger>
            <TabsTrigger value="mlm">MLM Ayarları</TabsTrigger>
            <TabsTrigger value="media">Medya</TabsTrigger>
            <TabsTrigger value="system">Sistem</TabsTrigger>
          </TabsList>

          {/* Users Management */}
          <TabsContent value="users" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span>Kullanıcı Yönetimi</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      <Input placeholder="Kullanıcı ara..." className="w-64" />
                      <Button variant="outline">
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Yenile
                      </Button>
                    </div>
                    <Button className="bg-spiritual-gradient text-white">
                      <Plus className="w-4 h-4 mr-2" />
                      Yeni Kullanıcı
                    </Button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left p-2">Kullanıcı</th>
                          <th className="text-left p-2">Seviye</th>
                          <th className="text-left p-2">Ekip</th>
                          <th className="text-left p-2">Kazanç</th>
                          <th className="text-left p-2">Durum</th>
                          <th className="text-left p-2">İşlemler</th>
                        </tr>
                      </thead>
                      <tbody>
                        {users.map((user) => (
                          <tr
                            key={user.id}
                            className="border-b border-gray-100"
                          >
                            <td className="p-2">
                              <div>
                                <div className="font-medium">{user.name}</div>
                                <div className="text-xs text-gray-500">
                                  {user.email}
                                </div>
                              </div>
                            </td>
                            <td className="p-2">
                              <Badge
                                variant={
                                  user.level > 3 ? "default" : "secondary"
                                }
                              >
                                Seviye {user.level}
                              </Badge>
                            </td>
                            <td className="p-2">{user.teamSize} kişi</td>
                            <td className="p-2">${user.earnings}</td>
                            <td className="p-2">
                              <Badge
                                variant={
                                  user.isActive ? "default" : "destructive"
                                }
                              >
                                {user.isActive ? "Aktif" : "Pasif"}
                              </Badge>
                            </td>
                            <td className="p-2">
                              <div className="flex space-x-1">
                                <Button size="sm" variant="outline">
                                  <Edit className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleUserDelete(user.id)}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Management */}
          <TabsContent value="content" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-6 h-6 text-spiritual-purple-600" />
                  <span>Günlük İçerik Yönetimi</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="daily-quote">Günün Sözü</Label>
                      <Textarea
                        id="daily-quote"
                        value={dailyContent.quote}
                        onChange={(e) =>
                          setDailyContent({
                            ...dailyContent,
                            quote: e.target.value,
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="quote-author">Yazar</Label>
                      <Input
                        id="quote-author"
                        value={dailyContent.author}
                        onChange={(e) =>
                          setDailyContent({
                            ...dailyContent,
                            author: e.target.value,
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="daily-prayer">Günün Duası (Arapça)</Label>
                      <Textarea
                        id="daily-prayer"
                        value={dailyContent.prayer}
                        onChange={(e) =>
                          setDailyContent({
                            ...dailyContent,
                            prayer: e.target.value,
                          })
                        }
                        className="mt-1 arabic-text"
                      />
                    </div>
                    <div>
                      <Label htmlFor="prayer-translation">Türkçe Çeviri</Label>
                      <Textarea
                        id="prayer-translation"
                        value={dailyContent.prayerTranslation}
                        onChange={(e) =>
                          setDailyContent({
                            ...dailyContent,
                            prayerTranslation: e.target.value,
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>
                <Button
                  onClick={handleContentUpdate}
                  className="bg-spiritual-gradient text-white"
                >
                  <Save className="w-4 h-4 mr-2" />
                  İçeriği Güncelle
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Otomatik İçerik Güncelleme</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Günlük Otomatik Güncelleme</Label>
                    <p className="text-sm text-gray-600">
                      İçerik her gün otomatik olarak güncellensin
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Haftalık Burç Yorumları</Label>
                    <p className="text-sm text-gray-600">
                      Burç yorumları haftalık güncellensin
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <Button variant="outline" className="w-full">
                  <Globe className="w-4 h-4 mr-2" />
                  İnternetten İçerik Çek
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Management */}
          <TabsContent value="products" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="w-6 h-6 text-spiritual-gold-600" />
                  <span>Ürün Yönetimi</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      <Input placeholder="Ürün ara..." className="w-64" />
                      <Button variant="outline">
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Yenile
                      </Button>
                    </div>
                    <Button className="bg-spiritual-gradient text-white">
                      <Plus className="w-4 h-4 mr-2" />
                      Yeni Ürün
                    </Button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left p-2">Ürün</th>
                          <th className="text-left p-2">Kategori</th>
                          <th className="text-left p-2">Fiyat</th>
                          <th className="text-left p-2">Stok</th>
                          <th className="text-left p-2">Durum</th>
                          <th className="text-left p-2">İşlemler</th>
                        </tr>
                      </thead>
                      <tbody>
                        {products.map((product) => (
                          <tr
                            key={product.id}
                            className="border-b border-gray-100"
                          >
                            <td className="p-2">
                              <div className="font-medium">{product.name}</div>
                            </td>
                            <td className="p-2">{product.category}</td>
                            <td className="p-2">${product.price}</td>
                            <td className="p-2">{product.stock}</td>
                            <td className="p-2">
                              <Badge
                                variant={
                                  product.isActive ? "default" : "secondary"
                                }
                              >
                                {product.isActive ? "Aktif" : "Pasif"}
                              </Badge>
                            </td>
                            <td className="p-2">
                              <div className="flex space-x-1">
                                <Button size="sm" variant="outline">
                                  <Edit className="w-3 h-3" />
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* MLM Settings */}
          <TabsContent value="mlm" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span>MLM Sistem Ayarları</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-gray-900">
                      Komisyon Oranları (%)
                    </h3>
                    <div>
                      <Label htmlFor="sponsor-commission">
                        Sponsor Komisyonu
                      </Label>
                      <Input
                        id="sponsor-commission"
                        type="number"
                        value={mlmSettings.sponsorCommission}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            sponsorCommission: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="matching-bonus">Eşleşme Bonusu</Label>
                      <Input
                        id="matching-bonus"
                        type="number"
                        value={mlmSettings.matchingBonus}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            matchingBonus: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="recommendation-bonus">
                        Tavsiye Bonusu
                      </Label>
                      <Input
                        id="recommendation-bonus"
                        type="number"
                        value={mlmSettings.recommendationBonus}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            recommendationBonus: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="sales-commission">Satış Komisyonu</Label>
                      <Input
                        id="sales-commission"
                        type="number"
                        value={mlmSettings.salesCommission}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            salesCommission: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="font-semibold text-gray-900">
                      Sistem Ayarları
                    </h3>
                    <div>
                      <Label htmlFor="monthly-fee">Aylık Üyelik ($)</Label>
                      <Input
                        id="monthly-fee"
                        type="number"
                        value={mlmSettings.monthlyFee}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            monthlyFee: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="yearly-fee">Yıllık Üyelik ($)</Label>
                      <Input
                        id="yearly-fee"
                        type="number"
                        value={mlmSettings.yearlyFee}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            yearlyFee: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="max-depth">Maksimum Derinlik</Label>
                      <Input
                        id="max-depth"
                        type="number"
                        value={mlmSettings.maxDepth}
                        onChange={(e) =>
                          setMlmSettings({
                            ...mlmSettings,
                            maxDepth: parseInt(e.target.value),
                          })
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>
                </div>
                <Button
                  onClick={handleSettingsUpdate}
                  className="bg-spiritual-gradient text-white"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Ayarları Kaydet
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Media Management */}
          <TabsContent value="media" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Image className="w-6 h-6 text-spiritual-purple-600" />
                    <span>Galeri Yönetimi</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full bg-spiritual-gradient text-white">
                    <Upload className="w-4 h-4 mr-2" />
                    Resim Yükle
                  </Button>
                  <div className="grid grid-cols-3 gap-2">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <div
                        key={i}
                        className="aspect-square bg-gray-200 rounded-lg flex items-center justify-center"
                      >
                        <Image className="w-6 h-6 text-gray-400" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Video className="w-6 h-6 text-spiritual-gold-600" />
                    <span>Video Yönetimi</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full bg-spiritual-gradient text-white">
                    <Upload className="w-4 h-4 mr-2" />
                    Video Yükle
                  </Button>
                  <div className="space-y-2">
                    <div className="p-3 border border-gray-200 rounded-lg flex items-center justify-between">
                      <span className="text-sm">Meditasyon Rehberi.mp4</span>
                      <Button size="sm" variant="outline">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="p-3 border border-gray-200 rounded-lg flex items-center justify-between">
                      <span className="text-sm">MLM Eğitimi.mp4</span>
                      <Button size="sm" variant="outline">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* System Management */}
          <TabsContent value="system" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Database className="w-6 h-6 text-spiritual-turquoise-600" />
                    <span>Sistem Durumu</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Veritabanı</span>
                    <Badge className="bg-green-100 text-green-800">
                      Çalışıyor
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>MLM Sistemi</span>
                    <Badge className="bg-green-100 text-green-800">
                      Çalışıyor
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Ödeme Sistemi</span>
                    <Badge className="bg-green-100 text-green-800">
                      Çalışıyor
                    </Badge>
                  </div>
                  <Button variant="outline" className="w-full">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Sistemi Yeniden Başlat
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Download className="w-6 h-6 text-spiritual-purple-600" />
                    <span>Yedekleme</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full bg-spiritual-gradient text-white">
                    <Download className="w-4 h-4 mr-2" />
                    Veritabanı Yedeği Al
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Upload className="w-4 h-4 mr-2" />
                    Yedekten Geri Yükle
                  </Button>
                  <div className="text-sm text-gray-600">
                    Son yedek: {new Date().toLocaleDateString("tr-TR")}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Bell className="w-6 h-6 text-spiritual-gold-600" />
                  <span>Sistem Bildirimleri</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium text-green-800">
                        Sistem normal çalışıyor
                      </span>
                    </div>
                    <p className="text-xs text-green-600 mt-1">
                      Tüm servisler çevrimiçi
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-800">
                        Yeni güncelleme mevcut
                      </span>
                    </div>
                    <p className="text-xs text-blue-600 mt-1">
                      Sistem güncellemesi için hazır
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminPanel;
