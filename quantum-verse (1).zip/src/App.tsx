import React from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  useParams,
  useNavigate,
} from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import Navigation from "./components/Navigation";
import { Toaster } from "@/components/ui/toaster";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

// Pages
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import EnhancedUserDashboard from "./pages/EnhancedUserDashboard";
import UpdatedUserDashboard from "./pages/UpdatedUserDashboard";
import LifeCoaching from "./pages/LifeCoaching";
import MeditationDhikr from "./pages/MeditationDhikr";
import PrayerIntention from "./pages/PrayerIntention";
import SpiritualGuidance from "./pages/SpiritualGuidance";
import SpiritualProducts from "./pages/SpiritualProducts";
import NetworkMLM from "./pages/NetworkMLM";
import AdminPanel from "./pages/AdminPanel";
import EnhancedAdminPanel from "./pages/EnhancedAdminPanel";
import SuperAdminPanel from "./pages/SuperAdminPanel";
import SuperAdminDashboard from "./pages/SuperAdminDashboard";
import ComprehensiveAdminPanel from "./pages/ComprehensiveAdminPanel";
import UltimateAdminPanel from "./pages/UltimateAdminPanel";
import EnhancedClonePage from "./pages/EnhancedClonePage";
import NotFound from "./pages/NotFound";

// Clone page component
const ClonePage = () => {
  const { referralCode } = useParams();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-4xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Manevi Rehberim Network
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Ruhsal gelişim yolculuğuna katılın ve hem kendinizi geliştirin hem
            de gelir elde edin
          </p>
          <div className="bg-spiritual-gold-50 border border-spiritual-gold-200 rounded-lg p-4 mb-8">
            <p className="text-spiritual-gold-700 font-medium">
              {referralCode
                ? `Referans Kodu: ${referralCode}`
                : "Özel davet ile katılıyorsunuz"}
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Network Sistemi</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>• 7 seviyeli nefs mertebeleri</li>
                <li>• Binary MLM sistemi</li>
                <li>• Komisyon kazanma</li>
                <li>• Ekip oluşturma</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Manevi Gelişim</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li>• Günlük dua ve zikir</li>
                <li>• Yaşam koçluğu</li>
                <li>• Meditasyon rehberi</li>
                <li>• Kişisel gelişim</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <Button
            onClick={() =>
              navigate(
                `/kayıt${referralCode ? `?sponsor=${referralCode}` : ""}`,
              )
            }
            className="bg-spiritual-gradient text-white px-8 py-3 text-lg"
          >
            Hemen Katıl - Sadece $10/ay
          </Button>
        </div>
      </div>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-peaceful-gradient">
          <Navigation />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/giriş" element={<Login />} />
            <Route path="/kayıt" element={<Register />} />
            <Route
              path="/kullanıcı-paneli"
              element={<UpdatedUserDashboard />}
            />
            <Route path="/yaşam-koçluğu" element={<LifeCoaching />} />
            <Route path="/meditasyon" element={<MeditationDhikr />} />
            <Route path="/dua" element={<PrayerIntention />} />
            <Route path="/burç" element={<SpiritualGuidance />} />
            <Route path="/ürünler" element={<SpiritualProducts />} />
            <Route path="/network" element={<NetworkMLM />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/enhanced-admin" element={<EnhancedAdminPanel />} />
            <Route
              path="/super-admin-dashboard"
              element={<SuperAdminDashboard />}
            />
            <Route
              path="/comprehensive-admin"
              element={<ComprehensiveAdminPanel />}
            />
            <Route path="/ultimate-admin" element={<UltimateAdminPanel />} />
            <Route path="/kazançlar" element={<EnhancedUserDashboard />} />
            <Route
              path="/clone/:referralCode"
              element={<EnhancedClonePage />}
            />
            <Route path="/super-admin" element={<SuperAdminPanel />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <Toaster />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
