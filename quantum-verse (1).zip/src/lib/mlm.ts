// MLM Network Marketing System

export interface NetworkMember {
  id: string;
  name: string;
  email: string;
  sponsorId?: string;
  referralCode: string;
  level: number;
  joinDate: Date;
  isActive: boolean;
  subscriptionType: "monthly" | "yearly" | null;
  personalSales: number;
  teamSales: number;
  totalEarnings: number;
  leftLeg: NetworkMember[];
  rightLeg: NetworkMember[];
  children: NetworkMember[];
}

export interface Commission {
  id: string;
  userId: string;
  type: "sponsor" | "matching" | "recommendation" | "sales";
  amount: number;
  source: string;
  date: Date;
  level: number;
}

export interface MLMSettings {
  sponsorCommission: number; // %
  matchingBonus: number; // %
  recommendationBonus: number; // %
  salesCommission: number; // %
  monthlySubscription: number; // $
  yearlySubscription: number; // $
  maxDepth: number;
}

export const DEFAULT_MLM_SETTINGS: MLMSettings = {
  sponsorCommission: 10,
  matchingBonus: 5,
  recommendationBonus: 15,
  salesCommission: 20,
  monthlySubscription: 10,
  yearlySubscription: 100,
  maxDepth: 7,
};

export class MLMSystem {
  private members: Map<string, NetworkMember> = new Map();
  private commissions: Commission[] = [];
  private settings: MLMSettings;

  constructor(settings: MLMSettings = DEFAULT_MLM_SETTINGS) {
    this.settings = settings;
  }

  addMember(
    member: Omit<NetworkMember, "leftLeg" | "rightLeg" | "children">,
  ): NetworkMember {
    const newMember: NetworkMember = {
      ...member,
      leftLeg: [],
      rightLeg: [],
      children: [],
    };

    this.members.set(member.id, newMember);

    // Add to sponsor's network
    if (member.sponsorId) {
      const sponsor = this.members.get(member.sponsorId);
      if (sponsor) {
        sponsor.children.push(newMember);

        // Binary placement (left/right leg)
        if (sponsor.leftLeg.length <= sponsor.rightLeg.length) {
          sponsor.leftLeg.push(newMember);
        } else {
          sponsor.rightLeg.push(newMember);
        }
      }
    }

    return newMember;
  }

  calculateCommission(
    memberId: string,
    amount: number,
    type: Commission["type"],
  ): number {
    const member = this.members.get(memberId);
    if (!member || !member.isActive) return 0;

    let commissionRate = 0;
    switch (type) {
      case "sponsor":
        commissionRate = this.settings.sponsorCommission;
        break;
      case "matching":
        commissionRate = this.settings.matchingBonus;
        break;
      case "recommendation":
        commissionRate = this.settings.recommendationBonus;
        break;
      case "sales":
        commissionRate = this.settings.salesCommission;
        break;
    }

    return (amount * commissionRate) / 100;
  }

  processPayment(memberId: string, amount: number): void {
    const member = this.members.get(memberId);
    if (!member) return;

    // Sales commission to member
    const salesCommission = this.calculateCommission(memberId, amount, "sales");
    this.addCommission(memberId, "sales", salesCommission, "Product Sale", 0);

    // Sponsor commissions up the tree
    this.processSponsorCommissions(memberId, amount);
  }

  private processSponsorCommissions(memberId: string, amount: number): void {
    const member = this.members.get(memberId);
    if (!member || !member.sponsorId) return;

    let currentSponsorId = member.sponsorId;
    let level = 1;

    while (currentSponsorId && level <= this.settings.maxDepth) {
      const sponsor = this.members.get(currentSponsorId);
      if (sponsor && sponsor.isActive) {
        const commission = this.calculateCommission(
          currentSponsorId,
          amount,
          "sponsor",
        );
        const adjustedCommission = commission * (1 - (level - 1) * 0.1); // Reduce by 10% each level

        this.addCommission(
          currentSponsorId,
          "sponsor",
          adjustedCommission,
          `Level ${level} Sale`,
          level,
        );

        currentSponsorId = sponsor.sponsorId;
        level++;
      } else {
        break;
      }
    }
  }

  private addCommission(
    userId: string,
    type: Commission["type"],
    amount: number,
    source: string,
    level: number,
  ): void {
    const commission: Commission = {
      id: Date.now().toString() + Math.random(),
      userId,
      type,
      amount,
      source,
      date: new Date(),
      level,
    };

    this.commissions.push(commission);

    // Update member's total earnings
    const member = this.members.get(userId);
    if (member) {
      member.totalEarnings += amount;
    }
  }

  getNetworkTree(rootId: string): NetworkMember | null {
    return this.members.get(rootId) || null;
  }

  getMemberCommissions(memberId: string): Commission[] {
    return this.commissions.filter((c) => c.userId === memberId);
  }

  getTeamSize(memberId: string): number {
    const member = this.members.get(memberId);
    if (!member) return 0;

    let teamSize = 0;
    const countTeam = (m: NetworkMember) => {
      teamSize += m.children.length;
      m.children.forEach((child) => countTeam(child));
    };

    countTeam(member);
    return teamSize;
  }

  updateMemberLevel(memberId: string): void {
    const member = this.members.get(memberId);
    if (!member) return;

    const teamSize = this.getTeamSize(memberId);
    const totalSales = member.personalSales + member.teamSales;

    // Level advancement logic based on team size and sales
    if (teamSize >= 250 && totalSales >= 50000) {
      member.level = 7; // Nefs-i Kâmile
    } else if (teamSize >= 100 && totalSales >= 25000) {
      member.level = 6; // Nefs-i Mardiyye
    } else if (teamSize >= 50 && totalSales >= 12500) {
      member.level = 5; // Nefs-i Râziye
    } else if (teamSize >= 25 && totalSales >= 6000) {
      member.level = 4; // Nefs-i Mutmainne
    } else if (teamSize >= 10 && totalSales >= 3000) {
      member.level = 3; // Nefs-i Mülhime
    } else if (teamSize >= 3 && totalSales >= 1000) {
      member.level = 2; // Nefs-i Levvame
    } else {
      member.level = 1; // Nefs-i Emmare
    }
  }

  generateReferralLink(memberId: string): string {
    const member = this.members.get(memberId);
    if (!member) return "";

    return `${window.location.origin}/register?sponsor=${member.referralCode}`;
  }

  getWeakestUpline(): string | null {
    // Find member with smallest team for spillover placement
    let weakestMember: NetworkMember | null = null;
    let smallestTeam = Infinity;

    this.members.forEach((member) => {
      if (member.isActive) {
        const teamSize = this.getTeamSize(member.id);
        if (teamSize < smallestTeam) {
          smallestTeam = teamSize;
          weakestMember = member;
        }
      }
    });

    return weakestMember?.id || null;
  }
}

// Global MLM instance
export const mlmSystem = new MLMSystem();
