import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import {
  Crown,
  Users,
  Mail,
  MessageSquare,
  Bell,
  Settings,
  Plus,
  Edit,
  Trash2,
  Send,
  Eye,
  Save,
  Download,
  Upload,
  BarChart,
  TrendingUp,
  DollarSign,
  Shield,
  CheckCircle,
  AlertCircle,
  Calendar,
  Clock,
  Filter,
  Search,
  RefreshCw,
  FileText,
  Image,
  Video,
  Phone,
  Smartphone,
  Globe,
  Target,
  Star,
  Gift,
  Package,
  CreditCard,
  Database,
  Lock,
  Key,
} from "lucide-react";

interface User {
  id: number;
  name: string;
  email: string;
  phone?: string;
  subscriptionActive: boolean;
  subscriptionType: "monthly" | "yearly" | "free";
  registrationDate: string;
  lastLogin: string;
  totalEarnings: number;
  teamSize: number;
  nefsLevel: number;
  isAdmin: boolean;
  status: "active" | "inactive" | "suspended";
}

interface NewsItem {
  id: number;
  title: string;
  content: string;
  type: "announcement" | "update" | "promotion" | "warning";
  priority: "low" | "medium" | "high" | "urgent";
  targetUsers: "all" | "members" | "admins" | "specific";
  isActive: boolean;
  createdAt: string;
  expiresAt?: string;
  views: number;
  author: string;
}

interface Message {
  id: number;
  title: string;
  content: string;
  type: "email" | "sms" | "notification";
  recipients: string[];
  status: "draft" | "sent" | "scheduled";
  sentAt?: string;
  scheduledFor?: string;
  deliveryCount: number;
  openCount: number;
  clickCount: number;
}

const SuperAdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect if not admin
  useEffect(() => {
    if (!user || !user.isAdmin) {
      navigate("/");
    }
  }, [user, navigate]);

  // State management
  const [users, setUsers] = useState<User[]>([
    {
      id: 1,
      name: "Ahmet Yılmaz",
      email: "ahmet@email.com",
      phone: "+90 532 123 4567",
      subscriptionActive: true,
      subscriptionType: "monthly",
      registrationDate: "2024-01-15",
      lastLogin: "2024-01-20",
      totalEarnings: 1250,
      teamSize: 15,
      nefsLevel: 3,
      isAdmin: false,
      status: "active",
    },
    {
      id: 2,
      name: "Fatma Demir",
      email: "fatma@email.com",
      phone: "+90 534 567 8901",
      subscriptionActive: true,
      subscriptionType: "yearly",
      registrationDate: "2024-01-10",
      lastLogin: "2024-01-19",
      totalEarnings: 2100,
      teamSize: 28,
      nefsLevel: 4,
      isAdmin: false,
      status: "active",
    },
    {
      id: 3,
      name: "Mehmet Kaya",
      email: "mehmet@email.com",
      subscriptionActive: false,
      subscriptionType: "free",
      registrationDate: "2024-01-18",
      lastLogin: "2024-01-18",
      totalEarnings: 0,
      teamSize: 0,
      nefsLevel: 1,
      isAdmin: false,
      status: "inactive",
    },
  ]);

  const [newsItems, setNewsItems] = useState<NewsItem[]>([
    {
      id: 1,
      title: "Platform Güncellemesi",
      content:
        "Yeni özellikler eklendi. Artık daha kolay MLM yönetimi yapabilirsiniz.",
      type: "update",
      priority: "medium",
      targetUsers: "all",
      isActive: true,
      createdAt: "2024-01-20",
      views: 0,
      author: "Admin",
    },
    {
      id: 2,
      title: "Özel İndirim Kampanyası",
      content: "Bu ay %50 indirimli yıllık üyelik fırsatı!",
      type: "promotion",
      priority: "high",
      targetUsers: "members",
      isActive: true,
      createdAt: "2024-01-19",
      expiresAt: "2024-02-01",
      views: 0,
      author: "Admin",
    },
  ]);

  const [messages, setMessages] = useState<Message[]>([]);

  // Form states
  const [newNews, setNewNews] = useState({
    title: "",
    content: "",
    type: "announcement" as NewsItem["type"],
    priority: "medium" as NewsItem["priority"],
    targetUsers: "all" as NewsItem["targetUsers"],
    expiresAt: "",
  });

  const [newMessage, setNewMessage] = useState({
    title: "",
    content: "",
    type: "email" as Message["type"],
    recipients: "all",
    scheduledFor: "",
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [userFilter, setUserFilter] = useState("all");

  // Statistics
  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter((u) => u.subscriptionActive).length,
    totalRevenue: users.reduce((sum, u) => sum + u.totalEarnings, 0),
    totalNews: newsItems.length,
    activeNews: newsItems.filter((n) => n.isActive).length,
    totalMessages: messages.length,
  };

  // News Management Functions
  const addNews = () => {
    if (newNews.title && newNews.content) {
      const newsItem: NewsItem = {
        id: Date.now(),
        title: newNews.title,
        content: newNews.content,
        type: newNews.type,
        priority: newNews.priority,
        targetUsers: newNews.targetUsers,
        isActive: true,
        createdAt: new Date().toISOString().split("T")[0],
        expiresAt: newNews.expiresAt || undefined,
        views: 0,
        author: user?.name || "Admin",
      };
      setNewsItems([newsItem, ...newsItems]);
      setNewNews({
        title: "",
        content: "",
        type: "announcement",
        priority: "medium",
        targetUsers: "all",
        expiresAt: "",
      });
    }
  };

  const toggleNewsStatus = (newsId: number) => {
    setNewsItems(
      newsItems.map((item) =>
        item.id === newsId ? { ...item, isActive: !item.isActive } : item,
      ),
    );
  };

  const deleteNews = (newsId: number) => {
    setNewsItems(newsItems.filter((item) => item.id !== newsId));
  };

  // Message Functions
  const sendMessage = () => {
    if (newMessage.title && newMessage.content) {
      const message: Message = {
        id: Date.now(),
        title: newMessage.title,
        content: newMessage.content,
        type: newMessage.type,
        recipients:
          newMessage.recipients === "all" ? ["all"] : [newMessage.recipients],
        status: newMessage.scheduledFor ? "scheduled" : "sent",
        sentAt: newMessage.scheduledFor ? undefined : new Date().toISOString(),
        scheduledFor: newMessage.scheduledFor || undefined,
        deliveryCount: newMessage.recipients === "all" ? stats.totalUsers : 1,
        openCount: 0,
        clickCount: 0,
      };
      setMessages([message, ...messages]);
      setNewMessage({
        title: "",
        content: "",
        type: "email",
        recipients: "all",
        scheduledFor: "",
      });
    }
  };

  // User Management Functions
  const updateUserStatus = (userId: number, status: User["status"]) => {
    setUsers(
      users.map((user) => (user.id === userId ? { ...user, status } : user)),
    );
  };

  const updateUserSubscription = (
    userId: number,
    subscriptionType: User["subscriptionType"],
  ) => {
    setUsers(
      users.map((user) =>
        user.id === userId
          ? {
              ...user,
              subscriptionType,
              subscriptionActive: subscriptionType !== "free",
            }
          : user,
      ),
    );
  };

  const deleteUser = (userId: number) => {
    setUsers(users.filter((user) => user.id !== userId));
  };

  // Filter functions
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter =
      userFilter === "all" ||
      (userFilter === "active" && user.subscriptionActive) ||
      (userFilter === "inactive" && !user.subscriptionActive) ||
      (userFilter === "admin" && user.isAdmin);
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            <Crown className="w-8 h-8 inline-block mr-2" />
            Süper Admin Yönetici Paneli
          </h1>
          <p className="text-gray-600">
            Sistem yönetimi, haber bülteni ve toplu mesajlaşma
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
          <Card className="text-center">
            <CardContent className="p-4">
              <Users className="w-6 h-6 mx-auto mb-2 text-spiritual-turquoise-600" />
              <div className="text-xl font-bold text-spiritual-turquoise-600">
                {stats.totalUsers}
              </div>
              <div className="text-xs text-gray-600">Toplam Üye</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <CheckCircle className="w-6 h-6 mx-auto mb-2 text-green-600" />
              <div className="text-xl font-bold text-green-600">
                {stats.activeUsers}
              </div>
              <div className="text-xs text-gray-600">Aktif Üye</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <DollarSign className="w-6 h-6 mx-auto mb-2 text-spiritual-gold-600" />
              <div className="text-xl font-bold text-spiritual-gold-600">
                ${stats.totalRevenue}
              </div>
              <div className="text-xs text-gray-600">Toplam Gelir</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <Bell className="w-6 h-6 mx-auto mb-2 text-spiritual-purple-600" />
              <div className="text-xl font-bold text-spiritual-purple-600">
                {stats.activeNews}
              </div>
              <div className="text-xs text-gray-600">Aktif Haber</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <Mail className="w-6 h-6 mx-auto mb-2 text-blue-600" />
              <div className="text-xl font-bold text-blue-600">
                {stats.totalMessages}
              </div>
              <div className="text-xs text-gray-600">Gönderilen Mesaj</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <TrendingUp className="w-6 h-6 mx-auto mb-2 text-indigo-600" />
              <div className="text-xl font-bold text-indigo-600">
                {Math.round((stats.activeUsers / stats.totalUsers) * 100)}%
              </div>
              <div className="text-xs text-gray-600">Aktivite Oranı</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="news" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-white/80">
            <TabsTrigger value="news" className="flex items-center space-x-2">
              <Bell className="w-4 h-4" />
              <span>Haber Bülteni</span>
            </TabsTrigger>
            <TabsTrigger
              value="messaging"
              className="flex items-center space-x-2"
            >
              <Mail className="w-4 h-4" />
              <span>Toplu Mesajlaşma</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Kullanıcı Yönetimi</span>
            </TabsTrigger>
            <TabsTrigger value="mlm" className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4" />
              <span>MLM Network</span>
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="flex items-center space-x-2"
            >
              <BarChart className="w-4 h-4" />
              <span>Analitik</span>
            </TabsTrigger>
          </TabsList>

          {/* News Management */}
          <TabsContent value="news" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Add New News */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="w-5 h-5 mr-2" />
                    Yeni Haber Ekle
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="newsTitle">Başlık</Label>
                    <Input
                      id="newsTitle"
                      value={newNews.title}
                      onChange={(e) =>
                        setNewNews({ ...newNews, title: e.target.value })
                      }
                      placeholder="Haber başlığı..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="newsContent">İçerik</Label>
                    <Textarea
                      id="newsContent"
                      rows={4}
                      value={newNews.content}
                      onChange={(e) =>
                        setNewNews({ ...newNews, content: e.target.value })
                      }
                      placeholder="Haber içeriği..."
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="newsType">Tür</Label>
                      <Select
                        value={newNews.type}
                        onValueChange={(value: any) =>
                          setNewNews({ ...newNews, type: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="announcement">Duyuru</SelectItem>
                          <SelectItem value="update">Güncelleme</SelectItem>
                          <SelectItem value="promotion">Kampanya</SelectItem>
                          <SelectItem value="warning">Uyarı</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="newsPriority">Öncelik</Label>
                      <Select
                        value={newNews.priority}
                        onValueChange={(value: any) =>
                          setNewNews({ ...newNews, priority: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Düşük</SelectItem>
                          <SelectItem value="medium">Orta</SelectItem>
                          <SelectItem value="high">Yüksek</SelectItem>
                          <SelectItem value="urgent">Acil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="newsTarget">Hedef Kitle</Label>
                      <Select
                        value={newNews.targetUsers}
                        onValueChange={(value: any) =>
                          setNewNews({ ...newNews, targetUsers: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Tüm Kullanıcılar</SelectItem>
                          <SelectItem value="members">Sadece Üyeler</SelectItem>
                          <SelectItem value="admins">
                            Sadece Adminler
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="newsExpires">
                        Son Geçerlilik (Opsiyonel)
                      </Label>
                      <Input
                        id="newsExpires"
                        type="date"
                        value={newNews.expiresAt}
                        onChange={(e) =>
                          setNewNews({ ...newNews, expiresAt: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <Button
                    onClick={addNews}
                    className="w-full bg-spiritual-gradient text-white"
                  >
                    <Bell className="w-4 h-4 mr-2" />
                    Haberi Yayınla
                  </Button>
                </CardContent>
              </Card>

              {/* News List */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    Yayınlanan Haberler
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {newsItems.map((news) => (
                      <div
                        key={news.id}
                        className={`p-4 border rounded-lg ${
                          news.isActive
                            ? "border-green-200 bg-green-50"
                            : "border-gray-200 bg-gray-50"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold">{news.title}</h4>
                          <div className="flex items-center space-x-2">
                            <Badge
                              variant={
                                news.priority === "urgent"
                                  ? "destructive"
                                  : news.priority === "high"
                                    ? "default"
                                    : "outline"
                              }
                            >
                              {news.priority === "urgent"
                                ? "Acil"
                                : news.priority === "high"
                                  ? "Yüksek"
                                  : news.priority === "medium"
                                    ? "Orta"
                                    : "Düşük"}
                            </Badge>
                            <Switch
                              checked={news.isActive}
                              onCheckedChange={() => toggleNewsStatus(news.id)}
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteNews(news.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          {news.content}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{news.createdAt}</span>
                          <span>Görüntülenme: {news.views}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Messaging */}
          <TabsContent value="messaging" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Send Message */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Send className="w-5 h-5 mr-2" />
                    Toplu Mesaj Gönder
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="messageTitle">Mesaj Başlığı</Label>
                    <Input
                      id="messageTitle"
                      value={newMessage.title}
                      onChange={(e) =>
                        setNewMessage({ ...newMessage, title: e.target.value })
                      }
                      placeholder="Mesaj başlığı..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="messageContent">Mesaj İçeriği</Label>
                    <Textarea
                      id="messageContent"
                      rows={6}
                      value={newMessage.content}
                      onChange={(e) =>
                        setNewMessage({
                          ...newMessage,
                          content: e.target.value,
                        })
                      }
                      placeholder="Mesaj içeriği..."
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="messageType">Mesaj Türü</Label>
                      <Select
                        value={newMessage.type}
                        onValueChange={(value: any) =>
                          setNewMessage({ ...newMessage, type: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="email">
                            <Mail className="w-4 h-4 mr-2 inline" />
                            E-posta
                          </SelectItem>
                          <SelectItem value="sms">
                            <Smartphone className="w-4 h-4 mr-2 inline" />
                            SMS
                          </SelectItem>
                          <SelectItem value="notification">
                            <Bell className="w-4 h-4 mr-2 inline" />
                            Bildirim
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="messageRecipients">Alıcılar</Label>
                      <Select
                        value={newMessage.recipients}
                        onValueChange={(value: any) =>
                          setNewMessage({ ...newMessage, recipients: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Tüm Kullanıcılar</SelectItem>
                          <SelectItem value="members">Sadece Üyeler</SelectItem>
                          <SelectItem value="inactive">
                            Pasif Kullanıcılar
                          </SelectItem>
                          <SelectItem value="admins">Adminler</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="messageSchedule">
                      Zamanla Gönderim (Opsiyonel)
                    </Label>
                    <Input
                      id="messageSchedule"
                      type="datetime-local"
                      value={newMessage.scheduledFor}
                      onChange={(e) =>
                        setNewMessage({
                          ...newMessage,
                          scheduledFor: e.target.value,
                        })
                      }
                    />
                  </div>
                  <Button
                    onClick={sendMessage}
                    className="w-full bg-spiritual-gradient text-white"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {newMessage.scheduledFor
                      ? "Zamanla Gönder"
                      : "Hemen Gönder"}
                  </Button>
                </CardContent>
              </Card>

              {/* Message History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <MessageSquare className="w-5 h-5 mr-2" />
                    Gönderilen Mesajlar
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {messages.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Henüz mesaj gönderilmedi</p>
                      </div>
                    ) : (
                      messages.map((message) => (
                        <div
                          key={message.id}
                          className="p-4 border border-gray-200 rounded-lg"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold">{message.title}</h4>
                            <div className="flex items-center space-x-2">
                              <Badge
                                variant={
                                  message.status === "sent"
                                    ? "default"
                                    : message.status === "scheduled"
                                      ? "outline"
                                      : "secondary"
                                }
                              >
                                {message.status === "sent"
                                  ? "Gönderildi"
                                  : message.status === "scheduled"
                                    ? "Zamanlandı"
                                    : "Taslak"}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">
                            {message.content.substring(0, 100)}...
                          </p>
                          <div className="grid grid-cols-3 gap-4 text-xs text-gray-500">
                            <span>Teslim: {message.deliveryCount}</span>
                            <span>Açılma: {message.openCount}</span>
                            <span>Tıklama: {message.clickCount}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* MLM Network Management */}
          <TabsContent value="mlm" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
              <Card className="text-center">
                <CardContent className="p-6">
                  <TrendingUp className="w-12 h-12 mx-auto mb-4 text-spiritual-turquoise-600" />
                  <div className="text-2xl font-bold text-spiritual-turquoise-600 mb-2">
                    {stats.totalUsers}
                  </div>
                  <div className="text-sm text-gray-600">
                    Toplam Network Üyesi
                  </div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-6">
                  <DollarSign className="w-12 h-12 mx-auto mb-4 text-spiritual-gold-600" />
                  <div className="text-2xl font-bold text-spiritual-gold-600 mb-2">
                    ${stats.totalRevenue * 10}
                  </div>
                  <div className="text-sm text-gray-600">Toplam MLM Cirosu</div>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardContent className="p-6">
                  <Users className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                  <div className="text-2xl font-bold text-purple-600 mb-2">
                    {Math.floor(stats.totalUsers / 10)}
                  </div>
                  <div className="text-sm text-gray-600">Aktif Liderer</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* MLM Tree Visualization */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Network Ağacı Görünümü
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-spiritual-gradient rounded-full flex items-center justify-center mx-auto mb-2">
                        <Crown className="w-8 h-8 text-white" />
                      </div>
                      <p className="font-semibold">Master Lider</p>
                      <p className="text-sm text-gray-600">
                        Seviye 7 - 12 kişi
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                          <Users className="w-6 h-6 text-purple-600" />
                        </div>
                        <p className="text-sm font-medium">Sol Kol</p>
                        <p className="text-xs text-gray-600">156 üye</p>
                      </div>
                      <div className="text-center">
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                          <Users className="w-6 h-6 text-blue-600" />
                        </div>
                        <p className="text-sm font-medium">Sağ Kol</p>
                        <p className="text-xs text-gray-600">142 üye</p>
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <Button variant="outline" className="w-full">
                        <Eye className="w-4 h-4 mr-2" />
                        Detaylı Ağaç Görünümü
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* MLM Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart className="w-5 h-5 mr-2" />
                    MLM İstatistikleri
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">
                        Toplam Komisyon:
                      </span>
                      <span className="font-bold text-green-600">
                        ${stats.totalRevenue * 0.3}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">
                        Bu Ay Yeni Üye:
                      </span>
                      <span className="font-bold text-blue-600">47</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">
                        Ortalama Kazanç:
                      </span>
                      <span className="font-bold text-purple-600">
                        ${Math.floor(stats.totalRevenue / stats.totalUsers)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">
                        En Yüksek Seviye:
                      </span>
                      <span className="font-bold text-spiritual-gold-600">
                        Seviye 7
                      </span>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="font-semibold mb-3">Seviye Dağılımı:</h4>
                      <div className="space-y-2">
                        {[1, 2, 3, 4, 5, 6, 7].map((level) => (
                          <div
                            key={level}
                            className="flex justify-between text-sm"
                          >
                            <span>Seviye {level}:</span>
                            <span>
                              {Math.floor(stats.totalUsers / (level * 2))} kişi
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* MLM Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  MLM Sistem Kontrolleri
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-semibold">Komisyon Ayarları</h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <Label>Sponsor Bonusu:</Label>
                        <Input className="w-20" defaultValue="15" />
                        <span className="text-sm text-gray-600">%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Eşleşme Bonusu:</Label>
                        <Input className="w-20" defaultValue="10" />
                        <span className="text-sm text-gray-600">%</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Seviye Bonusu:</Label>
                        <Input className="w-20" defaultValue="5" />
                        <span className="text-sm text-gray-600">%</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold">Sistem Kontrolleri</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Label>MLM Sistemi Aktif:</Label>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Otomatik Komisyon:</Label>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Seviye Yükseltme:</Label>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4 mt-6">
                  <Button className="bg-spiritual-gradient text-white">
                    <Save className="w-4 h-4 mr-2" />
                    Ayarları Kaydet
                  </Button>
                  <Button variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    MLM Raporu İndir
                  </Button>
                  <Button variant="outline">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Komisyonları Yenile
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Kullanıcı Yönetimi
                  </CardTitle>
                  <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Kullanıcı ara..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-full md:w-64"
                      />
                    </div>
                    <Select value={userFilter} onValueChange={setUserFilter}>
                      <SelectTrigger className="w-full md:w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tümü</SelectItem>
                        <SelectItem value="active">Aktif</SelectItem>
                        <SelectItem value="inactive">Pasif</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Kullanıcı</TableHead>
                        <TableHead>İletişim</TableHead>
                        <TableHead>Abonelik</TableHead>
                        <TableHead>Kazanç</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead>İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium flex items-center">
                                {user.name}
                                {user.isAdmin && (
                                  <Crown className="w-4 h-4 ml-2 text-yellow-500" />
                                )}
                              </div>
                              <div className="text-sm text-gray-500">
                                Seviye {user.nefsLevel} •{" "}
                                {user.registrationDate}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{user.email}</div>
                              {user.phone && (
                                <div className="text-gray-500">
                                  {user.phone}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={user.subscriptionType}
                              onValueChange={(value: any) =>
                                updateUserSubscription(user.id, value)
                              }
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="free">Ücretsiz</SelectItem>
                                <SelectItem value="monthly">Aylık</SelectItem>
                                <SelectItem value="yearly">Yıllık</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">
                              ${user.totalEarnings}
                            </div>
                            <div className="text-sm text-gray-500">
                              {user.teamSize} kişi takım
                            </div>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={user.status}
                              onValueChange={(value: any) =>
                                updateUserStatus(user.id, value)
                              }
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="active">Aktif</SelectItem>
                                <SelectItem value="inactive">Pasif</SelectItem>
                                <SelectItem value="suspended">
                                  Askıya Alınmış
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Eye className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteUser(user.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Büyüme Trendi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    +{Math.round((stats.activeUsers / stats.totalUsers) * 100)}%
                  </div>
                  <p className="text-sm text-gray-600">
                    Bu ay yeni üye katılımı
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="w-5 h-5 mr-2" />
                    Gelir Analizi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-spiritual-gold-600 mb-2">
                    ${stats.totalRevenue}
                  </div>
                  <p className="text-sm text-gray-600">
                    Toplam platform geliri
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Aktivite Oranı
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-spiritual-purple-600 mb-2">
                    {Math.round((stats.activeUsers / stats.totalUsers) * 100)}%
                  </div>
                  <p className="text-sm text-gray-600">Aktif kullanıcı oranı</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Sistem Durumu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3">Platform Metrikleri</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Sunucu Durumu:</span>
                        <Badge className="bg-green-100 text-green-700">
                          Çevrimiçi
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Veritabanı:</span>
                        <Badge className="bg-green-100 text-green-700">
                          Bağlı
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>E-posta Servisi:</span>
                        <Badge className="bg-green-100 text-green-700">
                          Aktif
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>SMS Servisi:</span>
                        <Badge className="bg-green-100 text-green-700">
                          Aktif
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3">Son 24 Saat</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Yeni Kayıtlar:</span>
                        <span className="font-medium">3</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Gönderilen E-posta:</span>
                        <span className="font-medium">127</span>
                      </div>
                      <div className="flex justify-between">
                        <span>SMS Gönderimi:</span>
                        <span className="font-medium">45</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Platform Ziyareti:</span>
                        <span className="font-medium">892</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SuperAdminDashboard;
