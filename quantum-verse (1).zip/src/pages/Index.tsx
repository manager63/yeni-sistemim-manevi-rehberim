import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import DailyQuote from "@/components/DailyQuote";
import SpiritualTimer from "@/components/SpiritualTimer";
import { useAuth } from "@/contexts/AuthContext";
import {
  Star,
  Users,
  Heart,
  TrendingUp,
  Shield,
  Gift,
  Clock,
  BookOpen,
  Sparkles,
  Crown,
  Gem,
} from "lucide-react";
import { getTodaysPrayer } from "@/lib/spiritual";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const todaysPrayer = getTodaysPrayer();

  const features = [
    {
      icon: Heart,
      title: "Yaşam Koçluğu",
      description:
        "Profesyonel yaşam koçluğu ile kişisel gelişiminizi destekleyin",
      color: "text-red-500",
      path: "/yaşam-koçluğu",
    },
    {
      icon: Clock,
      title: "Meditasyon & Zikir",
      description: "Günlük meditasyon ve zikir alışkanlığı edinin",
      color: "text-spiritual-turquoise-500",
      path: "/meditasyon",
    },
    {
      icon: Star,
      title: "Dua & Niyet",
      description: "Günlük dualar ve niyetlerinizi kaydedin",
      color: "text-spiritual-gold-500",
      path: "/dua",
    },
    {
      icon: BookOpen,
      title: "Burç Yorumları",
      description: "Günlük burç yorumları ve yıldızname",
      color: "text-spiritual-purple-500",
      path: "/burç",
    },
    {
      icon: Users,
      title: "Network MLM",
      description: "7 seviyeli nefis mertebeleri ile gelir elde edin",
      color: "text-green-500",
      path: "/network",
    },
    {
      icon: Gift,
      title: "Ürünler",
      description: "Manevi gelişim ürünlerimizi keşfedin",
      color: "text-blue-500",
      path: "/ürünler",
    },
  ];

  const nefsLevels = [
    { emoji: "🌿", name: "Nefs-i Emmare", description: "Başlangıç seviyesi" },
    { emoji: "🌱", name: "Nefs-i Levvame", description: "Kendini sorgulama" },
    { emoji: "🌾", name: "Nefs-i Mülhime", description: "İlham alma" },
    { emoji: "🌼", name: "Nefs-i Mutmainne", description: "Huzur bulma" },
    { emoji: "🌸", name: "Nefs-i Râziye", description: "Rıza gösterme" },
    { emoji: "🌷", name: "Nefs-i Mardiyye", description: "Rıza görme" },
    { emoji: "🌺", name: "Nefs-i Kâmile", description: "Mükemmellik" },
  ];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-spiritual-gradient opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900">
                <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                  Manevi Rehberim
                </span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto">
                Ruhsal gelişim yolculuğunuzda yanınızdayız. Network sistemi ile
                hem kendinizi geliştirin hem de gelir elde edin.
              </p>
            </div>

            {!user && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  size="lg"
                  onClick={() => navigate("/kayıt")}
                  className="bg-spiritual-gradient text-white px-8 py-3 text-lg font-semibold hover:opacity-90 transform hover:scale-105 transition-all duration-200"
                >
                  <Users className="w-5 h-5 mr-2" />
                  Network'a Katıl
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={() => navigate("/giriş")}
                  className="border-spiritual-turquoise-300 text-spiritual-turquoise-700 px-8 py-3 text-lg hover:bg-spiritual-turquoise-50"
                >
                  Giriş Yap
                </Button>
              </div>
            )}

            {user && (
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 max-w-md mx-auto border border-spiritual-turquoise-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Crown className="w-6 h-6 text-spiritual-gold-500" />
                  <span className="text-lg font-semibold text-gray-700">
                    Hoş geldin, {user.name}!
                  </span>
                </div>
                <div className="space-y-2 text-sm text-gray-600">
                  <p>
                    Seviye: {nefsLevels[user.level - 1]?.emoji}{" "}
                    {nefsLevels[user.level - 1]?.name}
                  </p>
                  <p>Toplam Kazanç: ${user.totalEarnings}</p>
                  <p>Ekip Büyüklüğü: {user.teamSize} kişi</p>
                </div>
                <Button
                  onClick={() => navigate("/kullanıcı-paneli")}
                  className="w-full mt-4 bg-spiritual-gradient text-white"
                >
                  Panelime Git
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Daily Content Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Daily Quote */}
            <div className="space-y-6">
              <DailyQuote />

              {/* Daily Prayer */}
              <Card className="bg-gradient-to-br from-spiritual-purple-50 to-white border-spiritual-purple-200">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-spiritual-purple-700">
                    <Star className="w-6 h-6" />
                    <span>Günün Duası</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold text-spiritual-purple-700 mb-2">
                      {todaysPrayer.name}
                    </h3>
                    <div className="p-4 bg-white rounded-lg border border-spiritual-purple-100">
                      <p className="text-lg font-medium text-gray-800 mb-2 leading-relaxed">
                        {todaysPrayer.arabic}
                      </p>
                      <p className="text-sm text-gray-600">
                        {todaysPrayer.turkish}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Spiritual Timer */}
            <div>
              <SpiritualTimer />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Platform{" "}
              <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                Özellikleri
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Manevi gelişiminiz için ihtiyacınız olan tüm araçlar tek
              platformda
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="hover:shadow-lg transition-all duration-300 cursor-pointer group bg-white/80 backdrop-blur-sm border border-gray-200 hover:border-spiritual-turquoise-300"
                onClick={() => navigate(feature.path)}
              >
                <CardContent className="p-6 text-center">
                  <div className="mb-4">
                    <feature.icon
                      className={`w-12 h-12 mx-auto ${feature.color} group-hover:scale-110 transition-transform duration-200`}
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Nefs Levels Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                Nefs Mertebeleri
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              7 seviyeli ruhsal gelişim yolculuğu - Network sistemi ile her
              seviyede özel avantajlar
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {nefsLevels.slice(0, 4).map((level, index) => (
              <Card
                key={index}
                className="text-center bg-white/80 backdrop-blur-sm border border-spiritual-turquoise-200 hover:shadow-lg transition-all duration-300"
              >
                <CardContent className="p-4">
                  <div className="text-3xl mb-2">{level.emoji}</div>
                  <h3 className="font-semibold text-gray-900 mb-1 text-sm">
                    {level.name}
                  </h3>
                  <p className="text-xs text-gray-600">{level.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid sm:grid-cols-3 gap-4 mt-4 max-w-3xl mx-auto">
            {nefsLevels.slice(4).map((level, index) => (
              <Card
                key={index + 4}
                className="text-center bg-white/80 backdrop-blur-sm border border-spiritual-gold-200 hover:shadow-lg transition-all duration-300"
              >
                <CardContent className="p-4">
                  <div className="text-3xl mb-2">{level.emoji}</div>
                  <h3 className="font-semibold text-gray-900 mb-1 text-sm">
                    {level.name}
                  </h3>
                  <p className="text-xs text-gray-600">{level.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8">
            <Button
              onClick={() => navigate("/network")}
              className="bg-spiritual-gradient text-white px-8 py-3 text-lg font-semibold hover:opacity-90"
            >
              <TrendingUp className="w-5 h-5 mr-2" />
              Network Sistemini Keşfet
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-spiritual-gradient">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Manevi Yolculuğunuza Başlayın
            </h2>
            <p className="text-xl text-white/90">
              Aylık sadece $10 ile hem kendinizi geliştirin hem de gelir elde
              edin
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {!user && (
                <>
                  <Button
                    size="lg"
                    onClick={() => navigate("/kayıt")}
                    className="bg-white text-spiritual-turquoise-700 px-8 py-3 text-lg font-semibold hover:bg-gray-100"
                  >
                    <Users className="w-5 h-5 mr-2" />
                    Hemen Katıl
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => navigate("/yaşam-koçluğu")}
                    className="border-white text-white px-8 py-3 text-lg hover:bg-white/10"
                  >
                    Daha Fazla Bilgi
                  </Button>
                </>
              )}
              {user && (
                <Button
                  size="lg"
                  onClick={() => navigate("/kullanıcı-paneli")}
                  className="bg-white text-spiritual-turquoise-700 px-8 py-3 text-lg font-semibold hover:bg-gray-100"
                >
                  <Gem className="w-5 h-5 mr-2" />
                  Panelime Git
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
