import React, { useState, useEffect } from "react";
import { useNavigate, Link, useSearchParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import { Star, UserPlus, Eye, EyeOff, Users } from "lucide-react";

const registerSchema = z
  .object({
    name: z.string().min(2, "İsim en az 2 karakter olmalıdır"),
    email: z.string().email("Geçerli bir e-posta adresi girin"),
    password: z.string().min(6, "Şifre en az 6 karakter olmalıdır"),
    confirmPassword: z.string(),
    sponsorId: z.string().optional(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Şifreler eşleşmiyor",
    path: ["confirmPassword"],
  });

type RegisterFormData = z.infer<typeof registerSchema>;

const Register = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { register: registerUser, isLoading } = useAuth();
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const sponsorCode = searchParams.get("sponsor");

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      sponsorId: sponsorCode || "",
    },
  });

  useEffect(() => {
    if (sponsorCode) {
      setValue("sponsorId", sponsorCode);
    }
  }, [sponsorCode, setValue]);

  const onSubmit = async (data: RegisterFormData) => {
    setError("");
    setSuccess("");

    try {
      const success = await registerUser(
        data.email,
        data.password,
        data.name,
        data.sponsorId,
      );

      if (success) {
        setSuccess(
          "Kayıt başarılı! Abonelik işleminizi tamamlamak için yönlendiriliyorsunuz...",
        );
        setTimeout(() => {
          navigate("/kullanıcı-paneli");
        }, 2000);
      } else {
        setError("Kayıt olurken bir hata oluştu");
      }
    } catch (err) {
      setError("Kayıt işlemi sırasında bir hata oluştu");
    }
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-spiritual-gradient rounded-full flex items-center justify-center">
              <Star className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-spiritual-gradient bg-clip-text text-transparent">
            Manevi Rehberim
          </h1>
          <p className="text-gray-600 mt-2">Network'a katılın</p>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border border-spiritual-turquoise-200 shadow-xl">
          <CardHeader>
            <CardTitle className="text-center flex items-center justify-center space-x-2 text-spiritual-turquoise-700">
              <UserPlus className="w-6 h-6" />
              <span>Kayıt Ol</span>
            </CardTitle>
            {sponsorCode && (
              <div className="text-center">
                <div className="bg-spiritual-gold-50 border border-spiritual-gold-200 rounded-lg p-3">
                  <div className="flex items-center justify-center space-x-2 text-spiritual-gold-700">
                    <Users className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      Sponsor Kodu: {sponsorCode}
                    </span>
                  </div>
                  <p className="text-xs text-spiritual-gold-600 mt-1">
                    Bu sponsor aracılığıyla ekibe katılıyorsunuz
                  </p>
                </div>
              </div>
            )}
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {error && (
                <Alert className="border-red-200 bg-red-50 text-red-700">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="border-green-200 bg-green-50 text-green-700">
                  <AlertDescription>{success}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="name" className="text-spiritual-turquoise-700">
                  Ad Soyad
                </Label>
                <Input
                  {...register("name")}
                  type="text"
                  placeholder="Adınız Soyadınız"
                  className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                />
                {errors.name && (
                  <p className="text-sm text-red-600">{errors.name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-spiritual-turquoise-700">
                  E-posta
                </Label>
                <Input
                  {...register("email")}
                  type="email"
                  placeholder="ornek@email.com"
                  className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                />
                {errors.email && (
                  <p className="text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="password"
                  className="text-spiritual-turquoise-700"
                >
                  Şifre
                </Label>
                <div className="relative">
                  <Input
                    {...register("password")}
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-sm text-red-600">
                    {errors.password.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="confirmPassword"
                  className="text-spiritual-turquoise-700"
                >
                  Şifre Tekrar
                </Label>
                <div className="relative">
                  <Input
                    {...register("confirmPassword")}
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-sm text-red-600">
                    {errors.confirmPassword.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label
                  htmlFor="sponsorId"
                  className="text-spiritual-turquoise-700"
                >
                  Sponsor Kodu (Opsiyonel)
                </Label>
                <Input
                  {...register("sponsorId")}
                  type="text"
                  placeholder="REF123456"
                  className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                />
                <p className="text-xs text-gray-500">
                  Bir sponsor kodunuz varsa buraya girin
                </p>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-spiritual-gradient text-white hover:opacity-90"
              >
                {isLoading ? "Kayıt yapılıyor..." : "Kayıt Ol"}
              </Button>

              <div className="text-center space-y-2">
                <p className="text-sm text-gray-600">
                  Zaten hesabınız var mı?{" "}
                  <Link
                    to="/giriş"
                    className="text-spiritual-turquoise-600 hover:text-spiritual-turquoise-700 font-medium"
                  >
                    Giriş yapın
                  </Link>
                </p>
              </div>
            </form>

            {/* Subscription Info */}
            <div className="mt-6 p-4 bg-spiritual-purple-50 rounded-lg border border-spiritual-purple-200">
              <h4 className="text-sm font-medium text-spiritual-purple-700 mb-2">
                💎 Abonelik Planları
              </h4>
              <div className="space-y-1 text-xs text-spiritual-purple-600">
                <p>• Aylık: $10 - Temel erişim</p>
                <p>• Yıllık: $100 - %17 tasarruf</p>
                <p>• Tüm manevi içeriklere erişim</p>
                <p>• Network MLM sistemi</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <Link
            to="/"
            className="text-spiritual-turquoise-600 hover:text-spiritual-turquoise-700 text-sm"
          >
            ← Ana sayfaya dön
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
