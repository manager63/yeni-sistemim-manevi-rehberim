import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useAuth } from "@/contexts/AuthContext";
import {
  Menu,
  Home,
  Users,
  ShoppingCart,
  User,
  Settings,
  LogOut,
  LogIn,
  Star,
  Heart,
  Clock,
  BookOpen,
  TrendingUp,
  Shield,
  Crown,
  ChevronDown,
} from "lucide-react";

const Navigation = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/");
    setIsOpen(false);
  };

  const isActive = (path: string) => location.pathname === path;

  const navigationItems = [
    {
      path: "/",
      label: "Ana Sayfa",
      icon: Home,
      description: "Platform ana sayfası",
    },
    {
      path: "/yaşam-koçluğu",
      label: "Yaşam Koçluğu",
      icon: Heart,
      description:
        "İslami değerlerle desteklenen profesyonel yaşam danışmanlığı",
    },
    {
      path: "/meditasyon",
      label: "Dhikr & Meditasyon",
      icon: Clock,
      description: "İslami zikir ve tefekkür pratikleri",
    },
    {
      path: "/dua",
      label: "Dua & Niyet",
      icon: Star,
      description: "Günlük dualar ve manevi niyetler",
    },
    {
      path: "/burç",
      label: "Manevi Rehberlik",
      icon: BookOpen,
      description: "Rüya tabirleri ve manevi analiz",
    },
    {
      path: "/ürünler",
      label: "Manevi Ürünler",
      icon: ShoppingCart,
      description: "Ruhsal gelişim kitapları ve materyalleri",
    },
    {
      path: "/network",
      label: "Nefs Mertebeleri MLM",
      icon: Users,
      description: "7 seviyeli manevi gelişim ve kazanç sistemi",
    },
  ];

  const userMenuItems = user
    ? [
        { path: "/kullanıcı-paneli", label: "Kullanıcı Paneli", icon: User },
        ...(user.isAdmin
          ? [
              { path: "/admin", label: "Admin Panel", icon: Shield },
              { path: "/enhanced-admin", label: "Gelişmiş Admin", icon: Crown },
              {
                path: "/super-admin-dashboard",
                label: "Yönetici Paneli",
                icon: Crown,
              },
              {
                path: "/comprehensive-admin",
                label: "Kapsamlı Admin Panel",
                icon: Settings,
              },
              {
                path: "/ultimate-admin",
                label: "Ultimate Admin Kontrol",
                icon: Shield,
              },
            ]
          : []),
      ]
    : [];

  const NavItems = ({ onItemClick }: { onItemClick?: () => void }) => (
    <>
      {navigationItems.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          onClick={onItemClick}
          className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 hover:bg-spiritual-turquoise-100 ${
            isActive(item.path)
              ? "bg-spiritual-turquoise-200 text-spiritual-turquoise-700"
              : "text-gray-700"
          }`}
        >
          <item.icon className="w-5 h-5" />
          <span>{item.label}</span>
        </Link>
      ))}
    </>
  );

  return (
    <nav className="bg-white shadow-lg border-b border-spiritual-turquoise-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-spiritual-gradient rounded-full flex items-center justify-center">
                <Star className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-spiritual-gradient bg-clip-text text-transparent">
                Manevi Rehberim
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            <NavItems />
          </div>

          {/* Admin User Menu - Only for logged in admins */}
          {user && user.isAdmin && (
            <div className="hidden md:flex items-center space-x-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="flex items-center space-x-2 border-spiritual-turquoise-300 text-spiritual-turquoise-700 hover:bg-spiritual-turquoise-50"
                  >
                    <Crown className="w-4 h-4" />
                    <span>{user.name}</span>
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-64 p-2" align="end">
                  <div className="space-y-1">
                    <div className="px-3 py-2 border-b border-gray-200">
                      <p className="font-medium text-gray-900 text-sm flex items-center">
                        <Crown className="w-3 h-3 mr-1 text-yellow-500" />
                        {user.name}
                      </p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                      <p className="text-xs text-yellow-600 mt-1">
                        ✓ Sistem Yöneticisi
                      </p>
                    </div>

                    {userMenuItems.map((item) => (
                      <button
                        key={item.path}
                        onClick={() => navigate(item.path)}
                        className="w-full flex items-center space-x-2 px-3 py-2 rounded-md text-left hover:bg-gray-100 transition-colors"
                      >
                        <item.icon className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-700">
                          {item.label}
                        </span>
                      </button>
                    ))}

                    <div className="border-t border-gray-200 pt-1 mt-1">
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center space-x-2 px-3 py-2 rounded-md text-left hover:bg-red-50 transition-colors text-red-600"
                      >
                        <LogOut className="w-4 h-4" />
                        <span className="text-sm">Çıkış Yap</span>
                      </button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          )}

          {/* Mobile Menu */}
          <div className="md:hidden flex items-center">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <div className="flex flex-col space-y-4 mt-8">
                  <div className="flex items-center space-x-2 mb-6">
                    <div className="w-8 h-8 bg-spiritual-gradient rounded-full flex items-center justify-center">
                      <Star className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-xl font-bold bg-spiritual-gradient bg-clip-text text-transparent">
                      Manevi Rehberim
                    </span>
                  </div>

                  <NavItems onItemClick={() => setIsOpen(false)} />

                  {/* Admin Mobile Menu */}
                  {user && user.isAdmin && (
                    <div className="border-t border-gray-200 pt-4 mt-6">
                      <div className="space-y-3">
                        <div className="px-4 py-3 bg-yellow-50 rounded-lg border border-yellow-200">
                          <p className="text-sm font-medium text-gray-900 flex items-center">
                            <Crown className="w-3 h-3 mr-1 text-yellow-500" />
                            {user.name}
                          </p>
                          <p className="text-xs text-gray-500">{user.email}</p>
                          <p className="text-xs text-yellow-600 mt-1">
                            ✓ Sistem Yöneticisi
                          </p>
                        </div>

                        <div className="space-y-2">
                          {userMenuItems.map((item) => (
                            <button
                              key={item.path}
                              onClick={() => {
                                navigate(item.path);
                                setIsOpen(false);
                              }}
                              className="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-left hover:bg-yellow-100 transition-colors"
                            >
                              <item.icon className="w-4 h-4 text-yellow-600" />
                              <span className="text-sm text-gray-700">
                                {item.label}
                              </span>
                            </button>
                          ))}
                        </div>

                        <Button
                          variant="outline"
                          onClick={handleLogout}
                          className="w-full justify-start border-red-200 text-red-600 hover:bg-red-50"
                        >
                          <LogOut className="w-4 h-4 mr-2" />
                          Çıkış Yap
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
