import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import {
  Crown,
  Users,
  Mail,
  MessageSquare,
  Bell,
  Settings,
  Plus,
  Edit,
  Trash2,
  Send,
  Eye,
  Save,
  Download,
  Upload,
  BarChart,
  TrendingUp,
  DollarSign,
  Shield,
  CheckCircle,
  AlertCircle,
  Calendar,
  Clock,
  Filter,
  Search,
  RefreshCw,
  FileText,
  Image,
  Video,
  Phone,
  Smartphone,
  Globe,
  Target,
  Star,
  Gift,
  Package,
  CreditCard,
  Database,
  Lock,
  Key,
  BookOpen,
  ShoppingCart,
  Heart,
  Home,
} from "lucide-react";

const ComprehensiveAdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);

  // Check admin authentication
  useEffect(() => {
    if (!user?.isAdmin) {
      navigate("/giriş");
    }
  }, [user, navigate]);

  if (!user?.isAdmin) {
    return null;
  }

  // Sample data for demonstration
  const [users, setUsers] = useState([
    {
      id: 1,
      name: "Ahmet Yılmaz",
      email: "ahmet@email.com",
      phone: "+90 555 123 4567",
      subscriptionActive: true,
      subscriptionType: "yearly" as const,
      registrationDate: "2024-01-15",
      lastLogin: "2024-01-20",
      totalEarnings: 2500,
      teamSize: 15,
      nefsLevel: 4,
      isAdmin: false,
      status: "active" as const,
    },
    {
      id: 2,
      name: "Fatma Demir",
      email: "fatma@email.com",
      phone: "+90 555 987 6543",
      subscriptionActive: true,
      subscriptionType: "monthly" as const,
      registrationDate: "2024-01-10",
      lastLogin: "2024-01-19",
      totalEarnings: 850,
      teamSize: 8,
      nefsLevel: 3,
      isAdmin: false,
      status: "active" as const,
    },
  ]);

  const [websiteContent, setWebsiteContent] = useState({
    homepage: {
      title: "Manevi Rehberim",
      subtitle: "Ruhsal Gelişim ve İçsel Huzur Platformu",
      heroDescription:
        "İslami değerlerle desteklenen manevi gelişim programları, yaşam koçluğu hizmetleri ve MLM sistemi ile hem ruhsal hem de maddi kazanç elde edin.",
      featuredServices: [
        "Yaşam Koçluğu",
        "Dhikr & Meditasyon",
        "Dua & Niyet",
        "Manevi Rehberlik",
      ],
    },
    lifeCoaching: {
      title: "İslami Yaşam Koçluğu",
      description:
        "Kuran ve Sünnet ışığında profesyonel yaşam danışmanlığı hizmetleri",
      services: [
        "Kişisel Gelişim Danışmanlığı",
        "Evlilik ve Aile Danışmanlığı",
        "Kariyer Rehberliği",
        "Stres Yönetimi",
      ],
      pricing: {
        individual: { price: 150, duration: "60 dakika" },
        couple: { price: 200, duration: "75 dakika" },
        family: { price: 250, duration: "90 dakika" },
      },
    },
    meditation: {
      title: "Dhikr ve Meditasyon",
      description: "İslami zikir ve tefekkür pratikleriyle iç huzura kavuşun",
      practices: [
        "Sabah Dhikri",
        "Akşam Dhikri",
        "Tefekkür Meditasyonu",
        "Nefes Egzersizleri",
      ],
      guidedSessions: true,
      timerFeatures: true,
    },
    prayer: {
      title: "Dua ve Niyet",
      description: "Günlük dualar ve manevi niyetlerle kalbi besleyin",
      categories: [
        "Günlük Dualar",
        "Özel Dualar",
        "Hastalık Duaları",
        "Bereket Duaları",
      ],
      features: ["Audio Recordings", "Text Display", "Translation"],
    },
    guidance: {
      title: "Manevi Rehberlik",
      description: "Rüya tabirleri ve manevi analiz hizmetleri",
      services: [
        "Rüya Tabiri",
        "Manevi Danışmanlık",
        "İstikhare Rehberliği",
        "Kişisel Analiz",
      ],
      pricing: {
        consultation: 100,
        dreamAnalysis: 75,
        spiritualGuidance: 125,
      },
    },
    products: {
      title: "Manevi Ürünler",
      description: "Ruhsal gelişim kitapları ve materyalleri",
      categories: [
        "Kitaplar",
        "Audio Kitaplar",
        "Meditasyon Müziği",
        "Dijital İçerik",
        "Tesbihat",
        "Hediye Setleri",
      ],
      totalProducts: 45,
      featuredProducts: 12,
    },
    mlmSystem: {
      title: "Nefs Mertebeleri MLM Sistemi",
      description: "7 seviyeli manevi gelişim ve kazanç sistemi",
      levels: 7,
      commissionRates: {
        level1: "5%",
        level2: "8%",
        level3: "12%",
        level4: "15%",
        level5: "18%",
        level6: "22%",
        level7: "25%",
      },
      activeMembers: 1247,
      totalCapacity: 10000000,
    },
  });

  const [mlmSettings, setMlmSettings] = useState({
    systemActive: true,
    registrationOpen: true,
    commissionPayments: true,
    maxLevels: 7,
    monthlySubscription: 10,
    yearlySubscription: 100,
    yearlyDiscount: 17,
    maxTeamSize: 10000000,
    bonusThresholds: {
      bronze: 1000,
      silver: 5000,
      gold: 15000,
      platinum: 50000,
    },
  });

  const [newsItems, setNewsItems] = useState([
    {
      id: 1,
      title: "Yeni Özellikler Eklendi",
      content:
        "Dhikr sayacı ve manevi takip özellikleri sistemimize eklendi. Artık günlük dhikr pratiklerinizi takip edebilirsiniz.",
      type: "update" as const,
      priority: "medium" as const,
      targetAudience: "all",
      createdDate: "2024-01-20",
      expiryDate: "2024-02-20",
      isActive: true,
    },
    {
      id: 2,
      title: "Aylık Hedef Kampanyası",
      content:
        "Bu ay hedefine ulaşan tüm üyelerimize özel bonus! %25 ekstra komisyon kazanma fırsatı.",
      type: "promotion" as const,
      priority: "high" as const,
      targetAudience: "members",
      createdDate: "2024-01-18",
      expiryDate: "2024-01-31",
      isActive: true,
    },
  ]);

  const handleUserAction = (
    action: string,
    userId: number,
    newStatus?: string,
  ) => {
    setUsers((prev) =>
      prev.map((user) => {
        if (user.id === userId) {
          switch (action) {
            case "suspend":
              return { ...user, status: "suspended" as const };
            case "activate":
              return { ...user, status: "active" as const };
            case "changeSubscription":
              return {
                ...user,
                subscriptionType: newStatus as "monthly" | "yearly" | "free",
                subscriptionActive: newStatus !== "free",
              };
            default:
              return user;
          }
        }
        return user;
      }),
    );
  };

  const sendBulkMessage = (message: string, type: string) => {
    console.log("Sending bulk message:", {
      message,
      type,
      users: selectedUsers,
    });
    alert(
      `Mesaj ${selectedUsers.length > 0 ? selectedUsers.length + " seçili kullanıcıya" : "tüm kullanıcılara"} gönderildi!`,
    );
  };

  const updateWebsiteContent = (section: string, content: any) => {
    setWebsiteContent((prev) => ({
      ...prev,
      [section]: { ...prev[section as keyof typeof prev], ...content },
    }));
    alert(`${section} bölümü güncellendi!`);
  };

  const updateMLMSettings = (newSettings: any) => {
    setMlmSettings((prev) => ({ ...prev, ...newSettings }));
    alert("MLM sistem ayarları güncellendi!");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Crown className="w-8 h-8 mr-3 text-yellow-500" />
                Kapsamlı Admin Yönetim Paneli
              </h1>
              <p className="text-gray-600 mt-2">
                Tüm website bölümlerini ve MLM sistemini yönetin
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Badge className="bg-green-100 text-green-800">
                Sistem Aktif
              </Badge>
              <Badge className="bg-blue-100 text-blue-800">
                {users.length} Aktif Üye
              </Badge>
            </div>
          </div>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-6">
            <TabsTrigger value="overview">
              <BarChart className="w-4 h-4 mr-2" />
              Genel Bakı��
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="w-4 h-4 mr-2" />
              Kullanıcı Yönetimi
            </TabsTrigger>
            <TabsTrigger value="content">
              <FileText className="w-4 h-4 mr-2" />
              İçerik Yönetimi
            </TabsTrigger>
            <TabsTrigger value="mlm">
              <TrendingUp className="w-4 h-4 mr-2" />
              MLM Sistemi
            </TabsTrigger>
            <TabsTrigger value="news">
              <Bell className="w-4 h-4 mr-2" />
              Haber Yönetimi
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-4 h-4 mr-2" />
              Sistem Ayarları
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Toplam Kullanıcı
                      </p>
                      <p className="text-2xl font-bold">{users.length}</p>
                    </div>
                    <Users className="w-8 h-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Aktif Abonelik
                      </p>
                      <p className="text-2xl font-bold">
                        {users.filter((u) => u.subscriptionActive).length}
                      </p>
                    </div>
                    <CreditCard className="w-8 h-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Toplam Gelir
                      </p>
                      <p className="text-2xl font-bold">
                        $
                        {users
                          .reduce((sum, u) => sum + u.totalEarnings, 0)
                          .toLocaleString()}
                      </p>
                    </div>
                    <DollarSign className="w-8 h-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        MLM Kapasitesi
                      </p>
                      <p className="text-2xl font-bold">
                        {(
                          (mlmSettings.activeMembers /
                            mlmSettings.maxTeamSize) *
                          100
                        ).toFixed(2)}
                        %
                      </p>
                    </div>
                    <Target className="w-8 h-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="w-5 h-5 mr-2" />
                    Website Yönetimi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("content")}
                    >
                      <Home className="w-4 h-4 mr-2" />
                      Ana Sayfa Düzenle
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("content")}
                    >
                      <Heart className="w-4 h-4 mr-2" />
                      Yaşam Koçluğu Ayarları
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("content")}
                    >
                      <Star className="w-4 h-4 mr-2" />
                      Meditasyon Bölümü
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    MLM Sistem Kontrolü
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Sistem Durumu</span>
                      <Switch
                        checked={mlmSettings.systemActive}
                        onCheckedChange={(checked) =>
                          updateMLMSettings({ systemActive: checked })
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Kayıt Açık</span>
                      <Switch
                        checked={mlmSettings.registrationOpen}
                        onCheckedChange={(checked) =>
                          updateMLMSettings({ registrationOpen: checked })
                        }
                      />
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => setActiveTab("mlm")}
                    >
                      Detaylı Ayarlar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bell className="w-5 h-5 mr-2" />
                    Hızlı Mesajlaşma
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => setActiveTab("news")}
                    >
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Duyuru Yayınla
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => setActiveTab("users")}
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      Toplu E-posta
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => setActiveTab("users")}
                    >
                      <Smartphone className="w-4 h-4 mr-2" />
                      SMS Gönder
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Kullanıcı Yönetimi</h2>
                <div className="flex space-x-3">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Yeni Kullanıcı
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Yeni Kullanıcı Ekle</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Ad Soyad</Label>
                          <Input placeholder="Kullanıcı adı" />
                        </div>
                        <div>
                          <Label>E-posta</Label>
                          <Input type="email" placeholder="email@example.com" />
                        </div>
                        <div>
                          <Label>Telefon</Label>
                          <Input placeholder="+90 555 123 4567" />
                        </div>
                        <div>
                          <Label>Abonelik Tipi</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Abonelik seçin" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="monthly">Aylık</SelectItem>
                              <SelectItem value="yearly">Yıllık</SelectItem>
                              <SelectItem value="free">Ücretsiz</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button className="w-full">Kullanıcı Ekle</Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">
                        <Send className="w-4 h-4 mr-2" />
                        Toplu Mesaj
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Toplu Mesaj Gönder</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label>Mesaj Tipi</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Mesaj tipi seçin" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="email">E-posta</SelectItem>
                              <SelectItem value="sms">SMS</SelectItem>
                              <SelectItem value="notification">
                                Uygulama Bildirimi
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Mesaj İçeriği</Label>
                          <Textarea
                            placeholder="Mesajınızı buraya yazın..."
                            rows={4}
                          />
                        </div>
                        <div>
                          <Label>Hedef Kitle</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Hedef kitle seçin" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">
                                Tüm Kullanıcılar
                              </SelectItem>
                              <SelectItem value="active">
                                Aktif Aboneler
                              </SelectItem>
                              <SelectItem value="inactive">
                                Pasif Kullanıcılar
                              </SelectItem>
                              <SelectItem value="selected">
                                Seçili Kullanıcılar ({selectedUsers.length})
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button
                          className="w-full"
                          onClick={() =>
                            sendBulkMessage("Test mesajı", "email")
                          }
                        >
                          Mesaj Gönder
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              {/* Users Table */}
              <Card>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>
                          <input
                            type="checkbox"
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedUsers(users.map((u) => u.id));
                              } else {
                                setSelectedUsers([]);
                              }
                            }}
                          />
                        </TableHead>
                        <TableHead>Kullanıcı</TableHead>
                        <TableHead>İletişim</TableHead>
                        <TableHead>Abonelik</TableHead>
                        <TableHead>MLM Bilgileri</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead>İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <input
                              type="checkbox"
                              checked={selectedUsers.includes(user.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedUsers([...selectedUsers, user.id]);
                                } else {
                                  setSelectedUsers(
                                    selectedUsers.filter(
                                      (id) => id !== user.id,
                                    ),
                                  );
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium">{user.name}</div>
                              <div className="text-sm text-gray-500">
                                ID: {user.id}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="text-sm">{user.email}</div>
                              <div className="text-sm text-gray-500">
                                {user.phone}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <Badge
                                className={
                                  user.subscriptionActive
                                    ? "bg-green-100 text-green-800"
                                    : "bg-red-100 text-red-800"
                                }
                              >
                                {user.subscriptionType}
                              </Badge>
                              <div className="text-xs text-gray-500 mt-1">
                                Kayıt: {user.registrationDate}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="text-sm">
                                Seviye: {user.nefsLevel}
                              </div>
                              <div className="text-sm">
                                Takım: {user.teamSize}
                              </div>
                              <div className="text-sm text-green-600">
                                ${user.totalEarnings}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                user.status === "active"
                                  ? "bg-green-100 text-green-800"
                                  : user.status === "suspended"
                                    ? "bg-red-100 text-red-800"
                                    : "bg-yellow-100 text-yellow-800"
                              }
                            >
                              {user.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  handleUserAction("suspend", user.id)
                                }
                              >
                                <Lock className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  handleUserAction("activate", user.id)
                                }
                              >
                                <CheckCircle className="w-3 h-3" />
                              </Button>
                              <Select
                                onValueChange={(value) =>
                                  handleUserAction(
                                    "changeSubscription",
                                    user.id,
                                    value,
                                  )
                                }
                              >
                                <SelectTrigger className="w-20">
                                  <SelectValue placeholder="Değiştir" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="monthly">Aylık</SelectItem>
                                  <SelectItem value="yearly">Yıllık</SelectItem>
                                  <SelectItem value="free">Ücretsiz</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Content Management Tab */}
          <TabsContent value="content">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Website İçerik Yönetimi</h2>

              <Tabs defaultValue="homepage">
                <TabsList>
                  <TabsTrigger value="homepage">Ana Sayfa</TabsTrigger>
                  <TabsTrigger value="coaching">Yaşam Koçluğu</TabsTrigger>
                  <TabsTrigger value="meditation">Meditasyon</TabsTrigger>
                  <TabsTrigger value="prayer">Dua & Niyet</TabsTrigger>
                  <TabsTrigger value="guidance">Manevi Rehberlik</TabsTrigger>
                  <TabsTrigger value="products">Ürünler</TabsTrigger>
                </TabsList>

                <TabsContent value="homepage">
                  <Card>
                    <CardHeader>
                      <CardTitle>Ana Sayfa İçeriği</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label>Ana Başlık</Label>
                        <Input
                          value={websiteContent.homepage.title}
                          onChange={(e) =>
                            updateWebsiteContent("homepage", {
                              title: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Alt Başlık</Label>
                        <Input
                          value={websiteContent.homepage.subtitle}
                          onChange={(e) =>
                            updateWebsiteContent("homepage", {
                              subtitle: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Ana Açıklama</Label>
                        <Textarea
                          value={websiteContent.homepage.heroDescription}
                          onChange={(e) =>
                            updateWebsiteContent("homepage", {
                              heroDescription: e.target.value,
                            })
                          }
                          rows={4}
                        />
                      </div>
                      <Button
                        onClick={() => alert("Ana sayfa içeriği güncellendi!")}
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Değişiklikleri Kaydet
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="coaching">
                  <Card>
                    <CardHeader>
                      <CardTitle>Yaşam Koçluğu Yönetimi</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label>Hizmet Başlığı</Label>
                        <Input
                          value={websiteContent.lifeCoaching.title}
                          onChange={(e) =>
                            updateWebsiteContent("lifeCoaching", {
                              title: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div>
                        <Label>Hizmet Açıklaması</Label>
                        <Textarea
                          value={websiteContent.lifeCoaching.description}
                          onChange={(e) =>
                            updateWebsiteContent("lifeCoaching", {
                              description: e.target.value,
                            })
                          }
                          rows={3}
                        />
                      </div>
                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <Label>Bireysel Fiyat (TL)</Label>
                          <Input
                            type="number"
                            value={
                              websiteContent.lifeCoaching.pricing.individual
                                .price
                            }
                            onChange={(e) =>
                              updateWebsiteContent("lifeCoaching", {
                                pricing: {
                                  ...websiteContent.lifeCoaching.pricing,
                                  individual: {
                                    ...websiteContent.lifeCoaching.pricing
                                      .individual,
                                    price: parseInt(e.target.value),
                                  },
                                },
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label>Çift Fiyat (TL)</Label>
                          <Input
                            type="number"
                            value={
                              websiteContent.lifeCoaching.pricing.couple.price
                            }
                            onChange={(e) =>
                              updateWebsiteContent("lifeCoaching", {
                                pricing: {
                                  ...websiteContent.lifeCoaching.pricing,
                                  couple: {
                                    ...websiteContent.lifeCoaching.pricing
                                      .couple,
                                    price: parseInt(e.target.value),
                                  },
                                },
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label>Aile Fiyat (TL)</Label>
                          <Input
                            type="number"
                            value={
                              websiteContent.lifeCoaching.pricing.family.price
                            }
                            onChange={(e) =>
                              updateWebsiteContent("lifeCoaching", {
                                pricing: {
                                  ...websiteContent.lifeCoaching.pricing,
                                  family: {
                                    ...websiteContent.lifeCoaching.pricing
                                      .family,
                                    price: parseInt(e.target.value),
                                  },
                                },
                              })
                            }
                          />
                        </div>
                      </div>
                      <Button
                        onClick={() =>
                          alert("Yaşam koçluğu ayarları güncellendi!")
                        }
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Kaydet
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="products">
                  <Card>
                    <CardHeader>
                      <CardTitle>Ürün Yönetimi</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label>Toplam Ürün Sayısı</Label>
                          <Input
                            type="number"
                            value={websiteContent.products.totalProducts}
                            onChange={(e) =>
                              updateWebsiteContent("products", {
                                totalProducts: parseInt(e.target.value),
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label>Öne Çıkan Ürün Sayısı</Label>
                          <Input
                            type="number"
                            value={websiteContent.products.featuredProducts}
                            onChange={(e) =>
                              updateWebsiteContent("products", {
                                featuredProducts: parseInt(e.target.value),
                              })
                            }
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Ürün Kategorileri (virgülle ayırın)</Label>
                        <Input
                          value={websiteContent.products.categories.join(", ")}
                          onChange={(e) =>
                            updateWebsiteContent("products", {
                              categories: e.target.value
                                .split(",")
                                .map((s) => s.trim()),
                            })
                          }
                        />
                      </div>
                      <Button
                        onClick={() => alert("Ürün ayarları güncellendi!")}
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Kaydet
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </TabsContent>

          {/* MLM System Tab */}
          <TabsContent value="mlm">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">MLM Sistem Yönetimi</h2>

              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Sistem Ayarları</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>MLM Sistemi Aktif</Label>
                      <Switch
                        checked={mlmSettings.systemActive}
                        onCheckedChange={(checked) =>
                          updateMLMSettings({ systemActive: checked })
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Yeni Kayıtlar Açık</Label>
                      <Switch
                        checked={mlmSettings.registrationOpen}
                        onCheckedChange={(checked) =>
                          updateMLMSettings({ registrationOpen: checked })
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Komisyon Ödemeleri</Label>
                      <Switch
                        checked={mlmSettings.commissionPayments}
                        onCheckedChange={(checked) =>
                          updateMLMSettings({ commissionPayments: checked })
                        }
                      />
                    </div>
                    <div>
                      <Label>Maksimum Seviye Sayısı</Label>
                      <Input
                        type="number"
                        value={mlmSettings.maxLevels}
                        onChange={(e) =>
                          updateMLMSettings({
                            maxLevels: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Abonelik Fiyatları</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Aylık Abonelik ($)</Label>
                      <Input
                        type="number"
                        value={mlmSettings.monthlySubscription}
                        onChange={(e) =>
                          updateMLMSettings({
                            monthlySubscription: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Yıllık Abonelik ($)</Label>
                      <Input
                        type="number"
                        value={mlmSettings.yearlySubscription}
                        onChange={(e) =>
                          updateMLMSettings({
                            yearlySubscription: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Yıllık İndirim (%)</Label>
                      <Input
                        type="number"
                        value={mlmSettings.yearlyDiscount}
                        onChange={(e) =>
                          updateMLMSettings({
                            yearlyDiscount: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Maksimum Takım Kapasitesi</Label>
                      <Input
                        type="number"
                        value={mlmSettings.maxTeamSize}
                        onChange={(e) =>
                          updateMLMSettings({
                            maxTeamSize: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Komisyon Oranları (Nefs Seviyeleri)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-4 gap-4">
                    {Object.entries(
                      websiteContent.mlmSystem.commissionRates,
                    ).map(([level, rate]) => (
                      <div key={level}>
                        <Label>{level.toUpperCase()}</Label>
                        <Input
                          value={rate}
                          onChange={(e) =>
                            updateWebsiteContent("mlmSystem", {
                              commissionRates: {
                                ...websiteContent.mlmSystem.commissionRates,
                                [level]: e.target.value,
                              },
                            })
                          }
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* News Management Tab */}
          <TabsContent value="news">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Haber ve Duyuru Yönetimi</h2>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Yeni Duyuru
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Yeni Duyuru Oluştur</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Başlık</Label>
                        <Input placeholder="Duyuru başlığı" />
                      </div>
                      <div>
                        <Label>İçerik</Label>
                        <Textarea placeholder="Duyuru içeriği..." rows={4} />
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label>Tip</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Duyuru tipi" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="announcement">
                                Duyuru
                              </SelectItem>
                              <SelectItem value="update">Güncelleme</SelectItem>
                              <SelectItem value="promotion">
                                Kampanya
                              </SelectItem>
                              <SelectItem value="warning">Uyarı</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Öncelik</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Öncelik seviyesi" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="low">Düşük</SelectItem>
                              <SelectItem value="medium">Orta</SelectItem>
                              <SelectItem value="high">Yüksek</SelectItem>
                              <SelectItem value="urgent">Acil</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label>Hedef Kitle</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Hedef kitle seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Herkes</SelectItem>
                            <SelectItem value="members">Üyeler</SelectItem>
                            <SelectItem value="admins">Adminler</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Bitiş Tarihi</Label>
                        <Input type="date" />
                      </div>
                      <Button className="w-full">Duyuru Yayınla</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid gap-4">
                {newsItems.map((news) => (
                  <Card key={news.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold">{news.title}</h3>
                            <Badge
                              className={
                                news.priority === "urgent"
                                  ? "bg-red-100 text-red-800"
                                  : news.priority === "high"
                                    ? "bg-orange-100 text-orange-800"
                                    : "bg-blue-100 text-blue-800"
                              }
                            >
                              {news.priority}
                            </Badge>
                            <Badge variant="outline">{news.type}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">
                            {news.content}
                          </p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span>Oluşturulma: {news.createdDate}</span>
                            <span>Bitiş: {news.expiryDate}</span>
                            <span>Hedef: {news.targetAudience}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            checked={news.isActive}
                            onCheckedChange={(checked) => {
                              setNewsItems((prev) =>
                                prev.map((item) =>
                                  item.id === news.id
                                    ? { ...item, isActive: checked }
                                    : item,
                                ),
                              );
                            }}
                          />
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-red-600"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Sistem Ayarları</h2>

              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Güvenlik Ayarları</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Admin Giriş Bilgileri</Label>
                      <div className="space-y-2">
                        <Input
                          placeholder="Kullanıcı adı"
                          value="abdulkadirkan"
                          readOnly
                        />
                        <Input
                          type="password"
                          placeholder="Şifre"
                          value="Abdulkadir1983."
                          readOnly
                        />
                      </div>
                    </div>
                    <Button variant="outline" className="w-full">
                      <Key className="w-4 h-4 mr-2" />
                      Şifre Değiştir
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sistem Durumu</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Website Aktif</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Yeni Kayıtlar</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Email Bildirimleri</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>SMS Bildirimleri</span>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Yedekleme ve Geri Yükleme</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button className="w-full" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Veri Yedekle
                    </Button>
                    <Button className="w-full" variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Yedek Geri Yükle
                    </Button>
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        Son yedekleme: 20 Ocak 2024, 14:30
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Platform İstatistikleri</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Toplam Kullanıcı:</span>
                        <span className="font-bold">{users.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aktif Abonelik:</span>
                        <span className="font-bold">
                          {users.filter((u) => u.subscriptionActive).length}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Toplam Gelir:</span>
                        <span className="font-bold">
                          $
                          {users
                            .reduce((sum, u) => sum + u.totalEarnings, 0)
                            .toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>MLM Kapasitesi:</span>
                        <span className="font-bold">
                          {(
                            (mlmSettings.activeMembers /
                              mlmSettings.maxTeamSize) *
                            100
                          ).toFixed(2)}
                          %
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ComprehensiveAdminPanel;
