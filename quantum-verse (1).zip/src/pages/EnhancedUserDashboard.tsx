import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import UserNewsFeed from "@/components/UserNewsFeed";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { NEFS_LEVELS } from "@/lib/spiritual";
import {
  User,
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  Share,
  Download,
  MessageSquare,
  Star,
  Crown,
  Copy,
  Check,
  AlertCircle,
  Link as LinkIcon,
  Target,
  Globe,
  Zap,
  Gift,
  Trophy,
  ChevronRight,
  ChevronDown,
  Eye,
  BarChart,
  Smartphone,
} from "lucide-react";

const EnhancedUserDashboard = () => {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [copiedLink, setCopiedLink] = useState(false);
  const [expandedNodes, setExpandedNodes] = useState(new Set());

  if (!user) {
    navigate("/giriş");
    return null;
  }

  const currentLevel = NEFS_LEVELS.find((level) => level.id === user.level);
  const nextLevel = NEFS_LEVELS.find((level) => level.id === user.level + 1);

  const referralLink = `${window.location.origin}/kayıt?sponsor=${user.referralCode}`;
  const clonePageLink = `${window.location.origin}/clone/${user.referralCode}`;

  // Mock team data for demonstration
  const teamData = {
    direct: [
      {
        id: "1",
        name: "Ahmet Yılmaz",
        level: 2,
        teamSize: 8,
        earnings: 350,
        joinDate: "2024-02-15",
        isActive: true,
        children: [
          {
            id: "11",
            name: "Fatma Özkan",
            level: 1,
            teamSize: 3,
            earnings: 120,
            joinDate: "2024-03-01",
            isActive: true,
            children: [],
          },
          {
            id: "12",
            name: "Mehmet Kara",
            level: 1,
            teamSize: 2,
            earnings: 80,
            joinDate: "2024-03-10",
            isActive: true,
            children: [],
          },
        ],
      },
      {
        id: "2",
        name: "Zeynep Türk",
        level: 3,
        teamSize: 15,
        earnings: 650,
        joinDate: "2024-01-20",
        isActive: true,
        children: [
          {
            id: "21",
            name: "Ali Demir",
            level: 2,
            teamSize: 6,
            earnings: 280,
            joinDate: "2024-02-28",
            isActive: true,
            children: [],
          },
        ],
      },
    ],
  };

  const handleCopyLink = async (link: string, type: string) => {
    try {
      await navigator.clipboard.writeText(link);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (err) {
      console.error("Link kopyalanamadı:", err);
    }
  };

  const handleActivateSubscription = (type: "monthly" | "yearly") => {
    updateUser({
      isActive: true,
      subscriptionType: type,
      subscriptionExpiry:
        type === "monthly"
          ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
    });
  };

  const toggleNode = (nodeId: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(nodeId)) {
      newExpanded.delete(nodeId);
    } else {
      newExpanded.add(nodeId);
    }
    setExpandedNodes(newExpanded);
  };

  const renderTeamNode = (member: any, depth = 0) => (
    <div key={member.id} className={`ml-${depth * 4}`}>
      <div className="flex items-center space-x-3 p-3 bg-white/50 rounded-lg border border-gray-200 mb-2">
        <Avatar className="w-8 h-8">
          <AvatarFallback className="text-xs">
            {member.name
              .split(" ")
              .map((n: string) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center space-x-2">
            <span className="font-medium text-sm">{member.name}</span>
            <Badge
              variant={member.level > 2 ? "default" : "secondary"}
              className="text-xs"
            >
              Lv.{member.level}
            </Badge>
            <Badge
              variant={member.isActive ? "default" : "destructive"}
              className="text-xs"
            >
              {member.isActive ? "Aktif" : "Pasif"}
            </Badge>
          </div>
          <div className="flex space-x-4 text-xs text-gray-600">
            <span>{member.teamSize} kişi</span>
            <span>${member.earnings}</span>
            <span>{new Date(member.joinDate).toLocaleDateString("tr-TR")}</span>
          </div>
        </div>
        {member.children.length > 0 && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => toggleNode(member.id)}
          >
            {expandedNodes.has(member.id) ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </Button>
        )}
      </div>
      {expandedNodes.has(member.id) &&
        member.children.map((child: any) => renderTeamNode(child, depth + 1))}
    </div>
  );

  const stats = [
    {
      title: "Toplam Kazanç",
      value: `$${user.totalEarnings.toFixed(2)}`,
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: "+25% bu ay",
    },
    {
      title: "Ekip Büyüklüğü",
      value: user.teamSize.toString(),
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      change: "+5 yeni üye",
    },
    {
      title: "Mevcut Seviye",
      value: `${user.level}/7`,
      icon: Crown,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      change: currentLevel?.name || "",
    },
    {
      title: "Bu Ay Komisyon",
      value: `$${(user.totalEarnings * 0.3).toFixed(2)}`,
      icon: TrendingUp,
      color: "text-spiritual-turquoise-600",
      bgColor: "bg-spiritual-turquoise-50",
      change: "Bu ay kazanç",
    },
  ];

  const achievements = [
    { title: "İlk Üye", completed: true, date: "15 Şubat 2024" },
    { title: "5 Kişilik Ekip", completed: user.teamSize >= 5, date: null },
    { title: "Seviye 2", completed: user.level >= 2, date: null },
    {
      title: "İlk $100 Kazanç",
      completed: user.totalEarnings >= 100,
      date: null,
    },
    { title: "10 Kişilik Ekip", completed: user.teamSize >= 10, date: null },
    { title: "Seviye 3", completed: user.level >= 3, date: null },
  ];

  const quickActions = [
    {
      title: "Ekip Davet Et",
      description: "Yeni üyeleri ekibinize davet edin",
      icon: Users,
      action: () => navigator.clipboard.writeText(referralLink),
      color: "spiritual-turquoise",
    },
    {
      title: "Clone Sayfam",
      description: "Kişisel pazarlama sayfanızı görüntüleyin",
      icon: Globe,
      action: () => window.open(clonePageLink, "_blank"),
      color: "spiritual-purple",
    },
    {
      title: "Kazanç Raporu",
      description: "Detaylı kazanç analizinizi inceleyin",
      icon: BarChart,
      action: () => navigate("/kazançlar"),
      color: "spiritual-gold",
    },
    {
      title: "AI Danışman",
      description: "Yapay zeka destekli rehberlik alın",
      icon: MessageSquare,
      action: () => {},
      color: "green",
    },
  ];

  const progressToNextLevel = nextLevel
    ? Math.min((user.teamSize / 25) * 100, 100)
    : 100;

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Avatar className="w-16 h-16">
                <AvatarFallback className="bg-spiritual-gradient text-white text-xl">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  {user.name}
                </h1>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-2xl">{currentLevel?.emoji}</span>
                  <span className="text-lg text-gray-600">
                    {currentLevel?.name}
                  </span>
                  <Badge
                    variant={user.isActive ? "default" : "destructive"}
                    className="ml-2"
                  >
                    {user.isActive ? "Aktif Üye" : "Pasif Üye"}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Üyelik Tarihi</div>
              <div className="font-medium">
                {new Date(user.joinDate).toLocaleDateString("tr-TR")}
              </div>
            </div>
          </div>

          {/* Subscription Alert */}
          {!user.isActive && (
            <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-lg p-6 mb-6">
              <div className="flex items-center space-x-3 mb-4">
                <AlertCircle className="w-6 h-6 text-orange-600" />
                <h3 className="text-lg font-semibold text-orange-800">
                  Aboneliğinizi Aktifleştirin
                </h3>
              </div>
              <p className="text-orange-700 mb-4">
                Tüm özelliklere erişmek ve kazanç elde etmeye başlamak için
                abonelik planlarından birini seçin.
              </p>
              <div className="flex space-x-3">
                <Button
                  onClick={() => handleActivateSubscription("monthly")}
                  className="bg-orange-600 text-white hover:bg-orange-700"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Aylık $10
                </Button>
                <Button
                  onClick={() => handleActivateSubscription("yearly")}
                  className="bg-spiritual-gradient text-white"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Yıllık $100 (%17 indirim)
                </Button>
              </div>
            </div>
          )}

          {/* Level Progress */}
          {nextLevel && (
            <Card className="bg-gradient-to-r from-spiritual-turquoise-50 to-spiritual-purple-50 border-spiritual-turquoise-200 mb-6">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      Bir Sonraki Seviye: {nextLevel.emoji} {nextLevel.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {nextLevel.requirements}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-spiritual-turquoise-600">
                      {progressToNextLevel.toFixed(0)}%
                    </div>
                    <div className="text-xs text-gray-500">Tamamlandı</div>
                  </div>
                </div>
                <Progress value={progressToNextLevel} className="h-3" />
              </CardContent>
            </Card>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                    <p className="text-xs text-gray-500">{stat.change}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {quickActions.map((action, index) => (
            <Card
              key={index}
              className="bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all duration-200 cursor-pointer group"
              onClick={action.action}
            >
              <CardContent className="p-4 text-center">
                <div className="mb-3">
                  <action.icon
                    className={`w-8 h-8 mx-auto text-${action.color}-600 group-hover:scale-110 transition-transform`}
                  />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  {action.title}
                </h3>
                <p className="text-xs text-gray-600">{action.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="team">Ekibim</TabsTrigger>
            <TabsTrigger value="clone">Clone Sayfa</TabsTrigger>
            <TabsTrigger value="earnings">Kazançlar</TabsTrigger>
            <TabsTrigger value="tools">Araçlar</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* News Feed */}
            <UserNewsFeed />

            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {/* Achievements */}
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Trophy className="w-6 h-6 text-spiritual-gold-600" />
                      <span>Başarılarım</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-3">
                      {achievements.map((achievement, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg border ${
                            achievement.completed
                              ? "bg-green-50 border-green-200"
                              : "bg-gray-50 border-gray-200"
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            {achievement.completed ? (
                              <Check className="w-4 h-4 text-green-600" />
                            ) : (
                              <Target className="w-4 h-4 text-gray-400" />
                            )}
                            <span
                              className={`text-sm font-medium ${
                                achievement.completed
                                  ? "text-green-800"
                                  : "text-gray-600"
                              }`}
                            >
                              {achievement.title}
                            </span>
                          </div>
                          {achievement.date && (
                            <p className="text-xs text-gray-500 mt-1">
                              {achievement.date}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activity */}
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Son Aktiviteler</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 bg-spiritual-turquoise-50 rounded-lg">
                        <Users className="w-4 h-4 text-spiritual-turquoise-600" />
                        <div className="flex-1">
                          <span className="text-sm font-medium">
                            Yeni üye katıldı
                          </span>
                          <p className="text-xs text-gray-500">2 saat önce</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-spiritual-gold-50 rounded-lg">
                        <DollarSign className="w-4 h-4 text-spiritual-gold-600" />
                        <div className="flex-1">
                          <span className="text-sm font-medium">
                            Komisyon kazancı
                          </span>
                          <p className="text-xs text-gray-500">1 gün önce</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-spiritual-purple-50 rounded-lg">
                        <Star className="w-4 h-4 text-spiritual-purple-600" />
                        <div className="flex-1">
                          <span className="text-sm font-medium">
                            Seviye atladınız
                          </span>
                          <p className="text-xs text-gray-500">3 gün önce</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                {/* Current Level Info */}
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Crown className="w-6 h-6 text-spiritual-purple-600" />
                      <span>Mevcut Seviyem</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {currentLevel && (
                      <div className="space-y-4 text-center">
                        <div className="text-4xl mb-2">
                          {currentLevel.emoji}
                        </div>
                        <h3 className="text-lg font-bold text-gray-900">
                          {currentLevel.name}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {currentLevel.description}
                        </p>
                        <div className="space-y-2">
                          <h4 className="font-medium text-gray-900 text-sm">
                            Avantajlarım:
                          </h4>
                          <ul className="space-y-1">
                            {currentLevel.benefits.map((benefit, index) => (
                              <li
                                key={index}
                                className="flex items-center space-x-2 text-xs"
                              >
                                <Check className="w-3 h-3 text-green-500" />
                                <span>{benefit}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Special Offer */}
                <Card className="bg-gradient-to-br from-spiritual-gold-50 to-spiritual-gold-100 border-spiritual-gold-200">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 text-spiritual-gold-700">
                      <Gift className="w-6 h-6" />
                      <span>Özel Fırsat</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center space-y-3">
                      <p className="text-sm text-spiritual-gold-700">
                        Bu hafta 3 yeni üye getirirseniz bonus kazanın!
                      </p>
                      <div className="text-2xl font-bold text-spiritual-gold-800">
                        +$50 Bonus
                      </div>
                      <Button className="w-full bg-spiritual-gold-600 text-white hover:bg-spiritual-gold-700">
                        Detayları Gör
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="team" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span>Ekip Yönetimi</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-spiritual-turquoise-50 rounded-lg">
                      <div className="text-2xl font-bold text-spiritual-turquoise-700">
                        {teamData.direct.length}
                      </div>
                      <div className="text-sm text-spiritual-turquoise-600">
                        Direkt Üye
                      </div>
                    </div>
                    <div className="text-center p-4 bg-spiritual-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-spiritual-purple-700">
                        {user.teamSize}
                      </div>
                      <div className="text-sm text-spiritual-purple-600">
                        Toplam Ekip
                      </div>
                    </div>
                    <div className="text-center p-4 bg-spiritual-gold-50 rounded-lg">
                      <div className="text-2xl font-bold text-spiritual-gold-700">
                        ${user.totalEarnings.toFixed(0)}
                      </div>
                      <div className="text-sm text-spiritual-gold-600">
                        Toplam Kazanç
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-semibold text-gray-900 mb-4">
                      Ekip Ağacı
                    </h3>
                    {teamData.direct.map((member) => renderTeamNode(member))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="clone" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="w-6 h-6 text-spiritual-purple-600" />
                  <span>Kişisel Clone Sayfam</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-spiritual-purple-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-spiritual-purple-700 mb-2">
                    Clone Sayfa Nedir?
                  </h3>
                  <p className="text-spiritual-purple-600 text-sm">
                    Size özel tasarlanmış pazarlama sayfanız. Bu sayfayı
                    paylaşarak yeni üyeler kazanabilir ve ekibinizi
                    büyütebilirsiniz.
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">
                      Clone Sayfa Linkiniz:
                    </Label>
                    <div className="flex space-x-2 mt-1">
                      <input
                        type="text"
                        value={clonePageLink}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                      />
                      <Button
                        onClick={() => handleCopyLink(clonePageLink, "clone")}
                        variant="outline"
                        size="sm"
                      >
                        {copiedLink ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700">
                      Kayıt Linkiniz:
                    </Label>
                    <div className="flex space-x-2 mt-1">
                      <input
                        type="text"
                        value={referralLink}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                      />
                      <Button
                        onClick={() => handleCopyLink(referralLink, "referral")}
                        variant="outline"
                        size="sm"
                      >
                        {copiedLink ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <Button
                    onClick={() => window.open(clonePageLink, "_blank")}
                    className="bg-spiritual-gradient text-white"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Clone Sayfayı Görüntüle
                  </Button>
                  <Button variant="outline">
                    <Smartphone className="w-4 h-4 mr-2" />
                    QR Kod Oluştur
                  </Button>
                </div>

                <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-spiritual-turquoise-700 mb-2">
                    📱 Sosyal Medya Paylaşımı
                  </h4>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm">
                      WhatsApp
                    </Button>
                    <Button variant="outline" size="sm">
                      Facebook
                    </Button>
                    <Button variant="outline" size="sm">
                      Instagram
                    </Button>
                    <Button variant="outline" size="sm">
                      Twitter
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="earnings" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <DollarSign className="w-6 h-6 text-green-600" />
                    <span>Kazanç Dağılımı</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-green-50 rounded-lg">
                        <div className="text-xl font-bold text-green-700">
                          ${(user.totalEarnings * 0.6).toFixed(2)}
                        </div>
                        <div className="text-xs text-green-600">Sponsor</div>
                      </div>
                      <div className="text-center p-3 bg-blue-50 rounded-lg">
                        <div className="text-xl font-bold text-blue-700">
                          ${(user.totalEarnings * 0.25).toFixed(2)}
                        </div>
                        <div className="text-xs text-blue-600">Eşleşme</div>
                      </div>
                      <div className="text-center p-3 bg-purple-50 rounded-lg">
                        <div className="text-xl font-bold text-purple-700">
                          ${(user.totalEarnings * 0.15).toFixed(2)}
                        </div>
                        <div className="text-xs text-purple-600">Satış</div>
                      </div>
                      <div className="text-center p-3 bg-spiritual-gold-50 rounded-lg">
                        <div className="text-xl font-bold text-spiritual-gold-700">
                          ${(user.totalEarnings * 0.1).toFixed(2)}
                        </div>
                        <div className="text-xs text-spiritual-gold-600">
                          Bonus
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Son Kazançlar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <span className="text-sm">Sponsor Komisyonu</span>
                      <span className="font-medium text-green-600">+$25</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <span className="text-sm">Eşleşme Bonusu</span>
                      <span className="font-medium text-blue-600">+$15</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <span className="text-sm">Satış Komisyonu</span>
                      <span className="font-medium text-purple-600">+$10</span>
                    </div>
                    <Button variant="outline" className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Detaylı Rapor İndir
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Download className="w-6 h-6 text-spiritual-turquoise-600" />
                    <span>Pazarlama Araçları</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    MLM Sunumu İndir
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Sosyal Medya Görselleri
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    E-mail Şablonları
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Video Tanıtımları
                  </Button>
                  {!user.isActive && (
                    <p className="text-xs text-gray-500 text-center">
                      Abonelik aktivasyonu sonrası erişilebilir
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="w-6 h-6 text-spiritual-purple-600" />
                    <span>AI Destek Sistemi</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600">
                    Yapay zeka destekli rehberlik sistemi ile 7/24 destek alın.
                  </p>
                  <Button
                    className="w-full bg-spiritual-gradient text-white"
                    disabled={!user.isActive}
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    AI Sohbet Başlat
                  </Button>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div>• Pazarlama stratejileri</div>
                    <div>• Ekip yönetimi ipuçları</div>
                    <div>• Satış teknikleri</div>
                    <div>• Kişisel gelişim önerileri</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default EnhancedUserDashboard;
