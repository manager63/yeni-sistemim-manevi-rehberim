import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ShoppingCart,
  Heart,
  Star,
  Search,
  Filter,
  BookOpen,
  Music,
  Target,
  Gift,
  Play,
  Download,
  Package,
  CreditCard,
  AlertCircle,
  Lock,
  CheckCircle,
  Crown,
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
  digital: boolean;
  memberOnly: boolean;
  inStock: boolean;
  tags: string[];
}

const SpiritualProducts = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [cart, setCart] = useState<number[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);

  const products: Product[] = [
    // Kitaplar
    {
      id: 1,
      name: "Kur'an-ı Kerim - Özel Cilt",
      description:
        "Altın varaklı, el sanatı ciltli Kur'an-ı Kerim. Özel kasa hediyeli.",
      price: 299,
      originalPrice: 399,
      category: "books",
      image: "/api/placeholder/300/400",
      rating: 4.9,
      reviews: 284,
      digital: false,
      memberOnly: false,
      inStock: true,
      tags: ["kuran", "kitap", "hediye", "özel"],
    },
    {
      id: 2,
      name: "Esma-ül Hüsna Şerhi",
      description:
        "Allah'ın 99 isminin detaylı açıklaması ve manevi faydaları.",
      price: 89,
      category: "books",
      image: "/api/placeholder/300/400",
      rating: 4.8,
      reviews: 156,
      digital: false,
      memberOnly: true,
      inStock: true,
      tags: ["esma", "şerh", "dua"],
    },
    {
      id: 3,
      name: "Tasavvuf Klasikleri Seti",
      description:
        "Mevlana, Yunus Emre ve diğer büyük mutasavvıfların eserleri. 5 kitap set.",
      price: 199,
      originalPrice: 250,
      category: "books",
      image: "/api/placeholder/300/400",
      rating: 4.7,
      reviews: 98,
      digital: false,
      memberOnly: true,
      inStock: true,
      tags: ["tasavvuf", "set", "klasik"],
    },
    {
      id: 4,
      name: "Günlük Dua ve Zikir Rehberi",
      description:
        "Sabah, öğle, akşam duaları ve zikir programları. Pratik kullanım.",
      price: 59,
      category: "books",
      image: "/api/placeholder/300/400",
      rating: 4.6,
      reviews: 234,
      digital: true,
      memberOnly: false,
      inStock: true,
      tags: ["dua", "zikir", "günlük"],
    },

    // Ses Kayıtları
    {
      id: 5,
      name: "Kur'an Tilaveti - Hafız Ahmed",
      description:
        "Tecvid kurallarına uygun, huzur verici Kur'an tilaveti. 30 Cüz tam kayıt.",
      price: 149,
      category: "audio",
      image: "/api/placeholder/300/400",
      rating: 4.9,
      reviews: 445,
      digital: true,
      memberOnly: false,
      inStock: true,
      tags: ["kuran", "tilawet", "tecvid"],
    },
    {
      id: 6,
      name: "Zikir Meditasyonu Rehberi",
      description:
        "Eşlilik sesleriyle zikir meditasyonu. Nefes teknikleri dahil.",
      price: 79,
      category: "audio",
      image: "/api/placeholder/300/400",
      rating: 4.8,
      reviews: 167,
      digital: true,
      memberOnly: true,
      inStock: true,
      tags: ["zikir", "meditasyon", "rehber"],
    },
    {
      id: 7,
      name: "Dua ve İlahi Koleksiyonu",
      description:
        "En güzel dualar ve ilahiler. Kalbi rahatlatıcı etkili müzik.",
      price: 99,
      category: "audio",
      image: "/api/placeholder/300/400",
      rating: 4.7,
      reviews: 289,
      digital: true,
      memberOnly: false,
      inStock: true,
      tags: ["dua", "ilahi", "koleksiyon"],
    },

    // İbadet Malzemeleri
    {
      id: 8,
      name: "Premium Dua Seccadesi",
      description:
        "El dokuması, kaliteli iplik seccade. Kıble pusulaslı, taşıma çantalı.",
      price: 189,
      originalPrice: 229,
      category: "prayer",
      image: "/api/placeholder/300/400",
      rating: 4.8,
      reviews: 178,
      digital: false,
      memberOnly: false,
      inStock: true,
      tags: ["seccade", "dua", "premium"],
    },
    {
      id: 9,
      name: "Ağaç Tesbih - 99 Taneli",
      description: "Doğal ağaç, el işçiliği tesbih. Zikir sayacı özellikli.",
      price: 69,
      category: "prayer",
      image: "/api/placeholder/300/400",
      rating: 4.6,
      reviews: 234,
      digital: false,
      memberOnly: false,
      inStock: true,
      tags: ["tesbih", "ağaç", "zikir"],
    },
    {
      id: 10,
      name: "Misvak Seti",
      description:
        "Doğal misvak çubukları ve özel saklama kabı. Sünnet ibadet.",
      price: 39,
      category: "prayer",
      image: "/api/placeholder/300/400",
      rating: 4.5,
      reviews: 156,
      digital: false,
      memberOnly: false,
      inStock: true,
      tags: ["misvak", "sünnet", "doğal"],
    },

    // Dijital İçerik
    {
      id: 11,
      name: "İslami Yaşam Koçluğu Kursu",
      description:
        "20 saatlik video eğitim serisi. Kişisel gelişim ve maneviyat.",
      price: 299,
      originalPrice: 399,
      category: "digital",
      image: "/api/placeholder/300/400",
      rating: 4.9,
      reviews: 67,
      digital: true,
      memberOnly: true,
      inStock: true,
      tags: ["eğitim", "kurs", "koçluk"],
    },
    {
      id: 12,
      name: "Dua Uygulaması Premium",
      description:
        "Günlük dualar, hatırlatıcılar, kişisel dua günlüğü. Mobil uygulama.",
      price: 49,
      category: "digital",
      image: "/api/placeholder/300/400",
      rating: 4.7,
      reviews: 789,
      digital: true,
      memberOnly: false,
      inStock: true,
      tags: ["uygulama", "dua", "premium"],
    },

    // Hediye Setleri
    {
      id: 13,
      name: "Yeni Müslüman Hediye Seti",
      description:
        "Kur'an, seccade, tesbih, dua kitabı ve rehber kitap. Özel kutu.",
      price: 249,
      originalPrice: 319,
      category: "gifts",
      image: "/api/placeholder/300/400",
      rating: 4.8,
      reviews: 89,
      digital: false,
      memberOnly: false,
      inStock: true,
      tags: ["hediye", "set", "yeni müslüman"],
    },
    {
      id: 14,
      name: "Evlilik Hediye Seti",
      description:
        "Çift seccade, aile duaları kitabı, bereket duası yazılı tablo.",
      price: 199,
      category: "gifts",
      image: "/api/placeholder/300/400",
      rating: 4.6,
      reviews: 123,
      digital: false,
      memberOnly: false,
      inStock: true,
      tags: ["hediye", "evlilik", "aile"],
    },

    // Meditasyon Araçları
    {
      id: 15,
      name: "Zikir Meditasyon Minderi",
      description:
        "Ergonomik tasarım, rahat minder. Meditasyon ve ibadet için ideal.",
      price: 129,
      category: "meditation",
      image: "/api/placeholder/300/400",
      rating: 4.7,
      reviews: 145,
      digital: false,
      memberOnly: true,
      inStock: true,
      tags: ["minder", "meditasyon", "zikir"],
    },
    {
      id: 16,
      name: "Manevi Müzik Koleksiyonu",
      description:
        "Huzur verici enstrümantal müzikler. Meditasyon ve dinlenme için.",
      price: 89,
      category: "meditation",
      image: "/api/placeholder/300/400",
      rating: 4.5,
      reviews: 178,
      digital: true,
      memberOnly: false,
      inStock: true,
      tags: ["müzik", "meditasyon", "huzur"],
    },
  ];

  const categories = [
    { id: "all", name: "Tüm Ürünler", icon: Package },
    { id: "books", name: "Kitaplar", icon: BookOpen },
    { id: "audio", name: "Ses Kayıtları", icon: Music },
    { id: "prayer", name: "İbadet Malzemeleri", icon: Target },
    { id: "digital", name: "Dijital İçerik", icon: Download },
    { id: "gifts", name: "Hediye Setleri", icon: Gift },
    { id: "meditation", name: "Meditasyon", icon: Play },
  ];

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.tags.some((tag) =>
        tag.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    const matchesCategory =
      selectedCategory === "all" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const addToCart = (productId: number) => {
    if (!cart.includes(productId)) {
      setCart([...cart, productId]);
    }
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter((id) => id !== productId));
  };

  const toggleWishlist = (productId: number) => {
    if (wishlist.includes(productId)) {
      setWishlist(wishlist.filter((id) => id !== productId));
    } else {
      setWishlist([...wishlist, productId]);
    }
  };

  const ProductCard = ({ product }: { product: Product }) => {
    const isInCart = cart.includes(product.id);
    const isInWishlist = wishlist.includes(product.id);
    const canPurchase =
      !product.memberOnly || (user && user.subscriptionActive);

    return (
      <Card className="group hover:shadow-lg transition-all duration-300 border-spiritual-turquoise-100">
        <CardHeader className="p-0">
          <div className="relative">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover rounded-t-lg"
            />
            {product.originalPrice && (
              <Badge className="absolute top-2 left-2 bg-spiritual-gold-500 text-white">
                %{Math.round((1 - product.price / product.originalPrice) * 100)}{" "}
                İndirim
              </Badge>
            )}
            {product.digital && (
              <Badge className="absolute top-2 right-2 bg-spiritual-purple-500 text-white">
                <Download className="w-3 h-3 mr-1" />
                Dijital
              </Badge>
            )}
            {product.memberOnly && (
              <Badge className="absolute bottom-2 left-2 bg-spiritual-turquoise-500 text-white">
                <Lock className="w-3 h-3 mr-1" />
                Üye Özel
              </Badge>
            )}
            <Button
              variant="ghost"
              size="sm"
              className={`absolute bottom-2 right-2 ${isInWishlist ? "text-red-500" : "text-gray-500"} hover:text-red-500`}
              onClick={() => toggleWishlist(product.id)}
            >
              <Heart
                className={`w-4 h-4 ${isInWishlist ? "fill-current" : ""}`}
              />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-semibold text-sm line-clamp-2">
              {product.name}
            </h3>
          </div>
          <p className="text-gray-600 text-xs mb-3 line-clamp-2">
            {product.description}
          </p>

          <div className="flex items-center mb-3">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                />
              ))}
            </div>
            <span className="text-xs text-gray-500 ml-2">
              ({product.reviews})
            </span>
          </div>

          <div className="flex flex-wrap gap-1 mb-3">
            {product.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>

          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-spiritual-turquoise-600">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-gray-500 line-through">
                  ${product.originalPrice}
                </span>
              )}
            </div>
            {product.inStock ? (
              <Badge
                variant="outline"
                className="text-green-600 border-green-200"
              >
                <CheckCircle className="w-3 h-3 mr-1" />
                Stokta
              </Badge>
            ) : (
              <Badge variant="outline" className="text-red-600 border-red-200">
                <AlertCircle className="w-3 h-3 mr-1" />
                Tükendi
              </Badge>
            )}
          </div>

          {!canPurchase ? (
            <div className="text-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <Lock className="w-4 h-4 mx-auto mb-1 text-yellow-600" />
              <p className="text-xs text-yellow-700">
                Üye olarak satın alabilirsiniz
              </p>
              <Button size="sm" variant="outline" className="mt-2 text-xs">
                Üye Ol - $10/ay
              </Button>
            </div>
          ) : (
            <div className="flex space-x-2">
              {isInCart ? (
                <Button
                  onClick={() => removeFromCart(product.id)}
                  className="flex-1 bg-red-500 hover:bg-red-600 text-white text-xs"
                  size="sm"
                >
                  Sepetten Çıkar
                </Button>
              ) : (
                <Button
                  onClick={() => addToCart(product.id)}
                  className="flex-1 bg-spiritual-gradient text-white text-xs"
                  size="sm"
                  disabled={!product.inStock}
                >
                  <ShoppingCart className="w-3 h-3 mr-1" />
                  Sepete Ekle
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Manevi Ürünler
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ruhsal gelişiminizi destekleyecek kitaplar, ses kayıtları, ibadet
            malzemeleri ve dijital içerikler
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-spiritual-turquoise-200 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Ürün ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select
              value={selectedCategory}
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Kategori seç" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    <div className="flex items-center">
                      <category.icon className="w-4 h-4 mr-2" />
                      {category.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <div className="bg-spiritual-turquoise-50 border border-spiritual-turquoise-200 rounded-lg p-4 mb-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <ShoppingCart className="w-5 h-5 text-spiritual-turquoise-600 mr-2" />
                <span className="font-medium text-spiritual-turquoise-700">
                  Sepetinizde {cart.length} ürün
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-spiritual-turquoise-700">
                  Toplam: $
                  {products
                    .filter((p) => cart.includes(p.id))
                    .reduce((sum, p) => sum + p.price, 0)}
                </span>
                <Button className="bg-spiritual-gradient text-white">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Sepeti Onayla
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Category Tabs */}
        <Tabs
          value={selectedCategory}
          onValueChange={setSelectedCategory}
          className="mb-8"
        >
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-7 bg-white/80">
            {categories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="flex items-center space-x-1 text-xs md:text-sm"
              >
                <category.icon className="w-3 h-3 md:w-4 md:h-4" />
                <span className="hidden md:inline">{category.name}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* No Results */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              Ürün bulunamadı
            </h3>
            <p className="text-gray-500">
              Arama kriterlerinizi değiştirmeyi deneyin
            </p>
          </div>
        )}

        {/* Membership Benefits */}
        {!user?.subscriptionActive && (
          <div className="bg-spiritual-gradient rounded-2xl p-8 text-white text-center mt-12">
            <Crown className="w-12 h-12 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-4">Üye Avantajları</h3>
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              <div>
                <Lock className="w-8 h-8 mx-auto mb-2" />
                <h4 className="font-semibold mb-2">Özel Ürünlere Erişim</h4>
                <p className="text-sm opacity-90">
                  Sadece üyelere özel ürünleri satın alabilirsiniz
                </p>
              </div>
              <div>
                <Star className="w-8 h-8 mx-auto mb-2" />
                <h4 className="font-semibold mb-2">Özel İndirimler</h4>
                <p className="text-sm opacity-90">
                  Üyelere özel %15-30 indirimler
                </p>
              </div>
              <div>
                <Gift className="w-8 h-8 mx-auto mb-2" />
                <h4 className="font-semibold mb-2">Aylık Hediyeler</h4>
                <p className="text-sm opacity-90">
                  Her ay özel dijital hediyeler
                </p>
              </div>
            </div>
            <Button className="bg-white text-spiritual-turquoise-600 hover:bg-gray-100">
              Üye Ol - Sadece $10/ay
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SpiritualProducts;
