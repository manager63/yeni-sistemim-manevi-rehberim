import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Star,
  Heart,
  Users,
  DollarSign,
  Crown,
  Gift,
  Target,
  TrendingUp,
  Shield,
  Clock,
  CheckCircle,
  Lock,
  Zap,
  Globe,
  MessageSquare,
  BookOpen,
  Award,
  Sparkles,
  ArrowRight,
  Play,
  Download,
  Share2,
  Eye,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Coffee,
  Sunrise,
  Moon,
  Compass,
  Flame,
  Leaf,
  Flower,
  Sun,
} from "lucide-react";

const EnhancedClonePage = () => {
  const { referralCode } = useParams();
  const navigate = useNavigate();
  const [pageViews, setPageViews] = useState(0);
  const [isRegistering, setIsRegistering] = useState(false);

  // Mock sponsor data
  const sponsorInfo = {
    name: "Ayşe Yılmaz",
    title: "Manevi Gelişim Uzmanı",
    level: 5,
    levelName: "Nefs-i Râziye",
    levelEmoji: "🌸",
    joinDate: "2023-06-15",
    totalTeam: 147,
    achievements: ["Top Sponsor", "Manevi Rehber", "Topluluk Lideri"],
    message: "Size bu manevi yolculukta rehberlik etmekten onur duyarım.",
    photo: "/images/avatar-sponsor.jpg",
  };

  // Comprehensive spiritual content from research
  const spiritualContent = {
    dhikr: {
      title: "Dhikr (Zikir) - Allah'ı Anma",
      icon: "🕌",
      description:
        "İslami meditasyonun kalbi olan zikir, Allah'ın isimlerini ve sıfatlarını tekrarlayarak kalp huzuru ve manevi güç elde etme sanatıdır.",
      benefits: [
        "Kalp huzuru ve iç rahatlık",
        "Manevi güç ve dirençlilik",
        "Stres ve anksiyetenin azalması",
        "Allah ile derin bağlantı",
        "Günlük mindfulness pratiği",
      ],
      practices: [
        { text: "Subhanallah", count: 33, meaning: "Allah'ı tesbih ederim" },
        { text: "Alhamdulillah", count: 33, meaning: "Hamdolsun Allah'a" },
        { text: "Allahu Akbar", count: 34, meaning: "Allah en büyüktür" },
        {
          text: "La ilaha illallah",
          count: 100,
          meaning: "Allah'tan başka ilah yoktur",
        },
      ],
    },
    tafakkur: {
      title: "Tafakkur (Tefekkür) - Derin Düşünce",
      icon: "🧠",
      description:
        "Kur'an ayetleri ve yaratılış üzerine derin düşünce yaparak divine hikmet ve kişisel amaç keşfi.",
      benefits: [
        "Hikmet ve anlayış kazanma",
        "Manevi derinlik geliştirme",
        "Hayatın anlamını keşfetme",
        "Farkındalık artışı",
        "İçsel sorgulama becerisi",
      ],
      topics: [
        "Kur'an ayetleri üzerine düşünme",
        "Yaratılışın mucizelerini gözlemleme",
        "İnsan doğası ve amacı",
        "Ölüm ve ahiret farkındalığı",
        "Allah'ın sıfatları ve isimleri",
      ],
    },
    tazkiyah: {
      title: "Tazkiyah (Nefis Temizliği) - Ruh Arındırma",
      icon: "✨",
      description:
        "Nefsi kötü sıfatlardan arındırma ve güzel ahlak kazanma süreci.",
      benefits: [
        "Karakter gelişimi ve olgunlaşma",
        "Ruhsal arınma ve temizlik",
        "Ahlaki mükemmellik",
        "İç barış ve denge",
        "Manevi yükselme",
      ],
      practices: [
        "Nefis muhasebesi (günlük öz değerlendirme)",
        "Düzenli dua ve istiğfar",
        "Sadaka ve yardımseverlik",
        "Sabır ve şükür pratiği",
        "Kötü alışkanlıkları terk etme",
      ],
    },
  };

  const lifeCoachingServices = [
    {
      name: "Bireysel Manevi Koçluk",
      duration: "60 dakika",
      price: 150,
      originalPrice: 200,
      description:
        "İslami değerlerle desteklenen kişisel gelişim ve hedef belirleme",
      features: [
        "Kişisel manevi değerlendirme",
        "İslami perspektifle hedef belirleme",
        "Detaylı eylem planı oluşturma",
        "Haftalık ilerleme takibi",
        "Dua ve zikir programı",
      ],
      icon: Target,
    },
    {
      name: "Aile ve İlişki Danışmanlığı",
      duration: "90 dakika",
      price: 200,
      originalPrice: 250,
      description: "İslami aile yapısı ve sağlıklı ilişkiler kurma",
      features: [
        "İslami aile değerleri rehberliği",
        "İletişim becerileri geliştirme",
        "Çatışma çözümleme teknikleri",
        "Evlilik öncesi danışmanlık",
        "Ebeveynlik koçluğu",
      ],
      icon: Heart,
    },
    {
      name: "Kariyer ve Helal Kazanç Rehberliği",
      duration: "75 dakika",
      price: 175,
      originalPrice: 225,
      description: "İslami prensipler çerçevesinde kariyer planlama",
      features: [
        "Helal kazanç yolları keşfi",
        "İş-yaşam-ibadet dengesi",
        "Profesyonel gelişim planı",
        "Ticaret ahlakı eğitimi",
        "Girişimcilik rehberliği",
      ],
      icon: TrendingUp,
    },
  ];

  const spiritualPackages = [
    {
      name: "Temel Manevi Paket",
      price: 99,
      originalPrice: 149,
      duration: "1 ay",
      level: "Başlangıç",
      color: "bg-green-50 border-green-200",
      features: [
        "Günlük dua ve zikir rehberi",
        "Haftalık manevi sohbet",
        "Temel İslami meditasyon",
        "Kişisel manevi plan",
        "WhatsApp destek grubu",
      ],
    },
    {
      name: "Premium Manevi Paket",
      price: 249,
      originalPrice: 349,
      duration: "3 ay",
      level: "Orta Seviye",
      color: "bg-blue-50 border-blue-200",
      popular: true,
      features: [
        "Kişiselleştirilmiş dua programı",
        "Haftalık canlı zikir seansları",
        "Aylık özel manevi danışmanlık",
        "Rüya tabiri hizmeti",
        "Detaylı manevi gelişim raporu",
        "Özel WhatsApp desteği",
      ],
    },
    {
      name: "VIP Manevi Transformasyon",
      price: 599,
      originalPrice: 899,
      duration: "6 ay",
      level: "İleri Seviye",
      color: "bg-purple-50 border-purple-200",
      features: [
        "7/24 kişisel manevi danışman",
        "Haftalık birebir koçluk seansları",
        "Aylık manevi retreat katılımı",
        "Özel dua ve zikir programı",
        "Aile manevi danışmanlığı",
        "Hac/umre manevi hazırlık",
        "Yıllık manevi gelişim planı",
      ],
    },
  ];

  const nefsLevels = [
    {
      id: 1,
      name: "Nefs-i Emmare",
      emoji: "🌿",
      description: "Kötülüğü emreden nefis - Başlangıç seviyesi",
      teamRequirement: "0 kişi",
      benefits: ["Sisteme giriş", "Temel rehberlik"],
    },
    {
      id: 2,
      name: "Nefs-i Levvame",
      emoji: "🌱",
      description: "Kendini kınayan nefis - Vicdan uyanması",
      teamRequirement: "3 kişi",
      benefits: ["%5 komisyon", "Manevi sohbet erişimi"],
    },
    {
      id: 3,
      name: "Nefs-i Mülhime",
      emoji: "🌾",
      description: "İlham alan nefis - Ruhsal yükseliş",
      teamRequirement: "10 kişi",
      benefits: ["% 10 komisyon", "Özel eğitimlere erişim"],
    },
    {
      id: 4,
      name: "Nefs-i Mutmainne",
      emoji: "🌼",
      description: "Huzurlu nefis - Kalp huzuru",
      teamRequirement: "25 kişi",
      benefits: ["% 15 komisyon", "VIP etkinlik erişimi"],
    },
    {
      id: 5,
      name: "Nefs-i Râziye",
      emoji: "🌸",
      description: "Razı olan nefis - Teslimiyet",
      teamRequirement: "50 kişi",
      benefits: ["% 20 komisyon", "Liderlik programı"],
    },
    {
      id: 6,
      name: "Nefs-i Mardiyye",
      emoji: "🌷",
      description: "Rıza görülen nefis - Manevi olgunluk",
      teamRequirement: "100 kişi",
      benefits: ["% 25 komisyon", "Mentor statüsü"],
    },
    {
      id: 7,
      name: "Nefs-i Kâmile",
      emoji: "🌺",
      description: "Mükemmel nefis - En yüce seviye",
      teamRequirement: "250+ kişi",
      benefits: ["% 30 komisyon", "Sürekli gelir garantisi"],
    },
  ];

  const testimonials = [
    {
      name: "Fatma Özkan",
      location: "İstanbul",
      level: "Nefs-i Mutmainne",
      text: "Bu platform sayesinde hem maneviyatımı geliştirdim hem de aileme ek gelir sağladım. Çok şükür!",
      rating: 5,
      earnings: 850,
      duration: "8 ay",
    },
    {
      name: "Ahmet Demir",
      location: "Ankara",
      level: "Nefs-i Râziye",
      text: "İslami değerlerle uyumlu bir iş modeli. Vicdanım rahat şekilde kazanç elde ediyorum.",
      rating: 5,
      earnings: 1200,
      duration: "1 yıl",
    },
    {
      name: "Zeynep Kaya",
      location: "İzmir",
      level: "Nefs-i Mülhime",
      text: "Yaşam koçluğu hizmetleri gerçekten kaliteli. Hayatımda büyük değişiklikler yaşadım.",
      rating: 5,
      earnings: 650,
      duration: "6 ay",
    },
  ];

  const features = [
    {
      icon: Heart,
      title: "İslami Manevi Gelişim",
      description:
        "Kur'an ve Sünnet rehberliğinde ruhsal arınma ve gelişim programları",
      color: "text-red-500",
    },
    {
      icon: DollarSign,
      title: "7 Seviye Kazanç Sistemi",
      description:
        "Nefs mertebeleri ile yükselen gelir imkanı - %5'ten %30'a kadar komisyon",
      color: "text-green-500",
    },
    {
      icon: Users,
      title: "Güçlü Manevi Topluluk",
      description:
        "İslami değerleri paylaşan, birbirini destekleyen büyük aile",
      color: "text-blue-500",
    },
    {
      icon: BookOpen,
      title: "Sürekli Manevi Eğitim",
      description: "Yaşam koçluğu, dua, zikir ve İslami yaşam rehberliği",
      color: "text-purple-500",
    },
    {
      icon: Globe,
      title: "Kişisel Clone Sayfanız",
      description: "Size özel tasarlanmış profesyonel pazarlama sayfası",
      color: "text-indigo-500",
    },
    {
      icon: Shield,
      title: "24/7 Manevi Destek",
      description:
        "İhtiyacınız olduğunda yanınızda olan manevi rehberlik sistemi",
      color: "text-orange-500",
    },
  ];

  useEffect(() => {
    // Track page view
    setPageViews((prev) => prev + 1);
    // In real app, send to analytics
  }, []);

  const handleJoinClick = () => {
    setIsRegistering(true);
    navigate(`/kayıt?sponsor=${referralCode}`);
  };

  const currentLevel =
    nefsLevels.find((level) => level.id === sponsorInfo.level) || nefsLevels[0];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-spiritual-gradient text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="text-center space-y-8">
            {/* Sponsor Info */}
            <div className="flex justify-center mb-8">
              <Card className="bg-white/90 backdrop-blur-sm border-0 max-w-md">
                <CardContent className="p-6 text-center">
                  <Avatar className="w-16 h-16 mx-auto mb-4">
                    <AvatarFallback className="bg-spiritual-gradient text-white text-xl">
                      {sponsorInfo.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {sponsorInfo.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-2">
                    {sponsorInfo.title}
                  </p>
                  <div className="flex items-center justify-center space-x-2 mb-3">
                    <span className="text-2xl">{currentLevel.emoji}</span>
                    <Badge className="bg-spiritual-gradient text-white">
                      {currentLevel.name}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500 italic">
                    "{sponsorInfo.message}"
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold">
                Manevi Gelişim ve Kazanç Fırsatı
              </h1>
              <p className="text-xl md:text-2xl max-w-4xl mx-auto leading-relaxed">
                İslami değerlerle hem ruhsal gelişiminizi hem de mali
                kazancınızı artırın. 7 seviyeli nefs mertebeleri sistemi ile
                manevi yolculuğunuzda ilerleyin.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  size="lg"
                  onClick={handleJoinClick}
                  className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
                >
                  <Zap className="w-5 h-5 mr-2" />
                  Hemen Katıl - Sadece $10/ay
                </Button>
                <div className="text-sm">
                  <div className="flex items-center space-x-2">
                    <Eye className="w-4 h-4" />
                    <span>{pageViews + 1247} kişi bu sayfayı görüntüledi</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Alert for Non-Members */}
      <section className="py-4 bg-orange-50 border-b border-orange-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Alert className="border-orange-200 bg-orange-50">
            <Lock className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <strong>Bilgi:</strong> Bu sayfada yer alan tüm hizmetleri ve
              özellikleri görebilir, ancak üye olmadan ve ödeme yapmadan aktif
              olarak kullanamayacağınızı lütfen unutmayın. Sadece{" "}
              <strong>$10/ay</strong> ile tüm avantajlardan yararlanabilirsiniz.
            </AlertDescription>
          </Alert>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="spiritual">Manevi Gelişim</TabsTrigger>
            <TabsTrigger value="coaching">Yaşam Koçluğu</TabsTrigger>
            <TabsTrigger value="packages">Paketler</TabsTrigger>
            <TabsTrigger value="levels">Seviyeler</TabsTrigger>
            <TabsTrigger value="testimonials">Deneyimler</TabsTrigger>
          </TabsList>

          {/* Overview */}
          <TabsContent value="overview" className="space-y-12">
            {/* Features Grid */}
            <section>
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                  Platform{" "}
                  <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                    Özellikleri
                  </span>
                </h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                  Manevi gelişiminiz ve mali kazancınız için ihtiyacınız olan
                  her şey
                </p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {features.map((feature, index) => (
                  <Card
                    key={index}
                    className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 group"
                  >
                    <CardContent className="p-6 text-center">
                      <div className="mb-4">
                        <feature.icon
                          className={`w-12 h-12 mx-auto ${feature.color} group-hover:scale-110 transition-transform duration-200`}
                        />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-gray-600 text-sm">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Benefits Section */}
            <section className="bg-spiritual-turquoise-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-center text-spiritual-turquoise-800 mb-8">
                Neden Bu Platforma Katılmalısınız?
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  "Aylık sadece $10 ile başlayın",
                  "7 seviye derinliğinde komisyon kazancı",
                  "Size özel clone pazarlama sayfası",
                  "24/7 manevi destek ve rehberlik",
                  "İslami yaşam koçluğu hizmetleri",
                  "Esnek çalışma saatleri",
                  "Güvenilir helal kazanç modeli",
                  "Güçlü topluluk desteği",
                  "Sürekli eğitim ve gelişim",
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-spiritual-turquoise-600 flex-shrink-0" />
                    <span className="text-spiritual-turquoise-700">
                      {benefit}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          </TabsContent>

          {/* Spiritual Development */}
          <TabsContent value="spiritual" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                  Manevi Gelişim
                </span>{" "}
                Programları
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                İslami ilkelerle desteklenen ruhsal büyüme yolculuğu. Kur'an ve
                Sünnet rehberliğinde kendinizi geliştirin.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {Object.values(spiritualContent).map((content, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <span className="text-3xl">{content.icon}</span>
                      <span className="text-lg">{content.title}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {content.description}
                    </p>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Faydaları:
                      </h4>
                      <ul className="space-y-1">
                        {content.benefits.map((benefit, benefitIndex) => (
                          <li
                            key={benefitIndex}
                            className="flex items-center space-x-2 text-sm"
                          >
                            <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {content.practices && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">
                          Pratikler:
                        </h4>
                        <div className="space-y-2">
                          {content.practices.map((practice, practiceIndex) => (
                            <div
                              key={practiceIndex}
                              className="bg-spiritual-turquoise-50 p-2 rounded text-xs"
                            >
                              <span className="font-medium">
                                {practice.text}
                              </span>
                              {practice.count && (
                                <span className="text-gray-500">
                                  {" "}
                                  ({practice.count}x)
                                </span>
                              )}
                              {practice.meaning && (
                                <div className="text-gray-600 italic">
                                  {practice.meaning}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {content.topics && (
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">
                          Konular:
                        </h4>
                        <ul className="space-y-1">
                          {content.topics.map((topic, topicIndex) => (
                            <li
                              key={topicIndex}
                              className="text-xs text-gray-600"
                            >
                              • {topic}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="bg-orange-50 border border-orange-200 rounded p-3">
                      <div className="flex items-center space-x-2 text-orange-700">
                        <Lock className="w-4 h-4" />
                        <span className="text-xs font-medium">
                          Üyelik Gerekli
                        </span>
                      </div>
                      <p className="text-xs text-orange-600 mt-1">
                        Bu içeriğe erişim için aylık $10 abonelik gereklidir.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Life Coaching */}
          <TabsContent value="coaching" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                  Yaşam Koçluğu
                </span>{" "}
                Hizmetleri
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                İslami değerlerle desteklenen profesyonel yaşam danışmanlığı.
                Uzman koçlarımızla hayatınızı dönüştürün.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {lifeCoachingServices.map((service, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 relative"
                >
                  {service.originalPrice > service.price && (
                    <div className="absolute -top-3 -right-3">
                      <Badge className="bg-red-500 text-white">
                        %
                        {Math.round(
                          ((service.originalPrice - service.price) /
                            service.originalPrice) *
                            100,
                        )}{" "}
                        İndirim
                      </Badge>
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <service.icon className="w-6 h-6 text-spiritual-turquoise-600" />
                      <span className="text-lg">{service.name}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-600 text-sm">
                      {service.description}
                    </p>

                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        {service.duration}
                      </span>
                    </div>

                    <div className="text-center py-4">
                      <div className="flex items-center justify-center space-x-2">
                        {service.originalPrice > service.price && (
                          <span className="text-lg text-gray-400 line-through">
                            ${service.originalPrice}
                          </span>
                        )}
                        <span className="text-3xl font-bold text-spiritual-turquoise-600">
                          ${service.price}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">seans başına</p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Hizmet İçeriği:
                      </h4>
                      <ul className="space-y-1">
                        {service.features.map((feature, featureIndex) => (
                          <li
                            key={featureIndex}
                            className="flex items-center space-x-2 text-sm"
                          >
                            <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-orange-50 border border-orange-200 rounded p-3">
                      <div className="flex items-center space-x-2 text-orange-700">
                        <Lock className="w-4 h-4" />
                        <span className="text-xs font-medium">
                          Aktif Üyelik Gerekli
                        </span>
                      </div>
                      <p className="text-xs text-orange-600 mt-1">
                        Bu hizmeti kullanmak için aktif üyelik ve ödeme
                        gereklidir.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Packages */}
          <TabsContent value="packages" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Manevi{" "}
                <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                  Gelişim Paketleri
                </span>
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Ruhsal yolculuğunuza uygun paketi seçin. Her paket farklı
                seviyede manevi destek sunar.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {spiritualPackages.map((pkg, index) => (
                <Card
                  key={index}
                  className={`relative hover:shadow-xl transition-all duration-300 ${pkg.color}`}
                >
                  {pkg.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-spiritual-gold-500 text-white px-4 py-1">
                        En Popüler
                      </Badge>
                    </div>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle className="text-xl">{pkg.name}</CardTitle>
                    <Badge variant="outline" className="mx-auto w-fit">
                      {pkg.level}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center">
                      <div className="flex items-center justify-center space-x-2 mb-2">
                        {pkg.originalPrice > pkg.price && (
                          <span className="text-lg text-gray-400 line-through">
                            ${pkg.originalPrice}
                          </span>
                        )}
                        <span className="text-4xl font-bold text-spiritual-turquoise-600">
                          ${pkg.price}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        {pkg.duration} süreyle
                      </p>
                      {pkg.originalPrice > pkg.price && (
                        <p className="text-xs text-green-600 font-medium">
                          %
                          {Math.round(
                            ((pkg.originalPrice - pkg.price) /
                              pkg.originalPrice) *
                              100,
                          )}{" "}
                          tasarruf
                        </p>
                      )}
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">
                        Paket İçeriği:
                      </h4>
                      <ul className="space-y-2">
                        {pkg.features.map((feature, featureIndex) => (
                          <li
                            key={featureIndex}
                            className="flex items-center space-x-2 text-sm"
                          >
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-orange-50 border border-orange-200 rounded p-3">
                      <div className="flex items-center space-x-2 text-orange-700">
                        <Lock className="w-4 h-4" />
                        <span className="text-xs font-medium">
                          Ödeme Gerekli
                        </span>
                      </div>
                      <p className="text-xs text-orange-600 mt-1">
                        Bu paketi satın almak için üye olmanız ve ödeme yapmanız
                        gerekmektedir.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Levels */}
          <TabsContent value="levels" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                  Nefs Mertebeleri
                </span>{" "}
                Sistemi
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                7 seviyeli manevi gelişim ve kazanç sistemi. Her seviyede artan
                avantajlar ve manevi derinlik.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {nefsLevels.map((level, index) => (
                <Card
                  key={level.id}
                  className={`hover:shadow-xl transition-all duration-300 ${
                    level.id === sponsorInfo.level
                      ? "ring-2 ring-spiritual-gold-400 bg-spiritual-gold-50"
                      : "bg-white/80 backdrop-blur-sm"
                  }`}
                >
                  <CardHeader className="text-center">
                    <div className="text-4xl mb-2">{level.emoji}</div>
                    <CardTitle className="text-lg">{level.name}</CardTitle>
                    {level.id === sponsorInfo.level && (
                      <Badge className="bg-spiritual-gold-500 text-white">
                        Sponsorunuzun Seviyesi
                      </Badge>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600 text-center">
                      {level.description}
                    </p>

                    <div className="text-center">
                      <div className="text-sm text-gray-500">Gereksinim</div>
                      <div className="font-semibold text-spiritual-turquoise-600">
                        {level.teamRequirement}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                        Avantajlar:
                      </h4>
                      <ul className="space-y-1">
                        {level.benefits.map((benefit, benefitIndex) => (
                          <li
                            key={benefitIndex}
                            className="text-xs text-gray-600 flex items-center space-x-1"
                          >
                            <Star className="w-3 h-3 text-spiritual-gold-500 flex-shrink-0" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="bg-spiritual-purple-50 rounded-2xl p-8 text-center">
              <h3 className="text-2xl font-bold text-spiritual-purple-800 mb-4">
                Manevi Gelişim Yolculuğunuza Başlayın
              </h3>
              <p className="text-spiritual-purple-700 mb-6">
                Her seviye hem manevi gelişiminizi hem de kazancınızı artırır.
                İslami değerlerle desteklenen bu sistem ile hem dünya hem ahiret
                için çalışın.
              </p>
              <Button
                onClick={handleJoinClick}
                className="bg-spiritual-gradient text-white px-8 py-3"
              >
                <Crown className="w-5 h-5 mr-2" />
                Yolculuğuma Başla
              </Button>
            </div>
          </TabsContent>

          {/* Testimonials */}
          <TabsContent value="testimonials" className="space-y-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Üye{" "}
                <span className="bg-spiritual-gradient bg-clip-text text-transparent">
                  Deneyimleri
                </span>
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Platformumuzdan faydalanan üyelerimizin gerçek deneyimleri ve
                başarı hikayeleri.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="text-center mb-4">
                      <Avatar className="w-16 h-16 mx-auto mb-3">
                        <AvatarFallback className="bg-spiritual-gradient text-white">
                          {testimonial.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <h3 className="font-semibold text-gray-900">
                        {testimonial.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {testimonial.location}
                      </p>
                      <Badge className="mt-1" variant="outline">
                        {testimonial.level}
                      </Badge>
                    </div>

                    <div className="text-center mb-4">
                      <div className="flex justify-center space-x-1 mb-2">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star
                            key={i}
                            className="w-4 h-4 text-spiritual-gold-500 fill-current"
                          />
                        ))}
                      </div>
                      <p className="text-sm text-gray-700 italic">
                        "{testimonial.text}"
                      </p>
                    </div>

                    <div className="border-t border-gray-200 pt-4 grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-green-600">
                          ${testimonial.earnings}
                        </div>
                        <div className="text-xs text-gray-500">
                          Aylık Kazanç
                        </div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-600">
                          {testimonial.duration}
                        </div>
                        <div className="text-xs text-gray-500">
                          Üyelik Süresi
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center">
              <p className="text-gray-600 mb-6">
                Siz de bu başarılı üyelerimiz arasına katılın ve hem manevi
                gelişiminizi hem de maddi durumunuzu iyileştirin.
              </p>
              <Button
                onClick={handleJoinClick}
                className="bg-spiritual-gradient text-white px-8 py-4 text-lg"
              >
                <Users className="w-5 h-5 mr-2" />
                Başarı Hikayenizi Yazın
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {/* Bottom CTA */}
        <section className="mt-16 bg-spiritual-gradient rounded-2xl p-8 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">
            Manevi Yolculuğunuza Başlamaya Hazır mısınız?
          </h2>
          <p className="text-xl mb-6 opacity-90">
            {sponsorInfo.name} size bu özel yolculukta rehberlik etmeye hazır.
            Aylık sadece $10 ile başlayın.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={handleJoinClick}
              className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
            >
              <ArrowRight className="w-5 h-5 mr-2" />
              Hemen Katıl
            </Button>
            <div className="flex items-center space-x-4 text-sm opacity-75">
              <div className="flex items-center space-x-1">
                <Shield className="w-4 h-4" />
                <span>Güvenli ödeme</span>
              </div>
              <div className="flex items-center space-x-1">
                <CheckCircle className="w-4 h-4" />
                <span>Anında erişim</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default EnhancedClonePage;
