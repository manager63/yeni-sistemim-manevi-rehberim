import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import {
  Star,
  LogIn,
  Crown,
  Shield,
  Users,
  UserPlus,
  Eye,
  EyeOff,
} from "lucide-react";

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [activeTab, setActiveTab] = useState<"admin" | "member" | "register">(
    "member",
  );
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  // Admin login form state
  const [adminCredentials, setAdminCredentials] = useState({
    username: "",
    password: "",
  });

  // Member login form state
  const [memberCredentials, setMemberCredentials] = useState({
    email: "",
    password: "",
  });

  // Registration form state
  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Check admin credentials
    if (
      adminCredentials.username === "abdulkadirkan" &&
      adminCredentials.password === "Abdulkadir1983."
    ) {
      setTimeout(() => {
        const adminUser = {
          username: "abdulkadirkan",
          password: "Abdulkadir1983.",
          name: "Abdul Kadir Kan",
          isAdmin: true,
          subscriptionActive: true,
          nefsLevel: 7,
          totalEarnings: 100000,
          teamSize: 1000,
          role: "super_admin",
        };
        login(adminUser);
        navigate("/super-admin-dashboard");
        setIsLoading(false);
      }, 1000);
    } else {
      setTimeout(() => {
        setError("Hatalı kullanıcı adı veya şifre!");
        setIsLoading(false);
      }, 1000);
    }
  };

  const handleMemberLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Simulate member login (this would connect to real backend)
    setTimeout(() => {
      setError(
        "Üye girişi sistemi henüz aktif değil. Lütfen daha sonra tekrar deneyin.",
      );
      setIsLoading(false);
    }, 1000);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    if (registerData.password !== registerData.confirmPassword) {
      setError("Şifreler eşleşmiyor!");
      setIsLoading(false);
      return;
    }

    // Simulate registration (this would connect to real backend)
    setTimeout(() => {
      setError(
        "Üye kayıt sistemi henüz aktif değil. Lütfen daha sonra tekrar deneyin.",
      );
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-spiritual-gradient rounded-full flex items-center justify-center">
              <Star className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-spiritual-gradient bg-clip-text text-transparent">
            Manevi Rehberim
          </h1>
          <p className="text-gray-600 mt-2">Hoş Geldiniz</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex mb-6 bg-white/50 rounded-lg p-1">
          <button
            onClick={() => setActiveTab("member")}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === "member"
                ? "bg-white text-spiritual-turquoise-600 shadow-sm"
                : "text-gray-600 hover:text-spiritual-turquoise-600"
            }`}
          >
            <Users className="w-4 h-4 inline-block mr-2" />
            Üye Girişi
          </button>
          <button
            onClick={() => setActiveTab("register")}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === "register"
                ? "bg-white text-spiritual-turquoise-600 shadow-sm"
                : "text-gray-600 hover:text-spiritual-turquoise-600"
            }`}
          >
            <UserPlus className="w-4 h-4 inline-block mr-2" />
            Üye Ol
          </button>
          <button
            onClick={() => setActiveTab("admin")}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === "admin"
                ? "bg-white text-yellow-600 shadow-sm"
                : "text-gray-600 hover:text-yellow-600"
            }`}
          >
            <Crown className="w-4 h-4 inline-block mr-2" />
            Admin
          </button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border border-spiritual-turquoise-200 shadow-xl">
          <CardHeader>
            <CardTitle className="text-center flex items-center justify-center space-x-2">
              {activeTab === "admin" && (
                <>
                  <Crown className="w-6 h-6 text-yellow-600" />
                  <span className="text-yellow-600">Yönetici Girişi</span>
                </>
              )}
              {activeTab === "member" && (
                <>
                  <LogIn className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span className="text-spiritual-turquoise-600">
                    Üye Girişi
                  </span>
                </>
              )}
              {activeTab === "register" && (
                <>
                  <UserPlus className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span className="text-spiritual-turquoise-600">
                    Üye Kayıt
                  </span>
                </>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-4 border-red-200 bg-red-50">
                <AlertDescription className="text-red-700">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            {isLoading ? (
              <div className="text-center py-12">
                <div className="w-8 h-8 border-4 border-spiritual-turquoise-300 border-t-spiritual-turquoise-600 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600">
                  {activeTab === "admin" && "Admin girişi yapılıyor..."}
                  {activeTab === "member" && "Üye girişi yapılıyor..."}
                  {activeTab === "register" && "Kayıt işlemi yapılıyor..."}
                </p>
              </div>
            ) : (
              <>
                {/* Admin Login Form */}
                {activeTab === "admin" && (
                  <form onSubmit={handleAdminLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="admin-username">Kullanıcı Adı</Label>
                      <Input
                        id="admin-username"
                        type="text"
                        value={adminCredentials.username}
                        onChange={(e) =>
                          setAdminCredentials({
                            ...adminCredentials,
                            username: e.target.value,
                          })
                        }
                        required
                        className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="admin-password">Şifre</Label>
                      <div className="relative">
                        <Input
                          id="admin-password"
                          type={showPassword ? "text" : "password"}
                          value={adminCredentials.password}
                          onChange={(e) =>
                            setAdminCredentials({
                              ...adminCredentials,
                              password: e.target.value,
                            })
                          }
                          required
                          className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 text-white hover:from-yellow-600 hover:to-yellow-700"
                    >
                      <Crown className="w-4 h-4 mr-2" />
                      Admin Girişi Yap
                    </Button>
                  </form>
                )}

                {/* Member Login Form */}
                {activeTab === "member" && (
                  <form onSubmit={handleMemberLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="member-email">E-posta</Label>
                      <Input
                        id="member-email"
                        type="email"
                        value={memberCredentials.email}
                        onChange={(e) =>
                          setMemberCredentials({
                            ...memberCredentials,
                            email: e.target.value,
                          })
                        }
                        required
                        className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="member-password">Şifre</Label>
                      <div className="relative">
                        <Input
                          id="member-password"
                          type={showPassword ? "text" : "password"}
                          value={memberCredentials.password}
                          onChange={(e) =>
                            setMemberCredentials({
                              ...memberCredentials,
                              password: e.target.value,
                            })
                          }
                          required
                          className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-spiritual-gradient text-white hover:opacity-90"
                    >
                      <LogIn className="w-4 h-4 mr-2" />
                      Üye Girişi Yap
                    </Button>
                    <div className="text-center">
                      <button
                        type="button"
                        onClick={() => setActiveTab("register")}
                        className="text-sm text-spiritual-turquoise-600 hover:underline"
                      >
                        Hesabınız yok mu? Üye olun
                      </button>
                    </div>
                  </form>
                )}

                {/* Registration Form */}
                {activeTab === "register" && (
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="register-name">Ad Soyad</Label>
                      <Input
                        id="register-name"
                        type="text"
                        value={registerData.name}
                        onChange={(e) =>
                          setRegisterData({
                            ...registerData,
                            name: e.target.value,
                          })
                        }
                        required
                        className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-email">E-posta</Label>
                      <Input
                        id="register-email"
                        type="email"
                        value={registerData.email}
                        onChange={(e) =>
                          setRegisterData({
                            ...registerData,
                            email: e.target.value,
                          })
                        }
                        required
                        className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-phone">Telefon</Label>
                      <Input
                        id="register-phone"
                        type="tel"
                        value={registerData.phone}
                        onChange={(e) =>
                          setRegisterData({
                            ...registerData,
                            phone: e.target.value,
                          })
                        }
                        required
                        className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-password">Şifre</Label>
                      <div className="relative">
                        <Input
                          id="register-password"
                          type={showPassword ? "text" : "password"}
                          value={registerData.password}
                          onChange={(e) =>
                            setRegisterData({
                              ...registerData,
                              password: e.target.value,
                            })
                          }
                          required
                          className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400 pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-confirm-password">
                        Şifre Tekrar
                      </Label>
                      <Input
                        id="register-confirm-password"
                        type={showPassword ? "text" : "password"}
                        value={registerData.confirmPassword}
                        onChange={(e) =>
                          setRegisterData({
                            ...registerData,
                            confirmPassword: e.target.value,
                          })
                        }
                        required
                        className="border-spiritual-turquoise-200 focus:border-spiritual-turquoise-400"
                      />
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-spiritual-gradient text-white hover:opacity-90"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Üye Ol
                    </Button>
                    <div className="text-center">
                      <button
                        type="button"
                        onClick={() => setActiveTab("member")}
                        className="text-sm text-spiritual-turquoise-600 hover:underline"
                      >
                        Zaten hesabınız var mı? Giriş yapın
                      </button>
                    </div>
                  </form>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Admin Security Warning */}
        {activeTab === "admin" && (
          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-yellow-600" />
              <p className="text-sm text-yellow-700">
                Bu panel sadece sistem yöneticileri için tasarlanmıştır.
                Yetkisiz erişim yasaktır.
              </p>
            </div>
          </div>
        )}

        {/* Features Info */}
        {activeTab !== "admin" && (
          <div className="mt-8 text-center">
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="text-center">
                <div className="w-12 h-12 bg-spiritual-turquoise-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Star className="w-6 h-6 text-spiritual-turquoise-600" />
                </div>
                <div className="text-xs text-gray-600">Manevi Gelişim</div>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <div className="text-xs text-gray-600">Topluluk</div>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <div className="text-xs text-gray-600">Güvenli Platform</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Login;
