import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import {
  Bell,
  X,
  Clock,
  AlertCircle,
  Info,
  Gift,
  Star,
  CheckCircle,
  Eye,
  Calendar,
  ChevronDown,
  ChevronUp,
  Trash2,
} from "lucide-react";

interface NewsItem {
  id: number;
  title: string;
  content: string;
  type: "announcement" | "update" | "promotion" | "warning";
  priority: "low" | "medium" | "high" | "urgent";
  targetUsers: "all" | "members" | "admins" | "specific";
  isActive: boolean;
  createdAt: string;
  expiresAt?: string;
  views: number;
  author: string;
  isRead?: boolean;
}

const UserNewsFeed = () => {
  const { user } = useAuth();
  const [newsItems, setNewsItems] = useState<NewsItem[]>([
    {
      id: 1,
      title: "Platform Güncellemesi",
      content:
        "Yeni özellikler eklendi. Artık daha kolay MLM yönetimi yapabilirsiniz. Detaylı bilgi için lütfen kullanıcı rehberini inceleyin.",
      type: "update",
      priority: "medium",
      targetUsers: "all",
      isActive: true,
      createdAt: "2024-01-20",
      views: 127,
      author: "Admin",
      isRead: false,
    },
    {
      id: 2,
      title: "Özel İndirim Kampanyası",
      content:
        "Bu ay sadece sizler için %50 indirimli yıllık üyelik fırsatı! Kampanya 31 Ocak'a kadar geçerli.",
      type: "promotion",
      priority: "high",
      targetUsers: "members",
      isActive: true,
      createdAt: "2024-01-19",
      expiresAt: "2024-02-01",
      views: 89,
      author: "Admin",
      isRead: false,
    },
    {
      id: 3,
      title: "Sistem Bakımı Bildirimi",
      content:
        "Yarın saat 02:00-04:00 arası sistem bakımı yapılacaktır. Bu sürede platforma erişim sağlanamayacaktır.",
      type: "warning",
      priority: "urgent",
      targetUsers: "all",
      isActive: true,
      createdAt: "2024-01-18",
      views: 234,
      author: "Teknik Ekip",
      isRead: true,
    },
    {
      id: 4,
      title: "Yeni Seviye Sistemı",
      content:
        "Nefs mertebeleri sistemi yenilendi. Artık daha detaylı ilerleme takibi yapabilirsiniz.",
      type: "announcement",
      priority: "medium",
      targetUsers: "all",
      isActive: true,
      createdAt: "2024-01-17",
      views: 156,
      author: "Admin",
      isRead: true,
    },
  ]);

  const [expandedNews, setExpandedNews] = useState<number[]>([]);
  const [showAll, setShowAll] = useState(false);

  // Filter news based on user type and target
  const relevantNews = newsItems.filter((news) => {
    if (!news.isActive) return false;

    // Check expiry
    if (news.expiresAt) {
      const expiryDate = new Date(news.expiresAt);
      const now = new Date();
      if (now > expiryDate) return false;
    }

    // Check target audience
    if (news.targetUsers === "all") return true;
    if (news.targetUsers === "members" && user?.subscriptionActive) return true;
    if (news.targetUsers === "admins" && user?.isAdmin) return true;

    return false;
  });

  // Sort by priority and date
  const sortedNews = relevantNews.sort((a, b) => {
    const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
    const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
    if (priorityDiff !== 0) return priorityDiff;

    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  // Show only first 3 news unless "show all" is clicked
  const displayNews = showAll ? sortedNews : sortedNews.slice(0, 3);
  const unreadCount = relevantNews.filter((news) => !news.isRead).length;

  const getNewsIcon = (type: NewsItem["type"]) => {
    switch (type) {
      case "announcement":
        return <Bell className="w-4 h-4" />;
      case "update":
        return <Star className="w-4 h-4" />;
      case "promotion":
        return <Gift className="w-4 h-4" />;
      case "warning":
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const getNewsColor = (
    type: NewsItem["type"],
    priority: NewsItem["priority"],
  ) => {
    if (priority === "urgent") return "border-red-300 bg-red-50";
    if (priority === "high") return "border-orange-300 bg-orange-50";

    switch (type) {
      case "announcement":
        return "border-blue-300 bg-blue-50";
      case "update":
        return "border-purple-300 bg-purple-50";
      case "promotion":
        return "border-green-300 bg-green-50";
      case "warning":
        return "border-yellow-300 bg-yellow-50";
      default:
        return "border-gray-300 bg-gray-50";
    }
  };

  const getTypeLabel = (type: NewsItem["type"]) => {
    switch (type) {
      case "announcement":
        return "Duyuru";
      case "update":
        return "Güncelleme";
      case "promotion":
        return "Kampanya";
      case "warning":
        return "Uyarı";
      default:
        return "Bilgi";
    }
  };

  const getPriorityLabel = (priority: NewsItem["priority"]) => {
    switch (priority) {
      case "urgent":
        return "Acil";
      case "high":
        return "Yüksek";
      case "medium":
        return "Orta";
      case "low":
        return "Düşük";
      default:
        return "Normal";
    }
  };

  const markAsRead = (newsId: number) => {
    setNewsItems((items) =>
      items.map((item) =>
        item.id === newsId
          ? { ...item, isRead: true, views: item.views + 1 }
          : item,
      ),
    );
  };

  const toggleExpand = (newsId: number) => {
    setExpandedNews((prev) =>
      prev.includes(newsId)
        ? prev.filter((id) => id !== newsId)
        : [...prev, newsId],
    );
    markAsRead(newsId);
  };

  const dismissNews = (newsId: number) => {
    setNewsItems((items) =>
      items.map((item) =>
        item.id === newsId ? { ...item, isRead: true } : item,
      ),
    );
  };

  if (relevantNews.length === 0) {
    return null;
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border border-spiritual-turquoise-200">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-spiritual-turquoise-600" />
            <span>Haber Bülteni</span>
            {unreadCount > 0 && (
              <Badge className="bg-red-500 text-white">
                {unreadCount} yeni
              </Badge>
            )}
          </div>
          <div className="text-sm text-gray-500">
            {relevantNews.length} haber
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {displayNews.map((news) => {
          const isExpanded = expandedNews.includes(news.id);
          const isUnread = !news.isRead;

          return (
            <div
              key={news.id}
              className={`border rounded-lg p-4 transition-all duration-200 ${getNewsColor(news.type, news.priority)} ${
                isUnread ? "border-l-4 border-l-spiritual-turquoise-500" : ""
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    {getNewsIcon(news.type)}
                    <h4
                      className={`font-semibold ${isUnread ? "font-bold" : ""}`}
                    >
                      {news.title}
                    </h4>
                    <Badge
                      variant={
                        news.priority === "urgent" || news.priority === "high"
                          ? "destructive"
                          : "outline"
                      }
                      className="text-xs"
                    >
                      {getTypeLabel(news.type)}
                    </Badge>
                    {news.priority === "urgent" && (
                      <Badge variant="destructive" className="text-xs">
                        {getPriorityLabel(news.priority)}
                      </Badge>
                    )}
                  </div>

                  <p
                    className={`text-gray-700 ${isExpanded ? "" : "line-clamp-2"}`}
                  >
                    {news.content}
                  </p>

                  {news.content.length > 100 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleExpand(news.id)}
                      className="mt-2 text-spiritual-turquoise-600 hover:text-spiritual-turquoise-700 p-0 h-auto"
                    >
                      {isExpanded ? (
                        <>
                          <ChevronUp className="w-4 h-4 mr-1" />
                          Daha az göster
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4 mr-1" />
                          Devamını oku
                        </>
                      )}
                    </Button>
                  )}

                  <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {news.createdAt}
                      </span>
                      <span className="flex items-center">
                        <Eye className="w-3 h-3 mr-1" />
                        {news.views} görüntülenme
                      </span>
                      <span>Yazar: {news.author}</span>
                    </div>
                    {news.expiresAt && (
                      <span className="text-orange-600">
                        <Clock className="w-3 h-3 mr-1 inline" />
                        {news.expiresAt} tarihine kadar
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex flex-col space-y-2 ml-4">
                  {isUnread && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markAsRead(news.id)}
                      className="text-green-600 hover:text-green-700 p-1 h-auto"
                      title="Okundu olarak işaretle"
                    >
                      <CheckCircle className="w-4 h-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => dismissNews(news.id)}
                    className="text-gray-400 hover:text-gray-600 p-1 h-auto"
                    title="Kapat"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}

        {relevantNews.length > 3 && (
          <Button
            variant="outline"
            onClick={() => setShowAll(!showAll)}
            className="w-full"
          >
            {showAll ? (
              <>
                <ChevronUp className="w-4 h-4 mr-2" />
                Daha az göster
              </>
            ) : (
              <>
                <ChevronDown className="w-4 h-4 mr-2" />
                {relevantNews.length - 3} haber daha göster
              </>
            )}
          </Button>
        )}

        {!user?.subscriptionActive && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-sm">
              Üye olarak özel kampanya ve güncellemelerden haberdar
              olabilirsiniz.
              <Button variant="link" className="p-0 ml-1 h-auto text-sm">
                Üye ol
              </Button>
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};

export default UserNewsFeed;
