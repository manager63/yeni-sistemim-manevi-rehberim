import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/contexts/AuthContext";
import {
  Shield,
  Users,
  DollarSign,
  Settings,
  BarChart,
  FileText,
  Upload,
  Download,
  Edit,
  Trash2,
  Plus,
  Save,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Globe,
  Database,
  Image,
  Video,
  Mail,
  Bell,
  Palette,
  Code,
  Monitor,
  Lock,
  Key,
  Zap,
  Crown,
  Star,
  Gift,
  Target,
  Search,
  Filter,
  MoreHorizontal,
  Eye,
  Calendar,
  Clock,
  MapPin,
  Phone,
  MessageSquare,
} from "lucide-react";

const SuperAdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect if not admin
  useEffect(() => {
    if (!user || !user.isAdmin) {
      navigate("/");
    }
  }, [user, navigate]);

  // System Configuration State
  const [systemConfig, setSystemConfig] = useState({
    siteName: "Manevi Rehberim",
    siteTagline: "Ruhsal Gelişim ve Network Pazarlama Platformu",
    primaryColor: "#14b8a6",
    secondaryColor: "#a855f7",
    accentColor: "#f59e0b",
    logoUrl: "/logo.png",
    faviconUrl: "/favicon.ico",
    enableRegistration: true,
    enablePayment: true,
    maintenanceMode: false,
    maxUsers: 100000,
    defaultLanguage: "tr",
    timeZone: "Europe/Istanbul",
  });

  // Content Management State
  const [contentLibrary, setContentLibrary] = useState({
    dailyQuotes: [
      {
        id: 1,
        text: "Allah'a yakın olmak istiyorsan, insanlara yakın ol.",
        author: "Hz. Ali",
        category: "spiritual",
        isActive: true,
        scheduledDate: "2024-01-01",
      },
      {
        id: 2,
        text: "Sabır, imanın yarısıdır.",
        author: "Hz. Muhammed (SAV)",
        category: "wisdom",
        isActive: true,
        scheduledDate: "2024-01-02",
      },
    ],
    prayers: [
      {
        id: 1,
        name: "Sabah Duası",
        arabic: "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا",
        turkish: "Allah'ım! Seninle sabahladık, seninle akşamladık",
        time: "morning",
        isActive: true,
      },
    ],
    menuContent: {
      spiritualDevelopment: {
        title: "Manevi Gelişim",
        description: "İslami ilkelerle desteklenen ruhsal büyüme yolculuğu",
        sections: [
          {
            name: "Dhikr (Zikir)",
            content: "Allah'ın isimlerini zikretme ve kalp temizliği",
            benefits: ["Kalp huzuru", "Manevi güç", "İç rahatlık"],
            practices: ["Subhanallah", "Alhamdulillah", "Allahu Akbar"],
          },
          {
            name: "Tafakkur (Tefekkür)",
            content: "Kur'an ayetleri ve yaratılış üzerine derin düşünce",
            benefits: ["Hikmet kazanma", "Manevi derinlik", "Farkındalık"],
            practices: ["Ayetleri düşünme", "Doğa gözlemi", "İçsel sorgulama"],
          },
          {
            name: "Tazkiyah (Nefis Temizliği)",
            content: "Nefsi kötü sıfatlardan arındırma ve güzel ahlak",
            benefits: ["Karakter gelişimi", "Ruhsal arınma", "Ahlaki olgunluk"],
            practices: ["Nefis muhasebesi", "Dua", "Sadaka"],
          },
        ],
      },
      lifeCoaching: {
        title: "Yaşam Koçluğu",
        description:
          "İslami değerlerle desteklenen profesyonel yaşam danışmanlığı",
        services: [
          {
            name: "Bireysel Koçluk",
            duration: "60 dakika",
            price: 150,
            features: [
              "Kişisel hedef belirleme",
              "İslami perspektif",
              "Eylem planı",
            ],
          },
          {
            name: "Aile Danışmanlığı",
            duration: "90 dakika",
            price: 200,
            features: [
              "İlişki iyileştirme",
              "İletişim becerileri",
              "İslami aile yapısı",
            ],
          },
          {
            name: "Kariyer Rehberliği",
            duration: "75 dakika",
            price: 175,
            features: [
              "Helal kazanç yolları",
              "İş-yaşam dengesi",
              "Profesyonel gelişim",
            ],
          },
        ],
      },
      spiritualServices: {
        title: "Manevi Hizmetler",
        description: "Dua, meditasyon ve ruhsal rehberlik hizmetleri",
        packages: [
          {
            name: "Temel Manevi Paket",
            price: 99,
            duration: "1 ay",
            features: [
              "Günlük dua rehberi",
              "Haftalık zikir programı",
              "Manevi danışmanlık (2 seans)",
              "İslami meditasyon rehberi",
            ],
          },
          {
            name: "Premium Manevi Paket",
            price: 249,
            duration: "3 ay",
            features: [
              "Kişiselleştirilmiş dua programı",
              "Haftalık canlı zikir seansları",
              "Aylık özel danışmanlık",
              "Rüya tabiri hizmeti",
              "Manevi gelişim raporu",
            ],
          },
          {
            name: "VIP Manevi Transformasyon",
            price: 599,
            duration: "6 ay",
            features: [
              "7/24 manevi destek hattı",
              "Kişisel manevi mentor",
              "Aylık manevi retreat'ler",
              "Özel dua ve zikir programı",
              "Aile manevi danışmanlığı",
              "Yıllık hac/umre rehberliği",
            ],
          },
        ],
      },
    },
  });

  // Clone Page Template State
  const [clonePageTemplate, setClonePageTemplate] = useState({
    heroSection: {
      headline: "Manevi Gelişim ve Kazanç Fırsatı",
      subheadline:
        "İslami değerlerle hem ruhsal gelişiminizi hem de mali kazancınızı artırın",
      ctaText: "Hemen Katıl",
      backgroundImage: "/images/spiritual-bg.jpg",
    },
    features: [
      {
        icon: "🕌",
        title: "İslami Manevi Gelişim",
        description: "Dua, zikir ve tefekkür ile ruhsal arınma",
      },
      {
        icon: "💰",
        title: "7 Seviye Kazanç Sistemi",
        description: "Nefs mertebeleri ile yükselen gelir imkanı",
      },
      {
        icon: "👥",
        title: "Güçlü Topluluk",
        description: "Manevi değerleri paylaşan büyük aile",
      },
      {
        icon: "📚",
        title: "Sürekli Eğitim",
        description: "Yaşam koçluğu ve manevi rehberlik",
      },
    ],
    benefits: [
      "Aylık sadece $10 ile başlayın",
      "7 seviye derinliğinde komisyon",
      "Kişisel clone sayfanız",
      "24/7 manevi destek",
      "İslami yaşam koçluğu",
      "Özgür çalışma saatleri",
    ],
    testimonials: [
      {
        name: "Ayşe Hanım",
        location: "İstanbul",
        text: "Bu platform sayesinde hem maneviyatımı geliştirdim hem de ek gelir elde ettim.",
        rating: 5,
      },
      {
        name: "Mehmet Bey",
        location: "Ankara",
        text: "İslami değerlerle uyumlu bir iş modeli. Çok memnunum.",
        rating: 5,
      },
    ],
  });

  // Advanced Settings State
  const [advancedSettings, setAdvancedSettings] = useState({
    security: {
      enableTwoFactor: false,
      passwordMinLength: 8,
      sessionTimeout: 30,
      maxLoginAttempts: 5,
      enableCaptcha: true,
    },
    notifications: {
      emailNotifications: true,
      smsNotifications: false,
      pushNotifications: true,
      adminAlerts: true,
    },
    performance: {
      cacheEnabled: true,
      compressionEnabled: true,
      cdnEnabled: false,
      lazyLoading: true,
    },
    integrations: {
      googleAnalytics: "",
      facebookPixel: "",
      whatsappApi: "",
      paymentGateway: "stripe",
    },
  });

  // Statistics State
  const [stats, setStats] = useState({
    totalUsers: 1247,
    activeUsers: 892,
    totalRevenue: 45230,
    monthlyGrowth: 18.5,
    conversionRate: 12.3,
    clonePageViews: 8945,
    clonePageConversions: 234,
  });

  const handleSystemConfigUpdate = () => {
    console.log("System config updated:", systemConfig);
    alert("Sistem ayarları başarıyla güncellendi!");
  };

  const handleContentUpdate = () => {
    console.log("Content updated:", contentLibrary);
    alert("İçerik başarıyla güncellendi!");
  };

  const handleCloneTemplateUpdate = () => {
    console.log("Clone template updated:", clonePageTemplate);
    alert("Clone sayfa şablonu başarıyla güncellendi!");
  };

  const handleBulkUserOperation = (operation: string) => {
    console.log(`Bulk operation: ${operation}`);
    alert(`Toplu işlem (${operation}) başarıyla gerçekleştirildi!`);
  };

  const handleExportData = (type: string) => {
    console.log(`Exporting ${type} data`);
    alert(`${type} verileri dışa aktarılıyor...`);
  };

  const handleImportData = (type: string) => {
    console.log(`Importing ${type} data`);
    alert(`${type} verileri içe aktarılıyor...`);
  };

  if (!user || !user.isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-spiritual-gradient rounded-full flex items-center justify-center">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">
                  Süper Admin Kontrol Merkezi
                </h1>
                <p className="text-gray-600">
                  Tüm sistem yönetimi ve özelleştirme araçları
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Badge variant="default" className="bg-green-100 text-green-800">
                Sistem Aktif
              </Badge>
              <Button
                variant="outline"
                onClick={() => handleExportData("system")}
              >
                <Download className="w-4 h-4 mr-2" />
                Sistemi Yedekle
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <Users className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{stats.totalUsers}</div>
                <div className="text-xs text-gray-500">Toplam Üye</div>
              </CardContent>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <CheckCircle className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{stats.activeUsers}</div>
                <div className="text-xs text-gray-500">Aktif Üye</div>
              </CardContent>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <DollarSign className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <div className="text-xl font-bold">${stats.totalRevenue}</div>
                <div className="text-xs text-gray-500">Toplam Gelir</div>
              </CardContent>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <TrendingUp className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                <div className="text-xl font-bold">%{stats.monthlyGrowth}</div>
                <div className="text-xs text-gray-500">Aylık Büyüme</div>
              </CardContent>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <Target className="w-6 h-6 text-orange-600 mx-auto mb-2" />
                <div className="text-xl font-bold">%{stats.conversionRate}</div>
                <div className="text-xs text-gray-500">Dönüşüm</div>
              </CardContent>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <Eye className="w-6 h-6 text-indigo-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{stats.clonePageViews}</div>
                <div className="text-xs text-gray-500">Sayfa Görüntüleme</div>
              </CardContent>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-4 text-center">
                <Star className="w-6 h-6 text-yellow-600 mx-auto mb-2" />
                <div className="text-xl font-bold">
                  {stats.clonePageConversions}
                </div>
                <div className="text-xs text-gray-500">Üyelik</div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="system" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="system">Sistem</TabsTrigger>
            <TabsTrigger value="content">İçerik</TabsTrigger>
            <TabsTrigger value="users">Üyeler</TabsTrigger>
            <TabsTrigger value="clone">Clone Şablon</TabsTrigger>
            <TabsTrigger value="mlm">MLM Ayarlar</TabsTrigger>
            <TabsTrigger value="design">Tasarım</TabsTrigger>
            <TabsTrigger value="analytics">Analitik</TabsTrigger>
            <TabsTrigger value="advanced">Gelişmiş</TabsTrigger>
          </TabsList>

          {/* System Configuration */}
          <TabsContent value="system" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span>Sistem Yapılandırması</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="siteName">Site Adı</Label>
                      <Input
                        id="siteName"
                        value={systemConfig.siteName}
                        onChange={(e) =>
                          setSystemConfig({
                            ...systemConfig,
                            siteName: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="siteTagline">Site Sloganı</Label>
                      <Input
                        id="siteTagline"
                        value={systemConfig.siteTagline}
                        onChange={(e) =>
                          setSystemConfig({
                            ...systemConfig,
                            siteTagline: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="maxUsers">Maksimum Üye Sayısı</Label>
                      <Input
                        id="maxUsers"
                        type="number"
                        value={systemConfig.maxUsers}
                        onChange={(e) =>
                          setSystemConfig({
                            ...systemConfig,
                            maxUsers: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Yeni Üye Kaydı</Label>
                      <Switch
                        checked={systemConfig.enableRegistration}
                        onCheckedChange={(checked) =>
                          setSystemConfig({
                            ...systemConfig,
                            enableRegistration: checked,
                          })
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Ödeme Sistemi</Label>
                      <Switch
                        checked={systemConfig.enablePayment}
                        onCheckedChange={(checked) =>
                          setSystemConfig({
                            ...systemConfig,
                            enablePayment: checked,
                          })
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Bakım Modu</Label>
                      <Switch
                        checked={systemConfig.maintenanceMode}
                        onCheckedChange={(checked) =>
                          setSystemConfig({
                            ...systemConfig,
                            maintenanceMode: checked,
                          })
                        }
                      />
                    </div>
                  </div>
                </div>
                <Button
                  onClick={handleSystemConfigUpdate}
                  className="bg-spiritual-gradient text-white"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Sistem Ayarlarını Kaydet
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Management */}
          <TabsContent value="content" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Manevi İçerik Yönetimi</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Dhikr (Zikir) Bölümü</Label>
                    <Textarea
                      value={
                        contentLibrary.menuContent.spiritualDevelopment
                          .sections[0].content
                      }
                      onChange={(e) => {
                        const updated = { ...contentLibrary };
                        updated.menuContent.spiritualDevelopment.sections[0].content =
                          e.target.value;
                        setContentLibrary(updated);
                      }}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Tafakkur (Tefekkür) Bölümü</Label>
                    <Textarea
                      value={
                        contentLibrary.menuContent.spiritualDevelopment
                          .sections[1].content
                      }
                      onChange={(e) => {
                        const updated = { ...contentLibrary };
                        updated.menuContent.spiritualDevelopment.sections[1].content =
                          e.target.value;
                        setContentLibrary(updated);
                      }}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Tazkiyah (Nefis Temizliği) Bölümü</Label>
                    <Textarea
                      value={
                        contentLibrary.menuContent.spiritualDevelopment
                          .sections[2].content
                      }
                      onChange={(e) => {
                        const updated = { ...contentLibrary };
                        updated.menuContent.spiritualDevelopment.sections[2].content =
                          e.target.value;
                        setContentLibrary(updated);
                      }}
                      className="mt-1"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Yaşam Koçluğu Hizmetleri</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {contentLibrary.menuContent.lifeCoaching.services.map(
                    (service, index) => (
                      <div
                        key={index}
                        className="border border-gray-200 rounded-lg p-4"
                      >
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Hizmet Adı</Label>
                            <Input
                              value={service.name}
                              onChange={(e) => {
                                const updated = { ...contentLibrary };
                                updated.menuContent.lifeCoaching.services[
                                  index
                                ].name = e.target.value;
                                setContentLibrary(updated);
                              }}
                            />
                          </div>
                          <div>
                            <Label>Fiyat ($)</Label>
                            <Input
                              type="number"
                              value={service.price}
                              onChange={(e) => {
                                const updated = { ...contentLibrary };
                                updated.menuContent.lifeCoaching.services[
                                  index
                                ].price = parseInt(e.target.value);
                                setContentLibrary(updated);
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    ),
                  )}
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Manevi Hizmet Paketleri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  {contentLibrary.menuContent.spiritualServices.packages.map(
                    (pkg, index) => (
                      <div
                        key={index}
                        className="border border-gray-200 rounded-lg p-4"
                      >
                        <div className="space-y-3">
                          <Input
                            placeholder="Paket Adı"
                            value={pkg.name}
                            onChange={(e) => {
                              const updated = { ...contentLibrary };
                              updated.menuContent.spiritualServices.packages[
                                index
                              ].name = e.target.value;
                              setContentLibrary(updated);
                            }}
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <Input
                              placeholder="Fiyat"
                              type="number"
                              value={pkg.price}
                              onChange={(e) => {
                                const updated = { ...contentLibrary };
                                updated.menuContent.spiritualServices.packages[
                                  index
                                ].price = parseInt(e.target.value);
                                setContentLibrary(updated);
                              }}
                            />
                            <Input
                              placeholder="Süre"
                              value={pkg.duration}
                              onChange={(e) => {
                                const updated = { ...contentLibrary };
                                updated.menuContent.spiritualServices.packages[
                                  index
                                ].duration = e.target.value;
                                setContentLibrary(updated);
                              }}
                            />
                          </div>
                          <div className="space-y-1">
                            {pkg.features.map((feature, featureIndex) => (
                              <div
                                key={featureIndex}
                                className="text-xs bg-gray-50 p-1 rounded"
                              >
                                {feature}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ),
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="flex space-x-4">
              <Button
                onClick={handleContentUpdate}
                className="bg-spiritual-gradient text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                İçerikleri Kaydet
              </Button>
              <Button
                onClick={() => handleImportData("content")}
                variant="outline"
              >
                <Upload className="w-4 h-4 mr-2" />
                İçerik İçe Aktar
              </Button>
              <Button
                onClick={() => handleExportData("content")}
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                İçerik Dışa Aktar
              </Button>
            </div>
          </TabsContent>

          {/* Clone Page Template */}
          <TabsContent value="clone" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="w-6 h-6 text-spiritual-purple-600" />
                  <span>Clone Sayfa Şablonu</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label>Ana Başlık</Label>
                      <Input
                        value={clonePageTemplate.heroSection.headline}
                        onChange={(e) =>
                          setClonePageTemplate({
                            ...clonePageTemplate,
                            heroSection: {
                              ...clonePageTemplate.heroSection,
                              headline: e.target.value,
                            },
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Alt Başlık</Label>
                      <Textarea
                        value={clonePageTemplate.heroSection.subheadline}
                        onChange={(e) =>
                          setClonePageTemplate({
                            ...clonePageTemplate,
                            heroSection: {
                              ...clonePageTemplate.heroSection,
                              subheadline: e.target.value,
                            },
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Buton Metni</Label>
                      <Input
                        value={clonePageTemplate.heroSection.ctaText}
                        onChange={(e) =>
                          setClonePageTemplate({
                            ...clonePageTemplate,
                            heroSection: {
                              ...clonePageTemplate.heroSection,
                              ctaText: e.target.value,
                            },
                          })
                        }
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label>Özellikler</Label>
                      {clonePageTemplate.features.map((feature, index) => (
                        <div
                          key={index}
                          className="border border-gray-200 rounded p-3 mb-2"
                        >
                          <div className="grid grid-cols-3 gap-2">
                            <Input
                              placeholder="İkon"
                              value={feature.icon}
                              onChange={(e) => {
                                const updated = { ...clonePageTemplate };
                                updated.features[index].icon = e.target.value;
                                setClonePageTemplate(updated);
                              }}
                            />
                            <Input
                              placeholder="Başlık"
                              value={feature.title}
                              onChange={(e) => {
                                const updated = { ...clonePageTemplate };
                                updated.features[index].title = e.target.value;
                                setClonePageTemplate(updated);
                              }}
                            />
                            <Button size="sm" variant="outline">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                          <Input
                            placeholder="Açıklama"
                            value={feature.description}
                            onChange={(e) => {
                              const updated = { ...clonePageTemplate };
                              updated.features[index].description =
                                e.target.value;
                              setClonePageTemplate(updated);
                            }}
                            className="mt-2"
                          />
                        </div>
                      ))}
                      <Button size="sm" variant="outline" className="w-full">
                        <Plus className="w-4 h-4 mr-2" />
                        Özellik Ekle
                      </Button>
                    </div>
                  </div>
                </div>

                <div>
                  <Label>Avantajlar</Label>
                  <div className="grid md:grid-cols-2 gap-2 mt-2">
                    {clonePageTemplate.benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Input
                          value={benefit}
                          onChange={(e) => {
                            const updated = { ...clonePageTemplate };
                            updated.benefits[index] = e.target.value;
                            setClonePageTemplate(updated);
                          }}
                        />
                        <Button size="sm" variant="outline">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <Button size="sm" variant="outline" className="mt-2">
                    <Plus className="w-4 h-4 mr-2" />
                    Avantaj Ekle
                  </Button>
                </div>

                <div className="flex space-x-4">
                  <Button
                    onClick={handleCloneTemplateUpdate}
                    className="bg-spiritual-gradient text-white"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Şablonu Kaydet
                  </Button>
                  <Button variant="outline">
                    <Eye className="w-4 h-4 mr-2" />
                    Önizleme
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management */}
          <TabsContent value="users" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="w-6 h-6 text-spiritual-turquoise-600" />
                    <span>Gelişmiş Üye Yönetimi</span>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Filter className="w-4 h-4 mr-2" />
                      Filtrele
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Dışa Aktar
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex space-x-4">
                    <Input placeholder="Üye ara..." className="flex-1" />
                    <Select>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Durum" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tümü</SelectItem>
                        <SelectItem value="active">Aktif</SelectItem>
                        <SelectItem value="inactive">Pasif</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button className="bg-spiritual-gradient text-white">
                      <Search className="w-4 h-4 mr-2" />
                      Ara
                    </Button>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      onClick={() => handleBulkUserOperation("activate")}
                    >
                      Seçilileri Aktifleştir
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleBulkUserOperation("deactivate")}
                    >
                      Seçilileri Pasifleştir
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleBulkUserOperation("email")}
                    >
                      E-posta Gönder
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleBulkUserOperation("upgrade")}
                    >
                      Seviye Yükselt
                    </Button>
                  </div>

                  <div className="text-sm text-gray-600">
                    <p>
                      Toplam {stats.totalUsers} üye, {stats.activeUsers} aktif
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Clone Sayfa Performansı</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Toplam Görüntüleme</span>
                      <span className="font-bold">{stats.clonePageViews}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Toplam Dönüşüm</span>
                      <span className="font-bold">
                        {stats.clonePageConversions}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Dönüşüm Oranı</span>
                      <span className="font-bold text-green-600">
                        %{stats.conversionRate}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Gelir Analizi</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Bu Ay Gelir</span>
                      <span className="font-bold">
                        ${(stats.totalRevenue * 0.3).toFixed(0)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Aylık Büyüme</span>
                      <span className="font-bold text-green-600">
                        +%{stats.monthlyGrowth}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Ortalama Üye Değeri</span>
                      <span className="font-bold">
                        ${(stats.totalRevenue / stats.totalUsers).toFixed(0)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Advanced Settings */}
          <TabsContent value="advanced" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lock className="w-6 h-6 text-red-600" />
                    <span>Güvenlik Ayarları</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>İki Faktörlü Doğrulama</Label>
                    <Switch
                      checked={advancedSettings.security.enableTwoFactor}
                      onCheckedChange={(checked) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          security: {
                            ...advancedSettings.security,
                            enableTwoFactor: checked,
                          },
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Minimum Şifre Uzunluğu</Label>
                    <Input
                      type="number"
                      value={advancedSettings.security.passwordMinLength}
                      onChange={(e) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          security: {
                            ...advancedSettings.security,
                            passwordMinLength: parseInt(e.target.value),
                          },
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Oturum Zaman Aşımı (dakika)</Label>
                    <Input
                      type="number"
                      value={advancedSettings.security.sessionTimeout}
                      onChange={(e) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          security: {
                            ...advancedSettings.security,
                            sessionTimeout: parseInt(e.target.value),
                          },
                        })
                      }
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="w-6 h-6 text-yellow-600" />
                    <span>Performans Ayarları</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Önbellek Sistemi</Label>
                    <Switch
                      checked={advancedSettings.performance.cacheEnabled}
                      onCheckedChange={(checked) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          performance: {
                            ...advancedSettings.performance,
                            cacheEnabled: checked,
                          },
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Sıkıştırma</Label>
                    <Switch
                      checked={advancedSettings.performance.compressionEnabled}
                      onCheckedChange={(checked) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          performance: {
                            ...advancedSettings.performance,
                            compressionEnabled: checked,
                          },
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Lazy Loading</Label>
                    <Switch
                      checked={advancedSettings.performance.lazyLoading}
                      onCheckedChange={(checked) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          performance: {
                            ...advancedSettings.performance,
                            lazyLoading: checked,
                          },
                        })
                      }
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Entegrasyonlar</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Google Analytics ID</Label>
                    <Input
                      placeholder="G-XXXXXXXXXX"
                      value={advancedSettings.integrations.googleAnalytics}
                      onChange={(e) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          integrations: {
                            ...advancedSettings.integrations,
                            googleAnalytics: e.target.value,
                          },
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Facebook Pixel ID</Label>
                    <Input
                      placeholder="123456789"
                      value={advancedSettings.integrations.facebookPixel}
                      onChange={(e) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          integrations: {
                            ...advancedSettings.integrations,
                            facebookPixel: e.target.value,
                          },
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>WhatsApp API</Label>
                    <Input
                      placeholder="API anahtarı"
                      value={advancedSettings.integrations.whatsappApi}
                      onChange={(e) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          integrations: {
                            ...advancedSettings.integrations,
                            whatsappApi: e.target.value,
                          },
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Ödeme Sistemi</Label>
                    <Select
                      value={advancedSettings.integrations.paymentGateway}
                      onValueChange={(value) =>
                        setAdvancedSettings({
                          ...advancedSettings,
                          integrations: {
                            ...advancedSettings.integrations,
                            paymentGateway: value,
                          },
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stripe">Stripe</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="iyzico">Iyzico</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SuperAdminPanel;
