import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Quote, Star } from "lucide-react";
import { getTodaysQuote } from "@/lib/spiritual";

const DailyQuote = () => {
  const quote = getTodaysQuote();

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "wisdom":
        return "text-spiritual-turquoise-600";
      case "motivation":
        return "text-spiritual-purple-600";
      case "spiritual":
        return "text-spiritual-gold-600";
      case "peace":
        return "text-green-600";
      default:
        return "text-gray-600";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "wisdom":
        return "🧠";
      case "motivation":
        return "💪";
      case "spiritual":
        return "🕌";
      case "peace":
        return "☮️";
      default:
        return "✨";
    }
  };

  return (
    <Card className="w-full bg-gradient-to-br from-white to-spiritual-turquoise-25 border-spiritual-turquoise-200 shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 bg-spiritual-gradient rounded-full flex items-center justify-center">
              <Quote className="w-6 h-6 text-white" />
            </div>
          </div>

          <div className="flex-1 space-y-3">
            <div className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-spiritual-gold-500" />
              <span className="text-sm font-medium text-spiritual-turquoise-700">
                Günün İlham Verici Sözü
              </span>
              <span className="text-lg">{getCategoryIcon(quote.category)}</span>
            </div>

            <blockquote className="text-lg font-medium text-gray-700 leading-relaxed italic">
              "{quote.text}"
            </blockquote>

            <div className="flex items-center justify-between">
              <cite
                className={`text-sm font-semibold not-italic ${getCategoryColor(quote.category)}`}
              >
                — {quote.author}
              </cite>

              <div className="flex items-center space-x-1">
                <div
                  className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(quote.category)} bg-current bg-opacity-10`}
                >
                  {quote.category === "wisdom" && "Hikmet"}
                  {quote.category === "motivation" && "Motivasyon"}
                  {quote.category === "spiritual" && "Manevi"}
                  {quote.category === "peace" && "Huzur"}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-spiritual-turquoise-100">
          <p className="text-xs text-gray-500 text-center">
            Her gün yeni bir ilham verici söz ile ruhunuzu besleyin 🌟
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default DailyQuote;
