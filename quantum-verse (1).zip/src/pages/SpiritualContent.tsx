import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import {
  Clock,
  Star,
  Heart,
  BookOpen,
  Lock,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Calendar,
  Sunrise,
  Moon,
  Sun,
  Compass,
  Gift,
  Crown,
  Zap,
  CheckCircle,
  AlertCircle,
} from "lucide-react";

// Enhanced Meditation & Dhikr Page
export const MeditationPage = () => {
  const { user } = useAuth();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [selectedDhikr, setSelectedDhikr] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  const dhikrPractices = [
    {
      name: "Subhanallah (33x)",
      arabic: "سُبْحَانَ اللَّهِ",
      meaning: "Allah'ı tesbih ederim",
      count: 33,
      benefits: ["Kalp temizliği", "Manevi huzur", "Günah affı"],
      time: "Her namaz sonrası",
      audio: "/audio/subhanallah.mp3",
    },
    {
      name: "Alhamdulillah (33x)",
      arabic: "الْحَمْدُ لِلَّهِ",
      meaning: "Hamdolsun Allah'a",
      count: 33,
      benefits: ["Şükür artışı", "Nimet farkındalığı", "Pozitif enerji"],
      time: "Her namaz sonrası",
      audio: "/audio/alhamdulillah.mp3",
    },
    {
      name: "Allahu Akbar (34x)",
      arabic: "اللَّهُ أَكْبَرُ",
      meaning: "Allah en büyüktür",
      count: 34,
      benefits: ["Güven artışı", "Korku azalması", "Teslimiyet"],
      time: "Her namaz sonrası",
      audio: "/audio/allahu-akbar.mp3",
    },
    {
      name: "La ilaha illallah (100x)",
      arabic: "لَا إِلَٰهَ إِلَّا اللَّهُ",
      meaning: "Allah'tan başka ilah yoktur",
      count: 100,
      benefits: ["İman tazeleme", "Kalp nurlanması", "Ahiret hazırlığı"],
      time: "Sabah-akşam",
      audio: "/audio/la-ilaha-illallah.mp3",
    },
  ];

  const meditationPrograms = [
    {
      title: "Sabah Farkındalığı",
      duration: "15 dakika",
      description: "Güne manevi bir başlangıç yapın",
      steps: [
        "Abdest alın ve temiz bir yerde oturun",
        "3 defa derin nefes alıp verin",
        "Fatiha suresini okuyun",
        "Günün şükürlerini düşünün",
        "Sabah duasını yapın",
      ],
      icon: Sunrise,
      color: "text-yellow-500",
    },
    {
      title: "Öğle Dinginliği",
      duration: "10 dakika",
      description: "Gün ortasında huzur molası",
      steps: [
        "İşlerinizi bırakın ve sessiz kalın",
        "İstiğfar çekin (10x)",
        "Salavat getirin (10x)",
        "Kalp temizliği niyeti yapın",
        "Kısa bir şükür duası",
      ],
      icon: Sun,
      color: "text-orange-500",
    },
    {
      title: "Akşam Tefekkürü",
      duration: "20 dakika",
      description: "Günü değerlendirin ve şükredin",
      steps: [
        "Günün yaşadıklarını gözden geçirin",
        "Hatalarınız için tövbe edin",
        "İyilikleriniz için şükredin",
        "Yarın için dua edin",
        "Akşam duasını yapın",
      ],
      icon: Moon,
      color: "text-blue-500",
    },
  ];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Dhikr & İslami Meditasyon
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Kur'an ve Sünnet rehberliğinde kalp temizliği ve manevi gelişim
            pratikleri
          </p>
        </div>

        {!user?.isActive && (
          <Alert className="mb-8 border-orange-200 bg-orange-50">
            <Lock className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              Bu içeriklere tam erişim için aylık $10 abonelik gereklidir.
              <Button variant="link" className="text-orange-600 p-0 ml-2">
                Hemen üye ol
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="dhikr" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dhikr">Zikir Pratikleri</TabsTrigger>
            <TabsTrigger value="meditation">Meditasyon</TabsTrigger>
            <TabsTrigger value="programs">Programlar</TabsTrigger>
            <TabsTrigger value="guidance">Rehberlik</TabsTrigger>
          </TabsList>

          <TabsContent value="dhikr" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {dhikrPractices.map((dhikr, index) => (
                <Card
                  key={index}
                  className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 ${
                    !user?.isActive ? "opacity-75" : ""
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{dhikr.name}</span>
                      <Badge variant="outline">{dhikr.time}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-center p-4 bg-spiritual-turquoise-50 rounded-lg">
                      <div className="text-2xl arabic-text mb-2">
                        {dhikr.arabic}
                      </div>
                      <div className="text-sm text-gray-600">
                        {dhikr.meaning}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-spiritual-turquoise-600">
                          {dhikr.count}
                        </div>
                        <div className="text-xs text-gray-500">Tekrar</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-spiritual-purple-600">
                          {Math.ceil(dhikr.count / 10)}
                        </div>
                        <div className="text-xs text-gray-500">Dakika</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-spiritual-gold-600">
                          ∞
                        </div>
                        <div className="text-xs text-gray-500">Sevap</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Faydaları:
                      </h4>
                      <ul className="space-y-1">
                        {dhikr.benefits.map((benefit, benefitIndex) => (
                          <li
                            key={benefitIndex}
                            className="flex items-center space-x-2 text-sm"
                          >
                            <CheckCircle className="w-3 h-3 text-green-500" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        className="flex-1 bg-spiritual-gradient text-white"
                        disabled={!user?.isActive}
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Başlat
                      </Button>
                      <Button
                        variant="outline"
                        disabled={!user?.isActive}
                        onClick={() => setIsMuted(!isMuted)}
                      >
                        {isMuted ? (
                          <VolumeX className="w-4 h-4" />
                        ) : (
                          <Volume2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>

                    {!user?.isActive && (
                      <div className="text-center text-xs text-gray-500">
                        Sesli rehberlik için üyelik gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="meditation" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {meditationPrograms.map((program, index) => (
                <Card
                  key={index}
                  className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 ${
                    !user?.isActive ? "opacity-75" : ""
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <program.icon className={`w-6 h-6 ${program.color}`} />
                      <span>{program.title}</span>
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        {program.duration}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-600 text-sm">
                      {program.description}
                    </p>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Adımlar:
                      </h4>
                      <ol className="space-y-2">
                        {program.steps.map((step, stepIndex) => (
                          <li
                            key={stepIndex}
                            className="flex items-start space-x-2 text-sm"
                          >
                            <span className="flex-shrink-0 w-5 h-5 bg-spiritual-turquoise-100 text-spiritual-turquoise-600 rounded-full flex items-center justify-center text-xs font-medium">
                              {stepIndex + 1}
                            </span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    <Button
                      className="w-full bg-spiritual-gradient text-white"
                      disabled={!user?.isActive}
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Programı Başlat
                    </Button>

                    {!user?.isActive && (
                      <div className="text-center text-xs text-gray-500">
                        Rehberli meditasyon için üyelik gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="programs" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Haftalık Zikir Programı</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      "Pazartesi: Esmaül Hüsna (99 isim)",
                      "Salı: İstiğfar (100x)",
                      "Çarşamba: Salavat (100x)",
                      "Perşembe: Tesbih-i Fatıma",
                      "Cuma: Kur'an Tilaveti",
                      "Cumartesi: Dua-i Künüt",
                      "Pazar: Serbest zikir",
                    ].map((day, index) => (
                      <div
                        key={index}
                        className="flex items-center space-x-3 p-2 rounded bg-spiritual-turquoise-50"
                      >
                        <Calendar className="w-4 h-4 text-spiritual-turquoise-600" />
                        <span className="text-sm">{day}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Aylık Gelişim Takibi</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-spiritual-purple-600">
                        {user?.isActive ? "18" : "0"}
                      </div>
                      <div className="text-sm text-gray-600">
                        Bu ay tamamlanan günler
                      </div>
                    </div>
                    <div className="grid grid-cols-7 gap-1">
                      {Array.from({ length: 30 }, (_, i) => (
                        <div
                          key={i}
                          className={`w-8 h-8 rounded ${
                            user?.isActive && i < 18
                              ? "bg-spiritual-turquoise-500"
                              : "bg-gray-200"
                          } flex items-center justify-center text-xs text-white`}
                        >
                          {i + 1}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="guidance" className="space-y-8">
            <div className="space-y-6">
              <Card className="bg-spiritual-gradient text-white">
                <CardContent className="p-8 text-center">
                  <Crown className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-4">
                    Kişisel Manevi Rehberlik
                  </h3>
                  <p className="mb-6">
                    Uzman manevi rehberlerimizden birebir destek alın
                  </p>
                  <Button
                    className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100"
                    disabled={!user?.isActive}
                  >
                    Rehberlik Talep Et
                  </Button>
                </CardContent>
              </Card>

              <div className="grid lg:grid-cols-3 gap-6">
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-lg">Zikir Rehberliği</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Kişisel durumunuza uygun zikir programı oluşturma
                    </p>
                    <ul className="space-y-1 text-xs">
                      <li>• Kişisel değerlendirme</li>
                      <li>• Özel zikir listesi</li>
                      <li>• Haftalık takip</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-lg">Dua Danışmanlığı</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Özel durumlarınız için uygun duaların öğretimi
                    </p>
                    <ul className="space-y-1 text-xs">
                      <li>• Durum analizi</li>
                      <li>• Uygun dua seçimi</li>
                      <li>• Doğru okuma rehberi</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-lg">Rüya Tabiri</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      İslami kaynaklar ışığında rüya yorumları
                    </p>
                    <ul className="space-y-1 text-xs">
                      <li>• Detaylı analiz</li>
                      <li>• İslami kaynak referansları</li>
                      <li>• Manevi öneriler</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

// Enhanced Prayer & Intention Page
export const PrayerPage = () => {
  const { user } = useAuth();
  const [selectedPrayerTime, setSelectedPrayerTime] = useState("morning");

  const dailyPrayers = {
    morning: {
      name: "Sabah Duası",
      arabic:
        "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ",
      turkish:
        "Allah'ım! Seninle sabahladık, seninle akşamladık, seninle yaşıyoruz, seninle ölürüz ve sana döneceğiz.",
      time: "Sabah",
      benefits: ["Günün bereketli geçmesi", "Korunma", "Manevi güç"],
    },
    evening: {
      name: "Akşam Duası",
      arabic:
        "اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ",
      turkish:
        "Allah'ım! Seninle akşamladık, seninle sabahladık, seninle yaşıyoruz, seninle ölürüz ve sana döneceğiz.",
      time: "Akşam",
      benefits: ["Günahların affı", "Geceyi huzurla geçirme", "Korunma"],
    },
  };

  const specialPrayers = [
    {
      name: "İstiğfar Duası",
      arabic:
        "أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ",
      turkish:
        "Allah'tan başka ilah olmayan, Diri ve Kayyum olan Allah'tan mağfiret diler ve O'na tövbe ederim.",
      purpose: "Günah affı ve temizlik",
      frequency: "Günde 100 defa",
    },
    {
      name: "Salavat Duası",
      arabic: "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ",
      turkish: "Allah'ım! Muhammed'e ve Muhammed'in ailesine rahmet et.",
      purpose: "Sevap kazanma ve şefaat",
      frequency: "Sınırsız",
    },
  ];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Dua & Niyet Rehberi
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Günlük dualar, özel niyetler ve manevi temizlik pratikleri
          </p>
        </div>

        {!user?.isActive && (
          <Alert className="mb-8 border-orange-200 bg-orange-50">
            <Lock className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              Tüm dualar ve manevi rehberlik için aylık $10 abonelik gereklidir.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="daily" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="daily">Günlük Dualar</TabsTrigger>
            <TabsTrigger value="special">Özel Dualar</TabsTrigger>
            <TabsTrigger value="intentions">Niyetler</TabsTrigger>
            <TabsTrigger value="guidance">Dua Rehberi</TabsTrigger>
          </TabsList>

          <TabsContent value="daily" className="space-y-8">
            {/* Daily prayers content */}
            <div className="grid lg:grid-cols-2 gap-8">
              {Object.entries(dailyPrayers).map(([key, prayer]) => (
                <Card
                  key={key}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      {key === "morning" ? (
                        <Sunrise className="w-6 h-6 text-yellow-500" />
                      ) : (
                        <Moon className="w-6 h-6 text-blue-500" />
                      )}
                      <span>{prayer.name}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-spiritual-turquoise-50 rounded-lg">
                      <div className="text-lg arabic-text mb-3 leading-relaxed">
                        {prayer.arabic}
                      </div>
                      <div className="text-sm text-gray-700 leading-relaxed">
                        {prayer.turkish}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Faydaları:
                      </h4>
                      <ul className="space-y-1">
                        {prayer.benefits.map((benefit, index) => (
                          <li
                            key={index}
                            className="flex items-center space-x-2 text-sm"
                          >
                            <CheckCircle className="w-3 h-3 text-green-500" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Button
                      className="w-full bg-spiritual-gradient text-white"
                      disabled={!user?.isActive}
                    >
                      <Volume2 className="w-4 h-4 mr-2" />
                      Sesli Dinle
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="special" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {specialPrayers.map((prayer, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle>{prayer.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-spiritual-purple-50 rounded-lg">
                      <div className="text-lg arabic-text mb-3">
                        {prayer.arabic}
                      </div>
                      <div className="text-sm text-gray-700">
                        {prayer.turkish}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="font-semibold text-spiritual-turquoise-600">
                          {prayer.frequency}
                        </div>
                        <div className="text-xs text-gray-500">Sıklık</div>
                      </div>
                      <div>
                        <div className="font-semibold text-spiritual-purple-600">
                          {prayer.purpose}
                        </div>
                        <div className="text-xs text-gray-500">Amaç</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="intentions" className="space-y-8">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Niyet Rehberi</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  İslam'da niyet çok önemlidir. Her amelin değeri niyetle
                  belirlenir.
                </p>
                <div className="space-y-4">
                  {[
                    "Namaz kılmak için niyet",
                    "Oruç tutmak için niyet",
                    "Sadaka vermek için niyet",
                    "İlim öğrenmek için niyet",
                    "İyilik yapmak için niyet",
                  ].map((intention, index) => (
                    <div
                      key={index}
                      className="p-3 bg-spiritual-gold-50 rounded-lg"
                    >
                      <span className="text-spiritual-gold-700">
                        {intention}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="guidance" className="space-y-8">
            <Card className="bg-spiritual-gradient text-white">
              <CardContent className="p-8 text-center">
                <Star className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4">Dua Danışmanlığı</h3>
                <p className="mb-6">
                  Kişisel durumunuza uygun dualar için uzman rehberlik alın
                </p>
                <Button
                  className="bg-white text-spiritual-turquoise-700"
                  disabled={!user?.isActive}
                >
                  Danışmanlık Talep Et
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default { MeditationPage, PrayerPage };
