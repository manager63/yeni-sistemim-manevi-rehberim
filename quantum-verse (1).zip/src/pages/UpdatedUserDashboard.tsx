import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import UserNewsFeed from "@/components/UserNewsFeed";
import AiChat from "@/components/AiChat";
import {
  Crown,
  DollarSign,
  Users,
  TrendingUp,
  Trophy,
  Target,
  Check,
  ChevronDown,
  ChevronUp,
  Share2,
  Copy,
  Link,
  Calendar,
  Clock,
  CreditCard,
  AlertCircle,
  CheckCircle,
  Gift,
  Star,
  BarChart,
  PieChart,
  RefreshCw,
  Download,
  Upload,
  Plus,
  Edit,
  Eye,
  Mail,
  Phone,
  MessageSquare,
  Lock,
  Unlock,
  Zap,
  Sparkles,
  Heart,
  Flame,
} from "lucide-react";

const UpdatedUserDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      navigate("/giriş");
    }
  }, [user, navigate]);

  if (!user) return null;

  // Subscription Management
  const [subscriptionEndDate, setSubscriptionEndDate] = useState(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
  );
  const [daysTillExpiry, setDaysTillExpiry] = useState(30);
  const [autoRenewal, setAutoRenewal] = useState(true);

  // Team Management
  const [showTeamDetails, setShowTeamDetails] = useState(false);
  const [teamMembers] = useState([
    {
      id: 1,
      name: "Ali Veli",
      level: 2,
      earnings: 150,
      joinDate: "2024-01-15",
      status: "active",
    },
    {
      id: 2,
      name: "Ayşe Fatma",
      level: 1,
      earnings: 75,
      joinDate: "2024-01-18",
      status: "active",
    },
    {
      id: 3,
      name: "Mehmet Can",
      level: 1,
      earnings: 0,
      joinDate: "2024-01-20",
      status: "inactive",
    },
  ]);

  // Earnings Data
  const [earningsData] = useState({
    thisMonth: 425,
    lastMonth: 380,
    totalEarnings: user.totalEarnings || 1250,
    pendingEarnings: 125,
    commissionBreakdown: {
      directSales: 200,
      teamCommission: 150,
      bonuses: 75,
    },
    earningsHistory: [
      { month: "Ocak", amount: 425 },
      { month: "Aralık", amount: 380 },
      { month: "Kasım", amount: 295 },
      { month: "Ekim", amount: 150 },
    ],
  });

  // Calculate days until expiry
  useEffect(() => {
    const today = new Date();
    const diffTime = subscriptionEndDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    setDaysTillExpiry(diffDays);
  }, [subscriptionEndDate]);

  // Nefs Levels
  const nefsLevels = [
    { id: 1, name: "Nefs-i Emmare", description: "Kötülüğü Emreden Nefs" },
    { id: 2, name: "Nefs-i Levvame", description: "Kendini Kınayan Nefs" },
    { id: 3, name: "Nefs-i Mülhime", description: "İlham Alan Nefs" },
    { id: 4, name: "Nefs-i Mutmaine", description: "Huzur Bulan Nefs" },
    { id: 5, name: "Nefs-i Raziye", description: "Allah'tan Razı Olan Nefs" },
    {
      id: 6,
      name: "Nefs-i Marziyye",
      description: "Allah'ın Razı Olduğu Nefs",
    },
    { id: 7, name: "Nefs-i Kâmile", description: "Mükemmel Nefs" },
  ];

  const currentLevel = nefsLevels.find((level) => level.id === user.nefsLevel);
  const nextLevel = nefsLevels.find((level) => level.id === user.nefsLevel + 1);

  // Stats for dashboard
  const stats = [
    {
      title: "Bu Ay Kazanç",
      value: `$${earningsData.thisMonth}`,
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: `+${(((earningsData.thisMonth - earningsData.lastMonth) / earningsData.lastMonth) * 100).toFixed(1)}%`,
    },
    {
      title: "Toplam Kazanç",
      value: `$${earningsData.totalEarnings}`,
      icon: TrendingUp,
      color: "text-spiritual-gold-600",
      bgColor: "bg-spiritual-gold-50",
      change: "Toplam gelir",
    },
    {
      title: "Ekip Büyüklüğü",
      value: user.teamSize?.toString() || "0",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      change: `${teamMembers.filter((m) => m.status === "active").length} aktif`,
    },
    {
      title: "Mevcut Seviye",
      value: `${user.nefsLevel}/7`,
      icon: Crown,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      change: currentLevel?.name || "",
    },
  ];

  const achievements = [
    { title: "İlk Üye", completed: true, date: "15 Şubat 2024" },
    { title: "5 Kişilik Ekip", completed: user.teamSize >= 5, date: null },
    { title: "Seviye 2", completed: user.nefsLevel >= 2, date: null },
    {
      title: "İlk $100 Kazanç",
      completed: earningsData.totalEarnings >= 100,
      date: null,
    },
    { title: "10 Kişilik Ekip", completed: user.teamSize >= 10, date: null },
    { title: "Seviye 3", completed: user.nefsLevel >= 3, date: null },
  ];

  const handleRenewal = () => {
    // Simulate renewal process
    const newEndDate = new Date(
      subscriptionEndDate.getTime() +
        (user.subscriptionType === "yearly"
          ? 365 * 24 * 60 * 60 * 1000
          : 30 * 24 * 60 * 60 * 1000),
    );
    setSubscriptionEndDate(newEndDate);
  };

  const copyReferralLink = () => {
    const referralLink = `https://manevireberim.com/clone/${user.id}`;
    navigator.clipboard.writeText(referralLink);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("tr-TR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Welcome Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-2">
            Hoş Geldiniz, {user.name}
          </h1>
          <p className="text-gray-600">
            Manevi gelişim yolculuğunuz ve MLM başarınız için dashboard'unuz
          </p>
        </div>

        {/* Subscription Status */}
        <Card className="mb-8 bg-white/80 backdrop-blur-sm border-2 border-spiritual-turquoise-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CreditCard className="w-5 h-5 text-spiritual-turquoise-600" />
                <span>Üyelik Durumu</span>
                {user.subscriptionActive ? (
                  <Badge className="bg-green-100 text-green-700">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Aktif
                  </Badge>
                ) : (
                  <Badge className="bg-red-100 text-red-700">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    Pasif
                  </Badge>
                )}
              </div>
              <div className="text-sm text-gray-500">
                {user.subscriptionType === "yearly" ? "Yıllık" : "Aylık"} Plan
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <Label className="text-sm text-gray-600">Bitiş Tarihi</Label>
                <div className="text-lg font-semibold">
                  {formatDate(subscriptionEndDate)}
                </div>
                <div
                  className={`text-sm ${daysTillExpiry <= 7 ? "text-red-600" : "text-gray-600"}`}
                >
                  {daysTillExpiry} gün kaldı
                </div>
              </div>
              <div>
                <Label className="text-sm text-gray-600">
                  Otomatik Yenileme
                </Label>
                <div className="flex items-center space-x-2 mt-1">
                  {autoRenewal ? (
                    <Badge className="bg-green-100 text-green-700">
                      <Check className="w-3 h-3 mr-1" />
                      Aktif
                    </Badge>
                  ) : (
                    <Badge className="bg-yellow-100 text-yellow-700">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Pasif
                    </Badge>
                  )}
                </div>
              </div>
              <div className="flex items-end space-x-2">
                <Button
                  onClick={handleRenewal}
                  className="bg-spiritual-gradient text-white"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Hemen Yenile
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setAutoRenewal(!autoRenewal)}
                >
                  {autoRenewal ? "Otomatik İptal" : "Otomatik Aç"}
                </Button>
              </div>
            </div>

            {daysTillExpiry <= 7 && (
              <Alert className="mt-4 border-orange-200 bg-orange-50">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-orange-700">
                  Üyeliğiniz {daysTillExpiry} gün içinde sona erecek. Kesintisiz
                  hizmet için lütfen yenileyin.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* News Feed */}
        <div className="mb-8">
          <UserNewsFeed />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="bg-white/80 backdrop-blur-sm hover:shadow-lg transition-all duration-200"
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                    <p className="text-xs text-gray-500">{stat.change}</p>
                  </div>
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* AI Chat Card */}
        <div className="mb-8">
          <AiChat />
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-white/80">
            <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="earnings">Kazançlarım</TabsTrigger>
            <TabsTrigger value="team">Ekibim</TabsTrigger>
            <TabsTrigger value="clone">Clone Sayfa</TabsTrigger>
            <TabsTrigger value="tools">Araçlar</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {/* Achievements */}
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Trophy className="w-6 h-6 text-spiritual-gold-600" />
                      <span>Başarılarım</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-3">
                      {achievements.map((achievement, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg border ${
                            achievement.completed
                              ? "bg-green-50 border-green-200"
                              : "bg-gray-50 border-gray-200"
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            {achievement.completed ? (
                              <Check className="w-4 h-4 text-green-600" />
                            ) : (
                              <Target className="w-4 h-4 text-gray-400" />
                            )}
                            <span
                              className={`text-sm font-medium ${
                                achievement.completed
                                  ? "text-green-800"
                                  : "text-gray-600"
                              }`}
                            >
                              {achievement.title}
                            </span>
                          </div>
                          {achievement.date && (
                            <p className="text-xs text-gray-500 mt-1">
                              {achievement.date}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Activity */}
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Son Aktiviteler</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3 p-3 bg-spiritual-turquoise-50 rounded-lg">
                        <Users className="w-4 h-4 text-spiritual-turquoise-600" />
                        <div className="flex-1">
                          <span className="text-sm font-medium">
                            Yeni üye katıldı
                          </span>
                          <p className="text-xs text-gray-500">2 saat önce</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-spiritual-gold-50 rounded-lg">
                        <DollarSign className="w-4 h-4 text-spiritual-gold-600" />
                        <div className="flex-1">
                          <span className="text-sm font-medium">
                            $25 komisyon kazandınız
                          </span>
                          <p className="text-xs text-gray-500">1 gün önce</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                        <Crown className="w-4 h-4 text-purple-600" />
                        <div className="flex-1">
                          <span className="text-sm font-medium">
                            Seviye 3'e yükseldiniz
                          </span>
                          <p className="text-xs text-gray-500">3 gün önce</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Level Progress */}
              <div className="space-y-6">
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Crown className="w-6 h-6 text-purple-600" />
                      <span>Nefs Seviyesi</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center mb-4">
                      <div className="text-3xl font-bold text-purple-600 mb-2">
                        {user.nefsLevel}/7
                      </div>
                      <h3 className="font-semibold text-gray-900">
                        {currentLevel?.name}
                      </h3>
                      <p className="text-sm text-gray-600">
                        {currentLevel?.description}
                      </p>
                    </div>

                    <Progress
                      value={(user.nefsLevel / 7) * 100}
                      className="mb-4"
                    />

                    {nextLevel && (
                      <div className="text-center">
                        <p className="text-sm text-gray-600 mb-2">
                          Sonraki seviye:
                        </p>
                        <p className="font-medium text-gray-900">
                          {nextLevel.name}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Hızlı İşlemler</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={copyReferralLink}
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Referans Linkini Kopyala
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => navigate("/meditasyon")}
                    >
                      <Heart className="w-4 h-4 mr-2" />
                      Zikir & Meditasyon
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => navigate("/dua")}
                    >
                      <Star className="w-4 h-4 mr-2" />
                      Günlük Dualar
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Earnings Tab */}
          <TabsContent value="earnings" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Current Month Earnings */}
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <DollarSign className="w-5 h-5 mr-2 text-green-600" />
                    Bu Ay Kazanç
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    ${earningsData.thisMonth}
                  </div>
                  <p className="text-sm text-gray-600">
                    Geçen ay: ${earningsData.lastMonth}
                  </p>
                  <div className="mt-4">
                    <div className="flex justify-between text-sm mb-1">
                      <span>Hedef: $500</span>
                      <span>{(earningsData.thisMonth / 500) * 100}%</span>
                    </div>
                    <Progress value={(earningsData.thisMonth / 500) * 100} />
                  </div>
                </CardContent>
              </Card>

              {/* Total Earnings */}
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-spiritual-gold-600" />
                    Toplam Kazanç
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-spiritual-gold-600 mb-2">
                    ${earningsData.totalEarnings}
                  </div>
                  <p className="text-sm text-gray-600">Tüm zamanlar</p>
                  <div className="mt-4">
                    <Badge className="bg-green-100 text-green-700">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Bu ay %{" "}
                      {(
                        ((earningsData.thisMonth - earningsData.lastMonth) /
                          earningsData.lastMonth) *
                        100
                      ).toFixed(1)}{" "}
                      artış
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Pending Earnings */}
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="w-5 h-5 mr-2 text-orange-600" />
                    Bekleyen Kazanç
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-orange-600 mb-2">
                    ${earningsData.pendingEarnings}
                  </div>
                  <p className="text-sm text-gray-600">
                    Onay bekleyen komisyonlar
                  </p>
                  <Button variant="outline" size="sm" className="mt-4">
                    <Eye className="w-3 h-3 mr-1" />
                    Detayları Gör
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Commission Breakdown */}
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Komisyon Dağılımı</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      ${earningsData.commissionBreakdown.directSales}
                    </div>
                    <p className="text-sm text-gray-600">Direkt Satış</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      ${earningsData.commissionBreakdown.teamCommission}
                    </div>
                    <p className="text-sm text-gray-600">Ekip Komisyonu</p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      ${earningsData.commissionBreakdown.bonuses}
                    </div>
                    <p className="text-sm text-gray-600">Bonuslar</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Earnings History */}
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Kazanç Geçmişi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {earningsData.earningsHistory.map((month, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
                    >
                      <span className="font-medium">{month.month}</span>
                      <span className="text-lg font-bold text-green-600">
                        ${month.amount}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Team Tab */}
          <TabsContent value="team" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Users className="w-5 h-5 mr-2" />
                      Ekip Özeti
                    </div>
                    <Badge>{teamMembers.length} üye</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Aktif Üyeler:</span>
                      <span className="font-bold text-green-600">
                        {
                          teamMembers.filter((m) => m.status === "active")
                            .length
                        }
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Toplam Kazanç:</span>
                      <span className="font-bold text-spiritual-gold-600">
                        ${teamMembers.reduce((sum, m) => sum + m.earnings, 0)}
                      </span>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => setShowTeamDetails(!showTeamDetails)}
                    >
                      {showTeamDetails ? (
                        <ChevronUp className="w-4 h-4 mr-2" />
                      ) : (
                        <ChevronDown className="w-4 h-4 mr-2" />
                      )}
                      {showTeamDetails ? "Detayları Gizle" : "Detayları Göster"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Yeni Üye Davet Et</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600">
                      Referans linkinizi paylaşarak yeni üyeler kazanın
                    </p>
                    <Button
                      onClick={copyReferralLink}
                      className="w-full bg-spiritual-gradient text-white"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Referans Linkini Kopyala
                    </Button>
                    <div className="text-xs text-gray-500 text-center">
                      https://manevireberim.com/clone/{user.id}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {showTeamDetails && (
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Ekip Detayları</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {teamMembers.map((member) => (
                      <div
                        key={member.id}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                      >
                        <div>
                          <h4 className="font-semibold">{member.name}</h4>
                          <p className="text-sm text-gray-600">
                            Seviye {member.level} • {member.joinDate}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-green-600">
                            ${member.earnings}
                          </div>
                          <Badge
                            variant={
                              member.status === "active"
                                ? "default"
                                : "secondary"
                            }
                          >
                            {member.status === "active" ? "Aktif" : "Pasif"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Clone Page Tab */}
          <TabsContent value="clone" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Link className="w-5 h-5 mr-2" />
                  Kişisel Clone Sayfam
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-gray-600">
                    Kişisel pazarlama sayfanız üzerinden yeni üyeler kazanın
                  </p>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm font-medium mb-2">Clone Sayfa URL:</p>
                    <p className="text-sm text-gray-600 break-all">
                      https://manevireberim.com/clone/{user.id}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      onClick={copyReferralLink}
                      className="bg-spiritual-gradient text-white"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Linki Kopyala
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => window.open(`/clone/${user.id}`, "_blank")}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Önizleme
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tools Tab */}
          <TabsContent value="tools" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Pazarlama Araçları</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Download className="w-4 h-4 mr-2" />
                    Pazarlama Materyalleri İndir
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Share2 className="w-4 h-4 mr-2" />
                    Sosyal Medya Paylaşımları
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Mail className="w-4 h-4 mr-2" />
                    E-posta Şablonları
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Eğitim Kaynakları</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Eye className="w-4 h-4 mr-2" />
                    Video Eğitimler
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Webinar Kayıtları
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Phone className="w-4 h-4 mr-2" />
                    Mentorluk Takvimi
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UpdatedUserDashboard;
