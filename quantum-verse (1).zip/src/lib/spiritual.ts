// Spiritual content and utilities

export interface NefsLevel {
  id: number;
  name: string;
  description: string;
  emoji: string;
  requirements: string;
  benefits: string[];
}

export const NEFS_LEVELS: NefsLevel[] = [
  {
    id: 1,
    name: "Nefs-i Emmare",
    description:
      "Kötülüğü emreden nefis - İnsanı günaha ve kötülüğe yönlendiren, kontrolsüz arzularla dolu en alt seviyededir. Terbiye edilmemiştir.",
    emoji: "🌿",
    requirements: "Kayıt ve ilk adım",
    benefits: ["Sisteme giriş", "Temel rehberlik", "İlk seviye erişim"],
  },
  {
    id: 2,
    name: "Nefs-i Levvame",
    description:
      "Kendini kınayan nefis - Kişi, yaptığı hatalardan pişmanlık duyar ve kendini sorgulamaya başlar. Vicdan uyanmaya başladı.",
    emoji: "🌱",
    requirements: "3 kişi davet + Aylık abonelik",
    benefits: ["Temel komisyon", "Seviye 2 içerik", "Mentor desteği"],
  },
  {
    id: 3,
    name: "Nefs-i Mülhime",
    description:
      "İlham alan nefis - İyilik ve kötülük konusunda ilham alır, doğruyu seçme özelliği artar. Ruhsal olarak yükselir.",
    emoji: "🌾",
    requirements: "10 kişi davet + Düzenli satış",
    benefits: ["Yüksek komisyon", "Özel seminerler", "Liderlik eğitimi"],
  },
  {
    id: 4,
    name: "Nefs-i Mutmainne",
    description:
      "Tatmin olmuş, huzurlu nefis - Kalp huzuruna erişmiştir. Allah'a güven duyan, teslimiyet hâlindeki nefstir.",
    emoji: "🌼",
    requirements: "25 kişi davet + Aylık hedef",
    benefits: ["Bonus paylaşımı", "VIP etkinlikler", "Özel danışmanlık"],
  },
  {
    id: 5,
    name: "Nefs-i Râziye",
    description:
      "Allah'ın takdirine razı olan nefis - Kaderine tam teslimiyet içindedir. İradesini Allah'ın rızasıyla uyumlu hale getirmiş.",
    emoji: "🌸",
    requirements: "50 kişi davet + Liderlik",
    benefits: ["Yüksek bonus", "Ömür boyu gelir", "Elit statü"],
  },
  {
    id: 6,
    name: "Nefs-i Mardiyye",
    description:
      "Allah'ın razı olduğu nefis - Allah, bu nefisten razıdır. Kişi hem razıdır hem de Allah'ın rızasına erişmiştir.",
    emoji: "🌷",
    requirements: "100 kişi davet + Sürdürülebilir büyüme",
    benefits: ["Maksimum komisyon", "Şirket ortaklığı", "Global liderlik"],
  },
  {
    id: 7,
    name: "Nefs-i Kâmile",
    description:
      "Olgunlaşmış, kemale ermiş nefis - En yüce seviyedir. İnsan-ı kâmil mertebesidir. Bütün nefis basamaklarını geçerek ahlaken ve ruhen olgunluğa ulaşılmıştır.",
    emoji: "🌺",
    requirements: "250+ kişi davet + Mükemmel liderlik",
    benefits: ["Sınırsız gelir", "Miras hakları", "Ebedi statü"],
  },
];

export interface DailyQuote {
  text: string;
  author: string;
  category: "wisdom" | "motivation" | "spiritual" | "peace";
}

export const DAILY_QUOTES: DailyQuote[] = [
  {
    text: "Allah'a yakın olmak istiyorsan, insanlara yakın ol.",
    author: "Hz. Ali",
    category: "spiritual",
  },
  {
    text: "Sabır, iman yarısıdır.",
    author: "Hz. Muhammed (SAV)",
    category: "wisdom",
  },
  {
    text: "İlim çinle de olsa öğreniniz.",
    author: "Hz. Muhammed (SAV)",
    category: "motivation",
  },
  {
    text: "Gönlü temiz olan kişi, her yerde huzuru bulur.",
    author: "Mevlana",
    category: "peace",
  },
  {
    text: "Sen kendini bil ki, Rabbini bilesin.",
    author: "Hz. Ali",
    category: "spiritual",
  },
  {
    text: "Dünya ahiretin tarlasıdır.",
    author: "Hz. Muhammed (SAV)",
    category: "wisdom",
  },
  {
    text: "Her işe bismillah ile başla.",
    author: "İslam öğretisi",
    category: "spiritual",
  },
];

export interface Prayer {
  name: string;
  arabic: string;
  turkish: string;
  time: "morning" | "evening" | "anytime";
}

export const DAILY_PRAYERS: Prayer[] = [
  {
    name: "Sabah Duası",
    arabic:
      "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ",
    turkish:
      "Allah'ım! Seninle sabahladık, seninle akşamladık, seninle yaşıyoruz, seninle ölürüz ve sana döneceğiz.",
    time: "morning",
  },
  {
    name: "Akşam Duası",
    arabic:
      "اللَّهُمَّ ��ِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ",
    turkish:
      "Allah'ım! Seninle akşamladık, seninle sabahladık, seninle yaşıyoruz, seninle ölürüz ve sana döneceğiz.",
    time: "evening",
  },
];

export const DHIKR_FORMULAS = [
  { text: "Subhanallah", translation: "Allah'ı tesbih ederim", count: 33 },
  { text: "Alhamdulillah", translation: "Hamdolsun Allah'a", count: 33 },
  { text: "Allahu Akbar", translation: "Allah en büyüktür", count: 34 },
  {
    text: "La ilaha illallah",
    translation: "Allah'tan başka ilah yoktur",
    count: 100,
  },
];

export function getTodaysQuote(): DailyQuote {
  const today = new Date();
  const dayOfYear = Math.floor(
    (today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) /
      86400000,
  );
  return DAILY_QUOTES[dayOfYear % DAILY_QUOTES.length];
}

export function getTodaysPrayer(): Prayer {
  const hour = new Date().getHours();
  if (hour < 12) {
    return DAILY_PRAYERS.find((p) => p.time === "morning") || DAILY_PRAYERS[0];
  } else {
    return DAILY_PRAYERS.find((p) => p.time === "evening") || DAILY_PRAYERS[1];
  }
}

export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}
