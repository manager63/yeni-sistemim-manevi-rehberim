import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import {
  Crown,
  Users,
  Mail,
  MessageSquare,
  Bell,
  Settings,
  Plus,
  Edit,
  Trash2,
  Send,
  Eye,
  Save,
  Download,
  Upload,
  BarChart,
  TrendingUp,
  DollarSign,
  Shield,
  CheckCircle,
  AlertCircle,
  Calendar,
  Clock,
  Filter,
  Search,
  RefreshCw,
  FileText,
  Image,
  Video,
  Phone,
  Smartphone,
  Globe,
  Target,
  Star,
  Gift,
  Package,
  CreditCard,
  Database,
  Lock,
  Key,
  BookOpen,
  ShoppingCart,
  Heart,
  Home,
  Menu,
  Navigation,
  Layers,
  Monitor,
  Code,
  Palette,
  MousePointer,
  Zap,
  Percent,
  MapPin,
  Headphones,
  Award,
  Truck,
  Calculator,
  PieChart,
  RotateCcw,
  Copy,
} from "lucide-react";

const UltimateAdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");

  // Check admin authentication
  useEffect(() => {
    if (!user?.isAdmin) {
      navigate("/giriş");
    }
  }, [user, navigate]);

  if (!user?.isAdmin) {
    return null;
  }

  // Navigation Management State
  const [navigationItems, setNavigationItems] = useState([
    {
      id: 1,
      path: "/",
      label: "Ana Sayfa",
      icon: "Home",
      description: "Platform ana sayfası",
      visible: true,
      order: 1,
    },
    {
      id: 2,
      path: "/yaşam-koçluğu",
      label: "Yaşam Koçluğu",
      icon: "Heart",
      description:
        "İslami değerlerle desteklenen profesyonel yaşam danışmanlığı",
      visible: true,
      order: 2,
    },
    {
      id: 3,
      path: "/meditasyon",
      label: "Dhikr & Meditasyon",
      icon: "Clock",
      description: "İslami zikir ve tefekkür pratikleri",
      visible: true,
      order: 3,
    },
    {
      id: 4,
      path: "/dua",
      label: "Dua & Niyet",
      icon: "Star",
      description: "Günlük dualar ve manevi niyetler",
      visible: true,
      order: 4,
    },
    {
      id: 5,
      path: "/burç",
      label: "Manevi Rehberlik",
      icon: "BookOpen",
      description: "Rüya tabirleri ve manevi analiz",
      visible: true,
      order: 5,
    },
    {
      id: 6,
      path: "/ürünler",
      label: "Manevi Ürünler",
      icon: "ShoppingCart",
      description: "Ruhsal gelişim kitapları ve materyalleri",
      visible: true,
      order: 6,
    },
    {
      id: 7,
      path: "/network",
      label: "Nefs Mertebeleri MLM",
      icon: "Users",
      description: "7 seviyeli manevi gelişim ve kazanç sistemi",
      visible: true,
      order: 7,
    },
  ]);

  // E-commerce Product Management
  const [products, setProducts] = useState([
    {
      id: 1,
      name: "Kur'an-ı Kerim Tefsiri Seti",
      category: "Kitaplar",
      price: 350,
      discountPrice: 280,
      stock: 45,
      description: "Kapsamlı Kur'an tefsiri seti - 10 cilt",
      image: "/api/placeholder/200/200",
      isActive: true,
      isFeatured: true,
      tags: ["bestseller", "featured"],
      rating: 4.8,
      reviews: 124,
    },
    {
      id: 2,
      name: "Zikir Tesbihi - Gümüş",
      category: "Tesbihat",
      price: 120,
      discountPrice: 95,
      stock: 23,
      description: "925 ayar gümüş zikir tesbihi",
      image: "/api/placeholder/200/200",
      isActive: true,
      isFeatured: false,
      tags: ["handmade", "premium"],
      rating: 4.9,
      reviews: 67,
    },
    {
      id: 3,
      name: "Meditasyon Müziği Collection",
      category: "Dijital İçerik",
      price: 50,
      discountPrice: 35,
      stock: 999,
      description: "50+ saatlik rehberli meditasyon müziği",
      image: "/api/placeholder/200/200",
      isActive: true,
      isFeatured: true,
      tags: ["digital", "popular"],
      rating: 4.7,
      reviews: 89,
    },
  ]);

  // MLM System Configuration
  const [mlmConfig, setMlmConfig] = useState({
    systemEnabled: true,
    registrationOpen: true,
    commissionPayouts: true,
    binarySystem: true,
    maxLevels: 7,
    spilloverEnabled: true,
    autoRankAdvancement: true,
    minimumPayout: 50,
    payoutDay: 15,
    currencySymbol: "$",
    levels: [
      {
        id: 1,
        name: "Nefs-i Emmare",
        turkish: "Kötülüğü Emreden Nefs",
        commission: 5,
        requirements: {
          personalSales: 100,
          teamSales: 0,
          directReferrals: 0,
          teamSize: 0,
        },
        benefits: ["5% komisyon", "Başlangıç eğitimi"],
        color: "#ef4444",
      },
      {
        id: 2,
        name: "Nefs-i Levvame",
        turkish: "Kendini Kınayan Nefs",
        commission: 8,
        requirements: {
          personalSales: 250,
          teamSales: 500,
          directReferrals: 3,
          teamSize: 5,
        },
        benefits: ["8% komisyon", "İleri eğitim materyalleri"],
        color: "#f97316",
      },
      {
        id: 3,
        name: "Nefs-i Mülhime",
        turkish: "İlham Alan Nefs",
        commission: 12,
        requirements: {
          personalSales: 500,
          teamSales: 1500,
          directReferrals: 7,
          teamSize: 15,
        },
        benefits: ["12% komisyon", "Liderlik eğitimi", "Bonus programları"],
        color: "#eab308",
      },
      {
        id: 4,
        name: "Nefs-i Mutmaine",
        turkish: "Huzur Bulan Nefs",
        commission: 15,
        requirements: {
          personalSales: 1000,
          teamSales: 5000,
          directReferrals: 15,
          teamSize: 50,
        },
        benefits: ["15% komisyon", "Mentor sertifikası", "Aylık webinarlar"],
        color: "#22c55e",
      },
      {
        id: 5,
        name: "Nefs-i Raziye",
        turkish: "Allah'tan Razı Olan Nefs",
        commission: 18,
        requirements: {
          personalSales: 2000,
          teamSales: 15000,
          directReferrals: 30,
          teamSize: 150,
        },
        benefits: ["18% komisyon", "Özel etkinlik davetleri", "Kişisel koç"],
        color: "#3b82f6",
      },
      {
        id: 6,
        name: "Nefs-i Marziyye",
        turkish: "Allah'ın Razı Olduğu Nefs",
        commission: 22,
        requirements: {
          personalSales: 4000,
          teamSales: 50000,
          directReferrals: 60,
          teamSize: 500,
        },
        benefits: ["22% komisyon", "Yıllık kar payı", "VIP destek"],
        color: "#8b5cf6",
      },
      {
        id: 7,
        name: "Nefs-i Kâmile",
        turkish: "Mükemmel Nefs",
        commission: 25,
        requirements: {
          personalSales: 8000,
          teamSales: 200000,
          directReferrals: 100,
          teamSize: 2000,
        },
        benefits: ["25% komisyon", "Master lider", "Ömür boyu gelir"],
        color: "#f59e0b",
      },
    ],
    bonusPrograms: {
      fastStart: { enabled: true, amount: 100, period: 30 },
      rankAdvancement: { enabled: true, amount: 500 },
      teamVolume: { enabled: true, percentage: 5 },
      leadership: { enabled: true, amount: 1000 },
    },
  });

  // Page Content Management
  const [pageContents, setPageContents] = useState({
    homepage: {
      hero: {
        title: "Manevi Rehberim",
        subtitle: "Ruhsal Gelişim ve İçsel Huzur Platformu",
        description:
          "İslami değerlerle desteklenen manevi gelişim programları, yaşam koçluğu hizmetleri ve MLM sistemi ile hem ruhsal hem de maddi kazanç elde edin.",
        ctaText: "Hemen Başla",
        ctaLink: "/kayıt",
        backgroundImage: "/api/placeholder/1920/1080",
      },
      features: [
        {
          title: "7 Seviyeli Nefs Mertebeleri",
          description:
            "İslami gelenekte yer alan nefs mertebeleri ile manevi gelişim",
          icon: "Star",
        },
        {
          title: "Yaşam Koçluğu",
          description: "Profesyonel rehberlik ile hayatınızı dönüştürün",
          icon: "Heart",
        },
        {
          title: "MLM Sistemi",
          description: "Sürdürülebilir gelir elde edin ve takım oluşturun",
          icon: "TrendingUp",
        },
      ],
      testimonials: [],
      statistics: {
        users: 1247,
        earnings: 89650,
        levels: 7,
        satisfaction: 98,
      },
    },
    coaching: {
      services: [
        {
          name: "Bireysel Koçluk",
          price: 150,
          duration: "60 dakika",
          description: "Kişisel gelişim ve manevi rehberlik",
        },
        {
          name: "Çift Koçluğu",
          price: 200,
          duration: "75 dakika",
          description: "Evlilik ve ilişki danışmanlığı",
        },
        {
          name: "Aile Koçluğu",
          price: 250,
          duration: "90 dakika",
          description: "Aile dinamikleri ve çocuk eğitimi",
        },
      ],
      aboutCoach: {
        name: "Abdul Kadir Kan",
        title: "Sertifikalı Yaşam Koçu",
        experience: "15+ yıl deneyim",
        certifications: ["ICF Sertifikalı", "NLP Master", "İslami Danışmanlık"],
        bio: "15 yılı aşkın deneyimle İslami değerler çerçevesinde yaşam koçluğu hizmeti veriyorum.",
      },
    },
    ecommerce: {
      categories: [
        { id: 1, name: "Kitaplar", count: 45, visible: true },
        { id: 2, name: "Audio Kitaplar", count: 23, visible: true },
        { id: 3, name: "Tesbihat", count: 12, visible: true },
        { id: 4, name: "Dijital İçerik", count: 34, visible: true },
        { id: 5, name: "Meditasyon Müziği", count: 18, visible: true },
        { id: 6, name: "Hediye Setleri", count: 8, visible: true },
      ],
      settings: {
        currency: "TL",
        taxRate: 18,
        shippingFee: 15,
        freeShippingThreshold: 200,
        paymentMethods: ["Kredi Kartı", "Havale/EFT", "Kapıda Ödeme"],
        shippingMethods: ["Kargo", "Kurye", "Mağazadan Teslim"],
      },
    },
  });

  // Website Design Settings
  const [designSettings, setDesignSettings] = useState({
    theme: {
      primaryColor: "#14b8a6", // spiritual-turquoise-500
      secondaryColor: "#a855f7", // spiritual-purple-500
      accentColor: "#f59e0b", // spiritual-gold-500
      backgroundColor: "#f0fdfa", // spiritual-turquoise-50
      textColor: "#1f2937", // gray-800
      fontFamily: "Inter",
      borderRadius: "8px",
    },
    layout: {
      navigationStyle: "horizontal",
      sidebarEnabled: false,
      footerStyle: "full",
      containerWidth: "1280px",
    },
    homepage: {
      heroStyle: "gradient",
      featuresLayout: "grid",
      testimonialsEnabled: true,
      statisticsEnabled: true,
    },
  });

  // Functions for managing content
  const updateNavigationItem = (id: number, updates: any) => {
    setNavigationItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item)),
    );
  };

  const addNavigationItem = (newItem: any) => {
    const maxId = Math.max(...navigationItems.map((item) => item.id));
    setNavigationItems((prev) => [...prev, { ...newItem, id: maxId + 1 }]);
  };

  const deleteNavigationItem = (id: number) => {
    setNavigationItems((prev) => prev.filter((item) => item.id !== id));
  };

  const updateProduct = (id: number, updates: any) => {
    setProducts((prev) =>
      prev.map((product) =>
        product.id === id ? { ...product, ...updates } : product,
      ),
    );
  };

  const addProduct = (newProduct: any) => {
    const maxId = Math.max(...products.map((p) => p.id));
    setProducts((prev) => [...prev, { ...newProduct, id: maxId + 1 }]);
  };

  const deleteProduct = (id: number) => {
    setProducts((prev) => prev.filter((product) => product.id !== id));
  };

  const updateMLMLevel = (id: number, updates: any) => {
    setMlmConfig((prev) => ({
      ...prev,
      levels: prev.levels.map((level) =>
        level.id === id ? { ...level, ...updates } : level,
      ),
    }));
  };

  const updatePageContent = (page: string, section: string, updates: any) => {
    setPageContents((prev) => ({
      ...prev,
      [page]: {
        ...prev[page as keyof typeof prev],
        [section]: {
          ...prev[page as keyof typeof prev][section as any],
          ...updates,
        },
      },
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center">
                <Crown className="w-8 h-8 mr-3 text-yellow-500" />
                Ultimate Admin Kontrol Paneli
              </h1>
              <p className="text-gray-600 mt-2">
                Website'in tüm özelliklerini ve içeriklerini tamamen yönetin
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Badge className="bg-green-100 text-green-800">
                Sistem Aktif
              </Badge>
              <Badge className="bg-blue-100 text-blue-800">
                {products.length} Ürün
              </Badge>
              <Badge className="bg-purple-100 text-purple-800">
                {navigationItems.length} Menü
              </Badge>
            </div>
          </div>
        </div>

        {/* Ultra Comprehensive Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-8">
            <TabsTrigger value="overview">
              <BarChart className="w-4 h-4 mr-2" />
              Genel Bakış
            </TabsTrigger>
            <TabsTrigger value="navigation">
              <Menu className="w-4 h-4 mr-2" />
              Menü Yönetimi
            </TabsTrigger>
            <TabsTrigger value="pages">
              <FileText className="w-4 h-4 mr-2" />
              Sayfa İçerikleri
            </TabsTrigger>
            <TabsTrigger value="ecommerce">
              <ShoppingCart className="w-4 h-4 mr-2" />
              E-Ticaret
            </TabsTrigger>
            <TabsTrigger value="mlm-advanced">
              <TrendingUp className="w-4 h-4 mr-2" />
              MLM Sistemi
            </TabsTrigger>
            <TabsTrigger value="design">
              <Palette className="w-4 h-4 mr-2" />
              Tasarım
            </TabsTrigger>
            <TabsTrigger value="users-advanced">
              <Users className="w-4 h-4 mr-2" />
              Kullanıcılar
            </TabsTrigger>
            <TabsTrigger value="system">
              <Settings className="w-4 h-4 mr-2" />
              Sistem
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Menü Öğeleri
                      </p>
                      <p className="text-2xl font-bold">
                        {navigationItems.length}
                      </p>
                    </div>
                    <Menu className="w-8 h-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Toplam Ürün
                      </p>
                      <p className="text-2xl font-bold">{products.length}</p>
                    </div>
                    <Package className="w-8 h-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        MLM Seviyeleri
                      </p>
                      <p className="text-2xl font-bold">
                        {mlmConfig.levels.length}
                      </p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        Toplam Değer
                      </p>
                      <p className="text-2xl font-bold">
                        {products
                          .reduce((sum, p) => sum + p.price, 0)
                          .toLocaleString()}{" "}
                        TL
                      </p>
                    </div>
                    <DollarSign className="w-8 h-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Management Cards */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Globe className="w-5 h-5 mr-2" />
                    Website Yönetimi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("navigation")}
                    >
                      <Menu className="w-4 h-4 mr-2" />
                      Menü Düzenle
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("pages")}
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      Sayfa İçerikleri
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("design")}
                    >
                      <Palette className="w-4 h-4 mr-2" />
                      Tasarım Ayarları
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    E-Ticaret Kontrolü
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("ecommerce")}
                    >
                      <Package className="w-4 h-4 mr-2" />
                      Ürün Yönetimi
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("ecommerce")}
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Ödeme Ayarları
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => setActiveTab("ecommerce")}
                    >
                      <Truck className="w-4 h-4 mr-2" />
                      Kargo Ayarları
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    MLM Sistem Kontrolü
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Sistem Durumu</span>
                      <Switch
                        checked={mlmConfig.systemEnabled}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            systemEnabled: checked,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Kayıt Açık</span>
                      <Switch
                        checked={mlmConfig.registrationOpen}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            registrationOpen: checked,
                          }))
                        }
                      />
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => setActiveTab("mlm-advanced")}
                    >
                      Detaylı MLM Ayarları
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Navigation Management Tab */}
          <TabsContent value="navigation">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Menü Yönetimi</h2>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Yeni Menü Öğesi
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Yeni Menü Öğesi Ekle</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label>Menü Adı</Label>
                        <Input placeholder="Örn: Hakkımızda" />
                      </div>
                      <div>
                        <Label>URL Yolu</Label>
                        <Input placeholder="Örn: /hakkımızda" />
                      </div>
                      <div>
                        <Label>Açıklama</Label>
                        <Input placeholder="Menü açıklaması" />
                      </div>
                      <div>
                        <Label>İkon</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="İkon seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Home">Ana Sayfa</SelectItem>
                            <SelectItem value="Heart">Kalp</SelectItem>
                            <SelectItem value="Star">Yıldız</SelectItem>
                            <SelectItem value="Users">Kullanıcılar</SelectItem>
                            <SelectItem value="ShoppingCart">
                              Alışveriş
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Sıralama</Label>
                        <Input type="number" placeholder="1" />
                      </div>
                      <Button
                        className="w-full"
                        onClick={() => alert("Menü öğesi eklendi!")}
                      >
                        Menü Öğesi Ekle
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <Card>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Sıra</TableHead>
                        <TableHead>Menü Adı</TableHead>
                        <TableHead>URL</TableHead>
                        <TableHead>Açıklama</TableHead>
                        <TableHead>Görünür</TableHead>
                        <TableHead>İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {navigationItems
                        .sort((a, b) => a.order - b.order)
                        .map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              <Input
                                type="number"
                                value={item.order}
                                onChange={(e) =>
                                  updateNavigationItem(item.id, {
                                    order: parseInt(e.target.value),
                                  })
                                }
                                className="w-16"
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                value={item.label}
                                onChange={(e) =>
                                  updateNavigationItem(item.id, {
                                    label: e.target.value,
                                  })
                                }
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                value={item.path}
                                onChange={(e) =>
                                  updateNavigationItem(item.id, {
                                    path: e.target.value,
                                  })
                                }
                              />
                            </TableCell>
                            <TableCell>
                              <Input
                                value={item.description}
                                onChange={(e) =>
                                  updateNavigationItem(item.id, {
                                    description: e.target.value,
                                  })
                                }
                              />
                            </TableCell>
                            <TableCell>
                              <Switch
                                checked={item.visible}
                                onCheckedChange={(checked) =>
                                  updateNavigationItem(item.id, {
                                    visible: checked,
                                  })
                                }
                              />
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button size="sm" variant="outline">
                                  <Edit className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600"
                                  onClick={() => deleteNavigationItem(item.id)}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Page Content Management Tab */}
          <TabsContent value="pages">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Sayfa İçerik Yönetimi</h2>

              <Tabs defaultValue="homepage-content">
                <TabsList>
                  <TabsTrigger value="homepage-content">Ana Sayfa</TabsTrigger>
                  <TabsTrigger value="coaching-content">
                    Yaşam Koçluğu
                  </TabsTrigger>
                  <TabsTrigger value="meditation-content">
                    Meditasyon
                  </TabsTrigger>
                  <TabsTrigger value="prayer-content">Dua & Niyet</TabsTrigger>
                  <TabsTrigger value="guidance-content">
                    Manevi Rehberlik
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="homepage-content">
                  <div className="grid md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Hero Bölümü</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <Label>Ana Başlık</Label>
                          <Input
                            value={pageContents.homepage.hero.title}
                            onChange={(e) =>
                              updatePageContent("homepage", "hero", {
                                title: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label>Alt Başlık</Label>
                          <Input
                            value={pageContents.homepage.hero.subtitle}
                            onChange={(e) =>
                              updatePageContent("homepage", "hero", {
                                subtitle: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label>Açıklama</Label>
                          <Textarea
                            value={pageContents.homepage.hero.description}
                            onChange={(e) =>
                              updatePageContent("homepage", "hero", {
                                description: e.target.value,
                              })
                            }
                            rows={4}
                          />
                        </div>
                        <div>
                          <Label>Buton Metni</Label>
                          <Input
                            value={pageContents.homepage.hero.ctaText}
                            onChange={(e) =>
                              updatePageContent("homepage", "hero", {
                                ctaText: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label>Buton Linki</Label>
                          <Input
                            value={pageContents.homepage.hero.ctaLink}
                            onChange={(e) =>
                              updatePageContent("homepage", "hero", {
                                ctaLink: e.target.value,
                              })
                            }
                          />
                        </div>
                        <Button
                          onClick={() =>
                            alert("Ana sayfa hero bölümü güncellendi!")
                          }
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Kaydet
                        </Button>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>İstatistikler</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Kullanıcı Sayısı</Label>
                            <Input
                              type="number"
                              value={pageContents.homepage.statistics.users}
                              onChange={(e) =>
                                updatePageContent("homepage", "statistics", {
                                  users: parseInt(e.target.value),
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Toplam Kazanç</Label>
                            <Input
                              type="number"
                              value={pageContents.homepage.statistics.earnings}
                              onChange={(e) =>
                                updatePageContent("homepage", "statistics", {
                                  earnings: parseInt(e.target.value),
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Seviye Sayısı</Label>
                            <Input
                              type="number"
                              value={pageContents.homepage.statistics.levels}
                              onChange={(e) =>
                                updatePageContent("homepage", "statistics", {
                                  levels: parseInt(e.target.value),
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Memnuniyet (%)</Label>
                            <Input
                              type="number"
                              value={
                                pageContents.homepage.statistics.satisfaction
                              }
                              onChange={(e) =>
                                updatePageContent("homepage", "statistics", {
                                  satisfaction: parseInt(e.target.value),
                                })
                              }
                            />
                          </div>
                        </div>
                        <Button
                          onClick={() => alert("İstatistikler güncellendi!")}
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Kaydet
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="coaching-content">
                  <Card>
                    <CardHeader>
                      <CardTitle>Yaşam Koçluğu Hizmetleri</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {pageContents.coaching.services.map(
                          (service, index) => (
                            <div
                              key={index}
                              className="grid md:grid-cols-4 gap-4 p-4 border rounded-lg"
                            >
                              <div>
                                <Label>Hizmet Adı</Label>
                                <Input
                                  value={service.name}
                                  onChange={(e) => {
                                    const updatedServices = [
                                      ...pageContents.coaching.services,
                                    ];
                                    updatedServices[index].name =
                                      e.target.value;
                                    updatePageContent(
                                      "coaching",
                                      "services",
                                      updatedServices,
                                    );
                                  }}
                                />
                              </div>
                              <div>
                                <Label>Fiyat (TL)</Label>
                                <Input
                                  type="number"
                                  value={service.price}
                                  onChange={(e) => {
                                    const updatedServices = [
                                      ...pageContents.coaching.services,
                                    ];
                                    updatedServices[index].price = parseInt(
                                      e.target.value,
                                    );
                                    updatePageContent(
                                      "coaching",
                                      "services",
                                      updatedServices,
                                    );
                                  }}
                                />
                              </div>
                              <div>
                                <Label>Süre</Label>
                                <Input
                                  value={service.duration}
                                  onChange={(e) => {
                                    const updatedServices = [
                                      ...pageContents.coaching.services,
                                    ];
                                    updatedServices[index].duration =
                                      e.target.value;
                                    updatePageContent(
                                      "coaching",
                                      "services",
                                      updatedServices,
                                    );
                                  }}
                                />
                              </div>
                              <div>
                                <Label>Açıklama</Label>
                                <Input
                                  value={service.description}
                                  onChange={(e) => {
                                    const updatedServices = [
                                      ...pageContents.coaching.services,
                                    ];
                                    updatedServices[index].description =
                                      e.target.value;
                                    updatePageContent(
                                      "coaching",
                                      "services",
                                      updatedServices,
                                    );
                                  }}
                                />
                              </div>
                            </div>
                          ),
                        )}
                        <Button
                          onClick={() =>
                            alert("Yaşam koçluğu hizmetleri güncellendi!")
                          }
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Hizmetleri Kaydet
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </TabsContent>

          {/* E-commerce Management Tab */}
          <TabsContent value="ecommerce">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">E-Ticaret Yönetimi</h2>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Yeni Ürün Ekle
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Yeni Ürün Ekle</DialogTitle>
                    </DialogHeader>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label>Ürün Adı</Label>
                        <Input placeholder="Ürün adını girin" />
                      </div>
                      <div>
                        <Label>Kategori</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Kategori seçin" />
                          </SelectTrigger>
                          <SelectContent>
                            {pageContents.ecommerce.categories.map((cat) => (
                              <SelectItem key={cat.id} value={cat.name}>
                                {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Fiyat (TL)</Label>
                        <Input type="number" placeholder="0" />
                      </div>
                      <div>
                        <Label>İndirimli Fiyat (TL)</Label>
                        <Input type="number" placeholder="0" />
                      </div>
                      <div>
                        <Label>Stok Adedi</Label>
                        <Input type="number" placeholder="0" />
                      </div>
                      <div>
                        <Label>Puan (1-5)</Label>
                        <Input
                          type="number"
                          min="1"
                          max="5"
                          placeholder="4.5"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label>Ürün Açıklaması</Label>
                        <Textarea placeholder="Ürün detayları..." rows={3} />
                      </div>
                      <div className="md:col-span-2">
                        <Label>Etiketler (virgülle ayırın)</Label>
                        <Input placeholder="bestseller, featured, premium" />
                      </div>
                      <div className="md:col-span-2 flex space-x-3">
                        <div className="flex items-center space-x-2">
                          <Switch />
                          <Label>Ürünü Aktif Et</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch />
                          <Label>Öne Çıkar</Label>
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <Button
                          className="w-full"
                          onClick={() => alert("Ürün eklendi!")}
                        >
                          Ürün Ekle
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid md:grid-cols-3 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Ödeme Ayarları</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Para Birimi</Label>
                      <Select value={pageContents.ecommerce.settings.currency}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="TL">Türk Lirası (TL)</SelectItem>
                          <SelectItem value="USD">Dolar ($)</SelectItem>
                          <SelectItem value="EUR">Euro (€)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>KDV Oranı (%)</Label>
                      <Input
                        type="number"
                        value={pageContents.ecommerce.settings.taxRate}
                        onChange={(e) =>
                          updatePageContent("ecommerce", "settings", {
                            taxRate: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Kargo Ücreti (TL)</Label>
                      <Input
                        type="number"
                        value={pageContents.ecommerce.settings.shippingFee}
                        onChange={(e) =>
                          updatePageContent("ecommerce", "settings", {
                            shippingFee: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label>Ücretsiz Kargo Limiti (TL)</Label>
                      <Input
                        type="number"
                        value={
                          pageContents.ecommerce.settings.freeShippingThreshold
                        }
                        onChange={(e) =>
                          updatePageContent("ecommerce", "settings", {
                            freeShippingThreshold: parseInt(e.target.value),
                          })
                        }
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Kategori Yönetimi</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {pageContents.ecommerce.categories.map((category) => (
                        <div
                          key={category.id}
                          className="flex items-center justify-between p-2 border rounded"
                        >
                          <div>
                            <span className="font-medium">{category.name}</span>
                            <Badge className="ml-2">{category.count}</Badge>
                          </div>
                          <Switch checked={category.visible} />
                        </div>
                      ))}
                      <Button variant="outline" className="w-full">
                        <Plus className="w-4 h-4 mr-2" />
                        Yeni Kategori
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>İstatistikler</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span>Toplam Ürün:</span>
                        <span className="font-bold">{products.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aktif Ürün:</span>
                        <span className="font-bold">
                          {products.filter((p) => p.isActive).length}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Öne Çıkan:</span>
                        <span className="font-bold">
                          {products.filter((p) => p.isFeatured).length}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Toplam Değer:</span>
                        <span className="font-bold">
                          {products
                            .reduce((sum, p) => sum + p.price, 0)
                            .toLocaleString()}{" "}
                          TL
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Products Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Ürün Listesi</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Ürün</TableHead>
                        <TableHead>Kategori</TableHead>
                        <TableHead>Fiyat</TableHead>
                        <TableHead>Stok</TableHead>
                        <TableHead>Puan</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead>İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.map((product) => (
                        <TableRow key={product.id}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <img
                                src={product.image}
                                alt={product.name}
                                className="w-12 h-12 rounded-lg object-cover"
                              />
                              <div>
                                <div className="font-medium">
                                  {product.name}
                                </div>
                                <div className="text-sm text-gray-500">
                                  {product.description.substring(0, 50)}...
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{product.category}</Badge>
                          </TableCell>
                          <TableCell>
                            <div>
                              <div className="font-medium">
                                {product.price} TL
                              </div>
                              {product.discountPrice && (
                                <div className="text-sm text-green-600">
                                  {product.discountPrice} TL
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                product.stock < 10
                                  ? "bg-red-100 text-red-800"
                                  : "bg-green-100 text-green-800"
                              }
                            >
                              {product.stock}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 text-yellow-500 mr-1" />
                              {product.rating}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Switch
                                checked={product.isActive}
                                onCheckedChange={(checked) =>
                                  updateProduct(product.id, {
                                    isActive: checked,
                                  })
                                }
                              />
                              {product.isFeatured && (
                                <Badge className="bg-yellow-100 text-yellow-800">
                                  Öne Çıkan
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Copy className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-red-600"
                                onClick={() => deleteProduct(product.id)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Advanced MLM System Tab */}
          <TabsContent value="mlm-advanced">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">
                Gelişmiş MLM Sistem Yönetimi
              </h2>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Sistem Konfigürasyonu</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>MLM Sistemi Aktif</Label>
                      <Switch
                        checked={mlmConfig.systemEnabled}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            systemEnabled: checked,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Yeni Kayıtlar</Label>
                      <Switch
                        checked={mlmConfig.registrationOpen}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            registrationOpen: checked,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Komisyon Ödemeleri</Label>
                      <Switch
                        checked={mlmConfig.commissionPayouts}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            commissionPayouts: checked,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Binary Sistem</Label>
                      <Switch
                        checked={mlmConfig.binarySystem}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            binarySystem: checked,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Spillover Aktif</Label>
                      <Switch
                        checked={mlmConfig.spilloverEnabled}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            spilloverEnabled: checked,
                          }))
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Otomatik Terfi</Label>
                      <Switch
                        checked={mlmConfig.autoRankAdvancement}
                        onCheckedChange={(checked) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            autoRankAdvancement: checked,
                          }))
                        }
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Ödeme Ayarları</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Minimum Ödeme Tutarı</Label>
                      <Input
                        type="number"
                        value={mlmConfig.minimumPayout}
                        onChange={(e) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            minimumPayout: parseInt(e.target.value),
                          }))
                        }
                      />
                    </div>
                    <div>
                      <Label>Ödeme Günü (Ay içinde)</Label>
                      <Input
                        type="number"
                        min="1"
                        max="28"
                        value={mlmConfig.payoutDay}
                        onChange={(e) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            payoutDay: parseInt(e.target.value),
                          }))
                        }
                      />
                    </div>
                    <div>
                      <Label>Para Birimi Sembolü</Label>
                      <Select value={mlmConfig.currencySymbol}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="$">Dolar ($)</SelectItem>
                          <SelectItem value="₺">Türk Lirası (₺)</SelectItem>
                          <SelectItem value="€">Euro (€)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Maksimum Seviye</Label>
                      <Input
                        type="number"
                        min="3"
                        max="10"
                        value={mlmConfig.maxLevels}
                        onChange={(e) =>
                          setMlmConfig((prev) => ({
                            ...prev,
                            maxLevels: parseInt(e.target.value),
                          }))
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* MLM Levels Management */}
              <Card>
                <CardHeader>
                  <CardTitle>Nefs Mertebeleri Yönetimi</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {mlmConfig.levels.map((level) => (
                      <div key={level.id} className="p-4 border rounded-lg">
                        <div className="grid md:grid-cols-4 gap-4 mb-4">
                          <div>
                            <Label>Seviye Adı</Label>
                            <Input
                              value={level.name}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  name: e.target.value,
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Türkçe Adı</Label>
                            <Input
                              value={level.turkish}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  turkish: e.target.value,
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Komisyon (%)</Label>
                            <Input
                              type="number"
                              value={level.commission}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  commission: parseInt(e.target.value),
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Renk</Label>
                            <Input
                              type="color"
                              value={level.color}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  color: e.target.value,
                                })
                              }
                            />
                          </div>
                        </div>

                        <div className="grid md:grid-cols-4 gap-4 mb-4">
                          <div>
                            <Label>Kişisel Satış</Label>
                            <Input
                              type="number"
                              value={level.requirements.personalSales}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  requirements: {
                                    ...level.requirements,
                                    personalSales: parseInt(e.target.value),
                                  },
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Takım Satışı</Label>
                            <Input
                              type="number"
                              value={level.requirements.teamSales}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  requirements: {
                                    ...level.requirements,
                                    teamSales: parseInt(e.target.value),
                                  },
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Direkt Referans</Label>
                            <Input
                              type="number"
                              value={level.requirements.directReferrals}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  requirements: {
                                    ...level.requirements,
                                    directReferrals: parseInt(e.target.value),
                                  },
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label>Takım Boyutu</Label>
                            <Input
                              type="number"
                              value={level.requirements.teamSize}
                              onChange={(e) =>
                                updateMLMLevel(level.id, {
                                  requirements: {
                                    ...level.requirements,
                                    teamSize: parseInt(e.target.value),
                                  },
                                })
                              }
                            />
                          </div>
                        </div>

                        <div>
                          <Label>Faydalar (virgülle ayırın)</Label>
                          <Input
                            value={level.benefits.join(", ")}
                            onChange={(e) =>
                              updateMLMLevel(level.id, {
                                benefits: e.target.value
                                  .split(",")
                                  .map((b) => b.trim()),
                              })
                            }
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Bonus Programs */}
              <Card>
                <CardHeader>
                  <CardTitle>Bonus Programları</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label>Hızlı Başlangıç Bonusu</Label>
                        <Switch
                          checked={mlmConfig.bonusPrograms.fastStart.enabled}
                          onCheckedChange={(checked) =>
                            setMlmConfig((prev) => ({
                              ...prev,
                              bonusPrograms: {
                                ...prev.bonusPrograms,
                                fastStart: {
                                  ...prev.bonusPrograms.fastStart,
                                  enabled: checked,
                                },
                              },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label>Bonus Tutarı ({mlmConfig.currencySymbol})</Label>
                        <Input
                          type="number"
                          value={mlmConfig.bonusPrograms.fastStart.amount}
                          onChange={(e) =>
                            setMlmConfig((prev) => ({
                              ...prev,
                              bonusPrograms: {
                                ...prev.bonusPrograms,
                                fastStart: {
                                  ...prev.bonusPrograms.fastStart,
                                  amount: parseInt(e.target.value),
                                },
                              },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label>Süre (Gün)</Label>
                        <Input
                          type="number"
                          value={mlmConfig.bonusPrograms.fastStart.period}
                          onChange={(e) =>
                            setMlmConfig((prev) => ({
                              ...prev,
                              bonusPrograms: {
                                ...prev.bonusPrograms,
                                fastStart: {
                                  ...prev.bonusPrograms.fastStart,
                                  period: parseInt(e.target.value),
                                },
                              },
                            }))
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label>Seviye Yükselme Bonusu</Label>
                        <Switch
                          checked={
                            mlmConfig.bonusPrograms.rankAdvancement.enabled
                          }
                          onCheckedChange={(checked) =>
                            setMlmConfig((prev) => ({
                              ...prev,
                              bonusPrograms: {
                                ...prev.bonusPrograms,
                                rankAdvancement: {
                                  ...prev.bonusPrograms.rankAdvancement,
                                  enabled: checked,
                                },
                              },
                            }))
                          }
                        />
                      </div>
                      <div>
                        <Label>Bonus Tutarı ({mlmConfig.currencySymbol})</Label>
                        <Input
                          type="number"
                          value={mlmConfig.bonusPrograms.rankAdvancement.amount}
                          onChange={(e) =>
                            setMlmConfig((prev) => ({
                              ...prev,
                              bonusPrograms: {
                                ...prev.bonusPrograms,
                                rankAdvancement: {
                                  ...prev.bonusPrograms.rankAdvancement,
                                  amount: parseInt(e.target.value),
                                },
                              },
                            }))
                          }
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Design Settings Tab */}
          <TabsContent value="design">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Website Tasarım Ayarları</h2>

              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Renk Teması</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Ana Renk</Label>
                      <div className="flex space-x-2">
                        <Input
                          type="color"
                          value={designSettings.theme.primaryColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                primaryColor: e.target.value,
                              },
                            }))
                          }
                          className="w-16"
                        />
                        <Input
                          value={designSettings.theme.primaryColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                primaryColor: e.target.value,
                              },
                            }))
                          }
                        />
                      </div>
                    </div>
                    <div>
                      <Label>İkinci Renk</Label>
                      <div className="flex space-x-2">
                        <Input
                          type="color"
                          value={designSettings.theme.secondaryColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                secondaryColor: e.target.value,
                              },
                            }))
                          }
                          className="w-16"
                        />
                        <Input
                          value={designSettings.theme.secondaryColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                secondaryColor: e.target.value,
                              },
                            }))
                          }
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Vurgu Rengi</Label>
                      <div className="flex space-x-2">
                        <Input
                          type="color"
                          value={designSettings.theme.accentColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                accentColor: e.target.value,
                              },
                            }))
                          }
                          className="w-16"
                        />
                        <Input
                          value={designSettings.theme.accentColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                accentColor: e.target.value,
                              },
                            }))
                          }
                        />
                      </div>
                    </div>
                    <div>
                      <Label>Arka Plan Rengi</Label>
                      <div className="flex space-x-2">
                        <Input
                          type="color"
                          value={designSettings.theme.backgroundColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                backgroundColor: e.target.value,
                              },
                            }))
                          }
                          className="w-16"
                        />
                        <Input
                          value={designSettings.theme.backgroundColor}
                          onChange={(e) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              theme: {
                                ...prev.theme,
                                backgroundColor: e.target.value,
                              },
                            }))
                          }
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Tipografi ve Layout</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Font Ailesi</Label>
                      <Select value={designSettings.theme.fontFamily}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Inter">Inter</SelectItem>
                          <SelectItem value="Roboto">Roboto</SelectItem>
                          <SelectItem value="Open Sans">Open Sans</SelectItem>
                          <SelectItem value="Lato">Lato</SelectItem>
                          <SelectItem value="Poppins">Poppins</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Köşe Yuvarlaklığı</Label>
                      <Select value={designSettings.theme.borderRadius}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0px">Keskin (0px)</SelectItem>
                          <SelectItem value="4px">Az (4px)</SelectItem>
                          <SelectItem value="8px">Orta (8px)</SelectItem>
                          <SelectItem value="12px">Yuvarlak (12px)</SelectItem>
                          <SelectItem value="16px">
                            Çok Yuvarlak (16px)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Navigasyon Stili</Label>
                      <Select value={designSettings.layout.navigationStyle}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="horizontal">Yatay</SelectItem>
                          <SelectItem value="vertical">Dikey</SelectItem>
                          <SelectItem value="mega">Mega Menü</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Maksimum Genişlik</Label>
                      <Select value={designSettings.layout.containerWidth}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1280px">
                            Standard (1280px)
                          </SelectItem>
                          <SelectItem value="1440px">Geniş (1440px)</SelectItem>
                          <SelectItem value="1920px">
                            Extra Geniş (1920px)
                          </SelectItem>
                          <SelectItem value="100%">Tam Genişlik</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Ana Sayfa Tasarımı</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label>Hero Bölümü Stili</Label>
                      <Select value={designSettings.homepage.heroStyle}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="gradient">Gradient</SelectItem>
                          <SelectItem value="image">Resim</SelectItem>
                          <SelectItem value="video">Video</SelectItem>
                          <SelectItem value="solid">Düz Renk</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Özellikler Layout</Label>
                      <Select value={designSettings.homepage.featuresLayout}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="grid">Grid</SelectItem>
                          <SelectItem value="carousel">Kaydırmalı</SelectItem>
                          <SelectItem value="list">Liste</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={designSettings.homepage.testimonialsEnabled}
                          onCheckedChange={(checked) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              homepage: {
                                ...prev.homepage,
                                testimonialsEnabled: checked,
                              },
                            }))
                          }
                        />
                        <Label>Testimonial Göster</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={designSettings.homepage.statisticsEnabled}
                          onCheckedChange={(checked) =>
                            setDesignSettings((prev) => ({
                              ...prev,
                              homepage: {
                                ...prev.homepage,
                                statisticsEnabled: checked,
                              },
                            }))
                          }
                        />
                        <Label>İstatistikler Göster</Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Tasarım Önizleme</CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    className="p-6 rounded-lg border-2"
                    style={{
                      backgroundColor: designSettings.theme.backgroundColor,
                      borderColor: designSettings.theme.primaryColor,
                      fontFamily: designSettings.theme.fontFamily,
                    }}
                  >
                    <div
                      className="text-center p-4 rounded"
                      style={{
                        background: `linear-gradient(135deg, ${designSettings.theme.primaryColor}, ${designSettings.theme.secondaryColor})`,
                        borderRadius: designSettings.theme.borderRadius,
                        color: "white",
                      }}
                    >
                      <h3 className="text-xl font-bold mb-2">
                        Manevi Rehberim
                      </h3>
                      <p>Tasarım önizlemesi</p>
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-4">
                      <div
                        className="p-3 text-center rounded"
                        style={{
                          backgroundColor: designSettings.theme.primaryColor,
                          borderRadius: designSettings.theme.borderRadius,
                          color: "white",
                        }}
                      >
                        Ana Renk
                      </div>
                      <div
                        className="p-3 text-center rounded"
                        style={{
                          backgroundColor: designSettings.theme.secondaryColor,
                          borderRadius: designSettings.theme.borderRadius,
                          color: "white",
                        }}
                      >
                        İkinci Renk
                      </div>
                      <div
                        className="p-3 text-center rounded"
                        style={{
                          backgroundColor: designSettings.theme.accentColor,
                          borderRadius: designSettings.theme.borderRadius,
                          color: "white",
                        }}
                      >
                        Vurgu Rengi
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-center">
                    <Button
                      onClick={() => alert("Tasarım ayarları uygulandı!")}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Tasarımı Uygula
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Advanced Users Tab */}
          <TabsContent value="users-advanced">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">
                Gelişmiş Kullanıcı Yönetimi
              </h2>
              {/* This would include the previous user management features */}
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Kullanıcı yönetimi özellikleri önceki sekmelerde mevcuttur. Bu
                  sekme ek gelişmiş özellikler için ayrılmıştır.
                </AlertDescription>
              </Alert>
            </div>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Sistem Yönetimi</h2>

              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Sistem Durumu</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Website Aktif</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>MLM Sistemi</span>
                      <Switch checked={mlmConfig.systemEnabled} />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>E-Ticaret</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Kayıt Sistemi</span>
                      <Switch checked={mlmConfig.registrationOpen} />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Email Bildirimleri</span>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>SMS Bildirimleri</span>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sistem Bilgileri</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Platform Versiyonu:</span>
                        <span className="font-bold">v2.1.0</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Son Güncelleme:</span>
                        <span className="font-bold">20 Ocak 2024</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Toplam Sayfa:</span>
                        <span className="font-bold">
                          {navigationItems.length}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Aktif Modüller:</span>
                        <span className="font-bold">8</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Veritabanı Boyutu:</span>
                        <span className="font-bold">245 MB</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Yedekleme Durumu:</span>
                        <Badge className="bg-green-100 text-green-800">
                          Güncel
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Yedekleme ve Bakım</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button className="w-full" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Tam Sistem Yedeği Al
                    </Button>
                    <Button className="w-full" variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Yedek Geri Yükle
                    </Button>
                    <Button className="w-full" variant="outline">
                      <Database className="w-4 h-4 mr-2" />
                      Veritabanını Optimize Et
                    </Button>
                    <Button className="w-full" variant="outline">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Cache Temizle
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Admin Güvenlik</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Admin Kullanıcı Adı</Label>
                      <Input value="abdulkadirkan" readOnly />
                    </div>
                    <div>
                      <Label>Şifre</Label>
                      <Input type="password" value="Abdulkadir1983." readOnly />
                    </div>
                    <Button className="w-full" variant="outline">
                      <Key className="w-4 h-4 mr-2" />
                      Şifre Değiştir
                    </Button>
                    <Button className="w-full" variant="outline">
                      <Shield className="w-4 h-4 mr-2" />
                      İki Faktörlü Kimlik Doğrulama
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UltimateAdminPanel;
