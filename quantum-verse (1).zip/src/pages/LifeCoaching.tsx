import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import {
  Heart,
  Star,
  Users,
  Calendar,
  Clock,
  Target,
  Brain,
  TrendingUp,
  Shield,
  CheckCircle,
  MessageSquare,
  Video,
  Phone,
  Mail,
} from "lucide-react";

const LifeCoaching = () => {
  const { user } = useAuth();
  const [selectedService, setSelectedService] = useState(null);

  const coachingServices = [
    {
      id: 1,
      title: "Bireysel Yaşam Koçluğu",
      description:
        "Kişisel hedeflerinize ulaşmanız için birebir rehberlik ve destek",
      duration: "60 dakika",
      price: 50,
      features: [
        "Kişisel değerlendirme",
        "Hedef belirleme",
        "Eylem planı oluşturma",
        "Haftalık takip",
        "Motivasyon desteği",
      ],
      icon: Target,
      color: "spiritual-turquoise",
    },
    {
      id: 2,
      title: "Kariyer Danışmanlığı",
      description:
        "Profesyonel yaşamınızda doğru kararlar almanız için uzman desteği",
      duration: "90 dakika",
      price: 75,
      features: [
        "Kariyer analizi",
        "CV optimizasyonu",
        "Mülakat hazırlığı",
        "Networking stratejileri",
        "İş-yaşam dengesi",
      ],
      icon: TrendingUp,
      color: "spiritual-purple",
    },
    {
      id: 3,
      title: "İlişki Koçluğu",
      description:
        "Kişisel ve profesyonel ilişkilerinizi güçlendirmeniz için rehberlik",
      duration: "75 dakika",
      price: 60,
      features: [
        "İletişim becerileri",
        "Empati geliştirme",
        "Çatışma çözümü",
        "Sınır belirleme",
        "Duygusal zeka",
      ],
      icon: Heart,
      color: "spiritual-gold",
    },
    {
      id: 4,
      title: "Stres ve Anksiyete Yönetimi",
      description:
        "Stresinizi yönetmeniz ve anksiyetenizi azaltmanız için etkili teknikler",
      duration: "60 dakika",
      price: 55,
      features: [
        "Stres kaynaklarını belirleme",
        "Nefes teknikleri",
        "Zihinsel egzersizler",
        "Rahatlama teknikleri",
        "Günlük rutinler",
      ],
      icon: Brain,
      color: "green",
    },
  ];

  const groupSessions = [
    {
      title: "Motivasyon ve Hedef Belirleme Grubu",
      schedule: "Her Salı 19:00",
      price: 30,
      maxParticipants: 8,
      duration: "90 dakika",
    },
    {
      title: "Mindfulness ve Farkındalık Grubu",
      schedule: "Her Perşembe 20:00",
      price: 25,
      maxParticipants: 12,
      duration: "75 dakika",
    },
    {
      title: "Kariyer Geliştirme Workshop'u",
      schedule: "Aylık Workshop",
      price: 100,
      maxParticipants: 15,
      duration: "4 saat",
    },
  ];

  const packageDeals = [
    {
      title: "Temel Gelişim Paketi",
      sessions: 4,
      originalPrice: 200,
      packagePrice: 180,
      validity: "2 ay",
      features: [
        "4 bireysel seans",
        "WhatsApp desteği",
        "Haftalık değerlendirme",
        "Kişisel eylem planı",
      ],
    },
    {
      title: "Premium Dönüşüm Paketi",
      sessions: 8,
      originalPrice: 400,
      packagePrice: 320,
      validity: "3 ay",
      features: [
        "8 bireysel seans",
        "24/7 WhatsApp desteği",
        "Haftalık video değerlendirme",
        "Kişiselleştirilmiş araçlar",
        "Grup seanslarına ücretsiz katılım",
      ],
      recommended: true,
    },
    {
      title: "Elite Liderlik Paketi",
      sessions: 12,
      originalPrice: 600,
      packagePrice: 450,
      validity: "4 ay",
      features: [
        "12 bireysel seans",
        "7/24 öncelikli destek",
        "Aylık detaylı raporlar",
        "Liderlik becerileri eğitimi",
        "Tüm grup etkinliklerine erişim",
        "Özel networking etkinlikleri",
      ],
    },
  ];

  const testimonials = [
    {
      name: "Ayşe K.",
      role: "Pazarlama Müdürü",
      comment:
        "Psikolog Abdulkadir Kan ile çalışmak hayatımı değiştirdi. Kariyer hedeflerimi netleştirdim ve özgüvenimi artırdım.",
      rating: 5,
    },
    {
      name: "Mehmet R.",
      role: "Girişimci",
      comment:
        "Stres yönetimi konusunda aldığım eğitim sayesinde hem iş hem de özel hayatımda büyük iyileşmeler yaşadım.",
      rating: 5,
    },
    {
      name: "Zeynep T.",
      role: "Öğretmen",
      comment:
        "Grup seansları çok faydalıydı. Farklı perspektifler görme fırsatı buldum ve motivasyonum arttı.",
      rating: 5,
    },
  ];

  const getDailyTip = () => {
    const tips = [
      "Günde 5 dakika derin nefes egzersizi yapın",
      "Hedeflerinizi yazılı olarak belirleyin",
      "Günlük minnet listesi tutun",
      "Kendinize pozitif afirmasyonlar söyleyin",
      "Her gün yeni bir şey öğrenmeye odaklanın",
      "Doğayla bağlantı kuracak zaman ayırın",
      "Geçmiş başarılarınızı hatırlayın",
    ];
    const today = new Date().getDay();
    return tips[today];
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-spiritual-gradient rounded-full flex items-center justify-center">
              <Heart className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Profesyonel Yaşam Koçluğu
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Psikolog Abdulkadir Kan rehberliğinde, yaşamınızın her alanında
            gelişim sağlayın. Modern psikoloji ve İslami değerlerle desteklenen
            koçluk hizmetleri.
          </p>
          <div className="mt-6 bg-spiritual-turquoise-50 border border-spiritual-turquoise-200 rounded-lg p-4 max-w-2xl mx-auto">
            <h3 className="font-semibold text-spiritual-turquoise-700 mb-2">
              💡 Günün Koçluk İpucu
            </h3>
            <p className="text-spiritual-turquoise-600">{getDailyTip()}</p>
          </div>
        </div>

        <Tabs defaultValue="services" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="services">Hizmetler</TabsTrigger>
            <TabsTrigger value="packages">Paketler</TabsTrigger>
            <TabsTrigger value="group">Grup Seansları</TabsTrigger>
            <TabsTrigger value="about">Hakkında</TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="space-y-8">
            <div className="grid md:grid-cols-2 gap-6">
              {coachingServices.map((service) => (
                <Card
                  key={service.id}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 cursor-pointer group"
                  onClick={() => setSelectedService(service)}
                >
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div
                        className={`p-3 rounded-full bg-${service.color}-100`}
                      >
                        <service.icon
                          className={`w-6 h-6 text-${service.color}-600`}
                        />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-lg group-hover:text-spiritual-turquoise-600 transition-colors">
                          {service.title}
                        </CardTitle>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className="text-sm text-gray-500 flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {service.duration}
                          </span>
                          <span className="text-lg font-bold text-spiritual-gold-600">
                            ${service.price}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{service.description}</p>
                    <ul className="space-y-2">
                      {service.features.slice(0, 3).map((feature, index) => (
                        <li
                          key={index}
                          className="flex items-center space-x-2 text-sm"
                        >
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full mt-4 bg-spiritual-gradient text-white">
                      Randevu Al
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="packages" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-6">
              {packageDeals.map((pkg, index) => (
                <Card
                  key={index}
                  className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 relative ${
                    pkg.recommended
                      ? "ring-2 ring-spiritual-gold-400 scale-105"
                      : ""
                  }`}
                >
                  {pkg.recommended && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-spiritual-gold-500 text-white">
                        Önerilen
                      </Badge>
                    </div>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle className="text-xl">{pkg.title}</CardTitle>
                    <div className="space-y-2">
                      <div className="flex items-center justify-center space-x-2">
                        <span className="text-3xl font-bold text-spiritual-turquoise-600">
                          ${pkg.packagePrice}
                        </span>
                        <span className="text-lg text-gray-400 line-through">
                          ${pkg.originalPrice}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        {pkg.sessions} seans • Geçerlilik: {pkg.validity}
                      </p>
                      <p className="text-xs text-spiritual-gold-600 font-medium">
                        %
                        {Math.round(
                          ((pkg.originalPrice - pkg.packagePrice) /
                            pkg.originalPrice) *
                            100,
                        )}{" "}
                        tasarruf
                      </p>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      {pkg.features.map((feature, featureIndex) => (
                        <li
                          key={featureIndex}
                          className="flex items-center space-x-2 text-sm"
                        >
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      className={`w-full ${
                        pkg.recommended
                          ? "bg-spiritual-gradient text-white"
                          : "border border-spiritual-turquoise-300 text-spiritual-turquoise-700 hover:bg-spiritual-turquoise-50"
                      }`}
                      variant={pkg.recommended ? "default" : "outline"}
                    >
                      Paketi Seç
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="group" className="space-y-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {groupSessions.map((session, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle className="text-lg">{session.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-spiritual-turquoise-600" />
                        <span>{session.schedule}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-spiritual-purple-600" />
                        <span>{session.duration}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-spiritual-gold-600" />
                        <span>Max {session.maxParticipants} kişi</span>
                      </div>
                    </div>
                    <div className="text-center">
                      <span className="text-2xl font-bold text-spiritual-turquoise-600">
                        ${session.price}
                      </span>
                      <p className="text-xs text-gray-500">seans başına</p>
                    </div>
                    <Button className="w-full bg-spiritual-gradient text-white">
                      Gruba Katıl
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="bg-spiritual-purple-50 border-spiritual-purple-200">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-spiritual-purple-700 mb-4">
                  Grup Seanslarının Avantajları
                </h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-spiritual-purple-600">
                  <ul className="space-y-2">
                    <li>• Farklı perspektifler keşfetme</li>
                    <li>• Sosyal destek ağı oluşturma</li>
                    <li>• Maliyet etkin çözümler</li>
                  </ul>
                  <ul className="space-y-2">
                    <li>• Motivasyon artışı</li>
                    <li>• Deneyim paylaşımı</li>
                    <li>• Kolektif öğrenme</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="about" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="w-6 h-6 text-spiritual-turquoise-600" />
                      <span>Psikolog Abdulkadir Kan</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700 leading-relaxed">
                      Modern psikoloji ve İslami değerleri harmanlayarak,
                      bireylerin ruhsal ve zihinsel gelişimlerini destekleyen
                      uzman bir yaşam koçu. 15+ yıllık deneyimi ile binlerce
                      kişinin yaşamında olumlu değişiklikler yaratmıştır.
                    </p>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold text-spiritual-turquoise-700 mb-2">
                          Uzmanlık Alanları:
                        </h4>
                        <ul className="space-y-1 text-sm text-gray-600">
                          <li>• Kişisel Gelişim ve Motivasyon</li>
                          <li>• Stres ve Anksiyete Yönetimi</li>
                          <li>• Kariyer Danışmanlığı</li>
                          <li>• İlişki Koçluğu</li>
                          <li>• Manevi Danışmanlık</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold text-spiritual-purple-700 mb-2">
                          Eğitim ve Sertifikalar:
                        </h4>
                        <ul className="space-y-1 text-sm text-gray-600">
                          <li>• Psikoloji Lisans Derecesi</li>
                          <li>• ICF Akredite Koç</li>
                          <li>• NLP Practitioner</li>
                          <li>• Mindfulness Eğitmeni</li>
                          <li>• İslami Danışmanlık Sertifikası</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Müşteri Yorumları</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {testimonials.map((testimonial, index) => (
                      <div
                        key={index}
                        className="bg-gray-50 p-4 rounded-lg border border-gray-200"
                      >
                        <div className="flex items-center space-x-2 mb-2">
                          <div className="flex space-x-1">
                            {[...Array(testimonial.rating)].map((_, i) => (
                              <Star
                                key={i}
                                className="w-4 h-4 text-spiritual-gold-500 fill-current"
                              />
                            ))}
                          </div>
                          <span className="text-sm font-medium">
                            {testimonial.name}
                          </span>
                          <span className="text-xs text-gray-500">
                            {testimonial.role}
                          </span>
                        </div>
                        <p className="text-gray-700 text-sm italic">
                          "{testimonial.comment}"
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-lg">İletişim</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-5 h-5 text-spiritual-turquoise-600" />
                        <span className="text-sm">
                          psikologabdulkadirkan@gmail.com
                        </span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Phone className="w-5 h-5 text-spiritual-purple-600" />
                        <span className="text-sm">+90 555 123 4567</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Video className="w-5 h-5 text-spiritual-gold-600" />
                        <span className="text-sm">Online Seanslar Mevcut</span>
                      </div>
                    </div>

                    <Button className="w-full bg-spiritual-gradient text-white">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Ücretsiz Görüşme Talep Et
                    </Button>
                  </CardContent>
                </Card>

                <Card className="bg-spiritual-gold-50 border-spiritual-gold-200">
                  <CardHeader>
                    <CardTitle className="text-lg text-spiritual-gold-700">
                      Özel Fırsat
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-spiritual-gold-600 text-sm mb-4">
                      İlk seansınız %50 indirimli! Yaşam koçluğu yolculuğunuza
                      uygun maliyetle başlayın.
                    </p>
                    <Button className="w-full bg-spiritual-gold-600 text-white hover:bg-spiritual-gold-700">
                      İndirimli Seans Al
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default LifeCoaching;
