import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

export interface User {
  id: string;
  email: string;
  name: string;
  sponsorId?: string;
  referralCode: string;
  level: number;
  isActive: boolean;
  subscriptionType: "monthly" | "yearly" | null;
  subscriptionExpiry: Date | null;
  totalEarnings: number;
  teamSize: number;
  joinDate: Date;
  isAdmin: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (user: any) => void;
  register: (
    email: string,
    password: string,
    name: string,
    sponsorId?: string,
  ) => Promise<boolean>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_CREDENTIALS = {
  email: "psikologabdulkadirkan@gmail.com",
  password: "Abdulkadir1983",
};

// Mock user data for demo
const mockUsers: User[] = [
  {
    id: "1",
    email: "psikologabdulkadirkan@gmail.com",
    name: "Psikolog Abdulkadir Kan",
    referralCode: "ADM001",
    level: 7,
    isActive: true,
    subscriptionType: "yearly",
    subscriptionExpiry: new Date("2025-12-31"),
    totalEarnings: 0,
    teamSize: 0,
    joinDate: new Date("2024-01-01"),
    isAdmin: true,
  },
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user on app start
    const storedUser = localStorage.getItem("currentUser");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = (userData: any) => {
    setUser(userData);
    localStorage.setItem("currentUser", JSON.stringify(userData));
  };

  const register = async (
    email: string,
    password: string,
    name: string,
    sponsorId?: string,
  ): Promise<boolean> => {
    setIsLoading(true);

    // Generate new user
    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      sponsorId,
      referralCode: `REF${Date.now()}`,
      level: 1,
      isActive: false,
      subscriptionType: null,
      subscriptionExpiry: null,
      totalEarnings: 0,
      teamSize: 0,
      joinDate: new Date(),
      isAdmin: false,
    };

    mockUsers.push(newUser);
    setUser(newUser);
    localStorage.setItem("currentUser", JSON.stringify(newUser));

    setIsLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("currentUser");
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem("currentUser", JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider
      value={{ user, isLoading, login, register, logout, updateUser }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}
