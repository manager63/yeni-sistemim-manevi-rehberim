import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/contexts/AuthContext";
import {
  Clock,
  Star,
  Heart,
  BookOpen,
  Lock,
  Play,
  Volume2,
  VolumeX,
  Calendar,
  Sunrise,
  Moon,
  Sun,
  MessageSquare,
  Gift,
  Crown,
  CheckCircle,
  Plus,
  Save,
  Download,
  Share2,
  Timer,
  Bell,
  Bookmark,
  Eye,
  Search,
  Filter,
  Sparkles,
  Compass,
  Shield,
  Flame,
  Leaf,
} from "lucide-react";

const PrayerIntention = () => {
  const { user } = useAuth();
  const [selectedPrayerCategory, setSelectedPrayerCategory] = useState("daily");
  const [currentTime, setCurrentTime] = useState(new Date());
  const [personalPrayers, setPersonalPrayers] = useState([]);
  const [isRecordingDua, setIsRecordingDua] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Comprehensive daily prayers from Islamic sources
  const dailyPrayers = {
    morning: {
      name: "Sabah Duaları",
      time: "Fecir sonrası - Güneş doğana kadar",
      icon: Sunrise,
      color: "text-yellow-500",
      background: "bg-yellow-50",
      prayers: [
        {
          id: 1,
          name: "Sabah Duası",
          arabic:
            "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ",
          turkish:
            "Allah'ım! Seninle sabahladık, seninle akşamladık, seninle yaşıyoruz, seninle ölürüz ve sana döneceğiz.",
          transliteration:
            "Allahumme bike asbahnâ ve bike amsaynâ ve bike nahyâ ve bike nemûtu ve ileyke'n-nuşûr.",
          benefits: [
            "Günün bereketli geçmesi",
            "Kötülüklerden korunma",
            "Manevi güç artışı",
            "İç huzur",
          ],
          source: "Hadis-i Şerif",
          frequency: "Her sabah 1 defa",
          audio: "/audio/sabah-duasi.mp3",
        },
        {
          id: 2,
          name: "Ayetel Kürsî",
          arabic:
            "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ",
          turkish:
            "Allah, O'ndan başka ilah yoktur. Diri ve Kaim olandır. O'nu uyuklama ve uyku tutmaz...",
          transliteration:
            "Allahu lâ ilâhe illâ huve'l-hayyu'l-kayyûm. Lâ te'huzuhu sinetün ve lâ nevm...",
          benefits: [
            "Güçlü koruma",
            "Şeytan ve cin korunması",
            "Ölüm anına kadar himaye",
            "Cennet kapısının açılması",
          ],
          source: "Bakara Suresi 255. Ayet",
          frequency: "Her namaz sonrası",
          audio: "/audio/ayetel-kursi.mp3",
        },
        {
          id: 3,
          name: "Felak ve Nas Sureleri",
          arabic: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ",
          turkish: "De ki: Şafağın Rabbine sığınırım...",
          transliteration: "Kul eûzu bi rabbi'l-felek...",
          benefits: [
            "Büyü ve nazardan korunma",
            "Kötü niyetli insanlardan korunma",
            "Şeytani vesveselerden korunma",
            "Manevi temizlik",
          ],
          source: "Kur'an-ı Kerim",
          frequency: "3'er defa sabah-akşam",
          audio: "/audio/muavvizetayn.mp3",
        },
      ],
    },
    noon: {
      name: "Öğle Duaları",
      time: "Öğle namazı öncesi/sonrası",
      icon: Sun,
      color: "text-orange-500",
      background: "bg-orange-50",
      prayers: [
        {
          id: 4,
          name: "Rızık Duası",
          arabic:
            "اللَّهُمَّ اكْفِنِي بِحَلَالِكَ عَنْ حَرَامِكَ وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ",
          turkish:
            "Allah'ım! Helalinle haramından beni koru, fazlinla da benden başkasından müstağni kıl.",
          transliteration:
            "Allahumme'kfinî bi halâlike an harâmike ve agninî bi fazlike ammen sivâke.",
          benefits: [
            "Helal rızık artışı",
            "Haram kazançtan korunma",
            "Zenginlik ve bereket",
            "Allah'a muhtaçlık",
          ],
          source: "Tirmizi",
          frequency: "İhtiyaç halinde",
          audio: "/audio/rizik-duasi.mp3",
        },
        {
          id: 5,
          name: "İş ve Çalışma Duası",
          arabic: "اللَّهُمَّ بَارِكْ لَنَا فِيمَا رَزَقْتَنَا",
          turkish: "Allah'ım! Bize verdiğin rızıkta bereket ver.",
          transliteration: "Allahumme bârik lenâ fîmâ razaktanâ.",
          benefits: [
            "İşte başarı",
            "Çalışmada bereket",
            "Gelirde artış",
            "Zorluklardan korunma",
          ],
          source: "Hadis-i Şerif",
          frequency: "İşe başlarken",
          audio: "/audio/is-duasi.mp3",
        },
      ],
    },
    evening: {
      name: "Akşam Duaları",
      time: "Güneş battıktan sonra",
      icon: Moon,
      color: "text-blue-500",
      background: "bg-blue-50",
      prayers: [
        {
          id: 6,
          name: "Akşam Duası",
          arabic:
            "اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ",
          turkish:
            "Allah'ım! Seninle akşamladık, seninle sabahladık, seninle yaşıyoruz, seninle ölürüz ve sana döneceğiz.",
          transliteration:
            "Allahumme bike amsaynâ ve bike asbahnâ ve bike nahyâ ve bike nemûtu ve ileyke'l-masîr.",
          benefits: [
            "Gecenin huzurlu geçmesi",
            "Kötü rüyalardan korunma",
            "Günahların affı",
            "Rahmet nüzulu",
          ],
          source: "Hadis-i Şerif",
          frequency: "Her akşam",
          audio: "/audio/aksam-duasi.mp3",
        },
        {
          id: 7,
          name: "Tevbe ve İstiğfar",
          arabic:
            "رَبِّ اغْفِرْ لِي ذَنْبِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ",
          turkish:
            "Rabbim! Günahımı bağışla ve tövbemi kabul et. Şüphesiz sen çok tövbe kabul eden, çok merhametlisin.",
          transliteration:
            "Rabbi'ğfir lî zenbî ve tub aleyye inneke ente't-tevvâbu'r-rahîm.",
          benefits: [
            "Günah affı",
            "Tövbe kabulü",
            "Kalp temizliği",
            "Allah'ın rızası",
          ],
          source: "Hadis-i Şerif",
          frequency: "Günde 100 defa",
          audio: "/audio/tevbe-duasi.mp3",
        },
      ],
    },
  };

  // Special situation prayers
  const specialPrayers = [
    {
      category: "Sıkıntı ve Zorluk",
      icon: Shield,
      color: "text-red-500",
      prayers: [
        {
          name: "Sıkıntı Duası",
          arabic:
            "لَا إِلَٰهَ إِلَّا اللَّهُ الْعَظِيمُ الْحَلِيمُ لَا إِلَٰهَ إِلَّا اللَّهُ رَبُّ الْعَرْشِ الْعَظِيمِ",
          turkish:
            "Büyük ve halîm olan Allah'tan başka ilah yoktur. Arş-ı azîmin Rabbi olan Allah'tan başka ilah yoktur.",
          situation: "Sıkıntı, stres, endişe anlarında",
        },
        {
          name: "Hastalık Duası",
          arabic:
            "اللَّهُمَّ رَبَّ النَّاسِ أَذْهِبِ الْبَأْسَ اشْفِ أَنْتَ الشَّافِي",
          turkish:
            "Allah'ım! İnsanların Rabbi, hastalığı gider, şifa ver. Sen şifa verensin.",
          situation: "Hastalık zamanlarında",
        },
      ],
    },
    {
      category: "Bereket ve Rızık",
      icon: Gift,
      color: "text-green-500",
      prayers: [
        {
          name: "Bereket Duası",
          arabic: "اللَّهُمَّ بَارِكْ لَنَا فِيمَا أَعْطَيْتَنَا",
          turkish: "Allah'ım! Bize verdiğin şeylerde bereket ver.",
          situation: "Yeni bir işe başlarken",
        },
        {
          name: "Ticaret Duası",
          arabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ وَرَحْمَتِكَ",
          turkish: "Allah'ım! Senden fazlını ve rahmetini istiyorum.",
          situation: "Alışveriş ve ticaret yaparken",
        },
      ],
    },
    {
      category: "Koruma",
      icon: Star,
      color: "text-purple-500",
      prayers: [
        {
          name: "Genel Koruma",
          arabic:
            "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ",
          turkish:
            "Öyle bir Allah'ın adıyla ki, O'nun adı ile beraber yerde ve gökte hiçbir şey zarar veremez.",
          situation: "Evden çıkarken, yolculukta",
        },
      ],
    },
  ];

  // Intentions and supplications
  const intentions = [
    {
      category: "İbadet Niyetleri",
      items: [
        "Namaz kılmak için niyet ettim",
        "Oruç tutmak için niyet ettim",
        "Sadaka vermek için niyet ettim",
        "Kur'an okumak için niyet ettim",
        "Zikir yapmak için niyet ettim",
      ],
    },
    {
      category: "Günlük Yaşam Niyetleri",
      items: [
        "İlim öğrenmek için niyet ettim",
        "İyilik yapmak için niyet ettim",
        "Sabırlı olmak için niyet ettim",
        "Adaletli olmak için niyet ettim",
        "Merhametli olmak için niyet ettim",
      ],
    },
    {
      category: "Sosyal Niyetler",
      items: [
        "İnsanlara faydalı olmak için",
        "Aileme iyi davranmak için",
        "Topluma hizmet etmek için",
        "Mazluma yardım etmek için",
        "Barışı desteklemek için",
      ],
    },
  ];

  // Prayer schedule based on current time
  const getPrayerTimeCategory = () => {
    const hour = currentTime.getHours();
    if (hour >= 5 && hour < 12) return "morning";
    if (hour >= 12 && hour < 18) return "noon";
    return "evening";
  };

  const currentPrayerTime = getPrayerTimeCategory();
  const currentPrayers = dailyPrayers[currentPrayerTime];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Dua & Niyet Rehberi
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Kur'an ve Sünnet'ten günlük dualar, özel durumlar için yapılacak
            dualar ve manevi niyetler. Allah'a yakınlaşmanın en güzel yolu.
          </p>
          <div className="flex justify-center space-x-4 mt-6">
            <Badge className="bg-spiritual-turquoise-100 text-spiritual-turquoise-700">
              50+ Özgün Dua
            </Badge>
            <Badge className="bg-spiritual-purple-100 text-spiritual-purple-700">
              Sesli Okuma
            </Badge>
            <Badge className="bg-spiritual-gold-100 text-spiritual-gold-700">
              Kişisel Dua Defteri
            </Badge>
          </div>
        </div>

        {/* Current Prayer Time Alert */}
        <Alert className="mb-8 border-spiritual-turquoise-200 bg-spiritual-turquoise-50">
          <currentPrayers.icon className={`w-5 h-5 ${currentPrayers.color}`} />
          <AlertDescription className="text-spiritual-turquoise-800">
            <strong>Şu anki zaman dilimi:</strong> {currentPrayers.name} (
            {currentPrayers.time})
            <br />
            <span className="text-sm">
              Bu vakitte özellikle tavsiye edilen dualarımız bulunmaktadır.
            </span>
          </AlertDescription>
        </Alert>

        {/* Membership Alert */}
        {!user?.isActive && (
          <Alert className="mb-8 border-orange-200 bg-orange-50">
            <Lock className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <strong>Önemli:</strong> Tüm dualar, sesli okuma, kişisel dua
              defteri ve özel dua danışmanlığı hizmetleri için aylık $10
              abonelik gereklidir.{" "}
              <Button variant="link" className="text-orange-600 p-0 ml-2">
                Hemen üye ol
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="daily" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="daily">Günlük Dualar</TabsTrigger>
            <TabsTrigger value="special">Özel Durumlar</TabsTrigger>
            <TabsTrigger value="intentions">Niyetler</TabsTrigger>
            <TabsTrigger value="personal">Kişisel Defterim</TabsTrigger>
            <TabsTrigger value="guidance">Dua Rehberi</TabsTrigger>
          </TabsList>

          {/* Daily Prayers */}
          <TabsContent value="daily" className="space-y-8">
            {/* Time-based Prayer Categories */}
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {Object.entries(dailyPrayers).map(([key, timeCategory]) => (
                <Card
                  key={key}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                    currentPrayerTime === key
                      ? "ring-2 ring-spiritual-turquoise-400 bg-spiritual-turquoise-50"
                      : "bg-white/80 backdrop-blur-sm"
                  }`}
                  onClick={() => setSelectedPrayerCategory(key)}
                >
                  <CardHeader className="text-center">
                    <timeCategory.icon
                      className={`w-8 h-8 mx-auto mb-2 ${timeCategory.color}`}
                    />
                    <CardTitle className="text-lg">
                      {timeCategory.name}
                    </CardTitle>
                    <p className="text-sm text-gray-600">{timeCategory.time}</p>
                  </CardHeader>
                  <CardContent>
                    <Badge variant="outline" className="w-full justify-center">
                      {timeCategory.prayers.length} Dua
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Selected Time Category Prayers */}
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-center text-gray-900">
                {dailyPrayers[selectedPrayerCategory]?.name || "Dualar"}
              </h3>
              <div className="grid gap-8">
                {dailyPrayers[selectedPrayerCategory]?.prayers?.map(
                  (prayer) => (
                    <Card
                      key={prayer.id}
                      className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 ${
                        !user?.isActive ? "opacity-75" : ""
                      }`}
                    >
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-xl">
                            {prayer?.name || "İsimsiz Dua"}
                          </CardTitle>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">
                              {prayer?.source || "Kaynak"}
                            </Badge>
                            <Button
                              size="sm"
                              variant="outline"
                              disabled={!user?.isActive}
                            >
                              <Bookmark className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {/* Arabic Text */}
                        <div className="p-6 bg-spiritual-turquoise-50 rounded-lg">
                          <div className="text-2xl arabic-text mb-4 leading-relaxed text-center">
                            {prayer?.arabic || ""}
                          </div>
                          <div className="text-sm text-gray-600 italic text-center mb-2">
                            {prayer?.transliteration || ""}
                          </div>
                          <div className="text-base text-gray-800 leading-relaxed">
                            {prayer.turkish}
                          </div>
                        </div>

                        {/* Prayer Details */}
                        <div className="grid md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3">
                              Faydaları:
                            </h4>
                            <ul className="space-y-2">
                              {prayer.benefits.map((benefit, index) => (
                                <li
                                  key={index}
                                  className="flex items-center space-x-2 text-sm"
                                >
                                  <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                                  <span>{benefit}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3">
                              Okuma Rehberi:
                            </h4>
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center space-x-2">
                                <Timer className="w-4 h-4 text-spiritual-purple-600" />
                                <span>Sıklık: {prayer.frequency}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <BookOpen className="w-4 h-4 text-spiritual-gold-600" />
                                <span>Kaynak: {prayer.source}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex space-x-3">
                          <Button
                            className="flex-1 bg-spiritual-gradient text-white"
                            disabled={!user?.isActive}
                          >
                            <Volume2 className="w-4 h-4 mr-2" />
                            Sesli Dinle
                          </Button>
                          <Button
                            variant="outline"
                            disabled={!user?.isActive}
                            className="flex items-center space-x-1"
                          >
                            <Download className="w-4 h-4" />
                            <span className="hidden sm:inline">İndir</span>
                          </Button>
                          <Button
                            variant="outline"
                            disabled={!user?.isActive}
                            className="flex items-center space-x-1"
                          >
                            <Share2 className="w-4 h-4" />
                            <span className="hidden sm:inline">Paylaş</span>
                          </Button>
                        </div>

                        {!user?.isActive && (
                          <div className="text-center text-sm text-gray-500 bg-orange-50 p-3 rounded">
                            Sesli dua okuma ve indirme özelliği için üyelik
                            gereklidir
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ),
                )}
              </div>
            </div>
          </TabsContent>

          {/* Special Situation Prayers */}
          <TabsContent value="special" className="space-y-8">
            <div className="grid gap-8">
              {specialPrayers.map((category, categoryIndex) => (
                <Card
                  key={categoryIndex}
                  className="bg-white/80 backdrop-blur-sm"
                >
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <category.icon className={`w-6 h-6 ${category.color}`} />
                      <span>{category.category}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-6">
                      {category.prayers?.map((prayer, prayerIndex) => (
                        <div
                          key={prayerIndex}
                          className="border border-gray-200 rounded-lg p-6"
                        >
                          <h4 className="font-semibold text-lg mb-4">
                            {prayer?.name || "İsimsiz Dua"}
                          </h4>
                          <div className="p-4 bg-gray-50 rounded-lg mb-4">
                            <div className="text-xl arabic-text mb-3 leading-relaxed">
                              {prayer?.arabic || ""}
                            </div>
                            <div className="text-gray-800 leading-relaxed">
                              {prayer?.turkish || ""}
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="text-sm text-gray-600">
                              <strong>Kullanım:</strong>{" "}
                              {prayer?.situation || "Genel kullanım"}
                            </div>
                            <div className="flex space-x-2">
                              <Button
                                size="sm"
                                disabled={!user?.isActive}
                                className="bg-spiritual-gradient text-white"
                              >
                                <Play className="w-4 h-4 mr-1" />
                                Oku
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={!user?.isActive}
                              >
                                <Bookmark className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Intentions */}
          <TabsContent value="intentions" className="space-y-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                İslam'da Niyet
              </h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                "Ameller niyetlere göredir" hadisi ışığında, her amelimizin
                değeri niyetimizle belirlenir. İşte günlük yaşamda
                yapabileceğiniz niyetler.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {intentions.map((category, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {category.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {category.items.map((item, itemIndex) => (
                        <div
                          key={itemIndex}
                          className="flex items-center space-x-3 p-3 bg-spiritual-turquoise-50 rounded-lg"
                        >
                          <Heart className="w-4 h-4 text-spiritual-turquoise-600 flex-shrink-0" />
                          <span className="text-sm">{item}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="bg-spiritual-gradient text-white">
              <CardContent className="p-8 text-center">
                <Star className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4">Niyet Rehberi</h3>
                <p className="mb-6 text-white/90">
                  "İnsan ancak çalıştığının karşılığını alır." Her işinizi Allah
                  rızası için yapın ve niyetinizi temiz tutun.
                </p>
                <Button
                  className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100"
                  disabled={!user?.isActive}
                >
                  Kişisel Niyet Planı Oluştur
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Personal Prayer Book */}
          <TabsContent value="personal" className="space-y-8">
            {user?.isActive ? (
              <div className="space-y-8">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-900">
                    Kişisel Dua Defterim
                  </h2>
                  <Button
                    className="bg-spiritual-gradient text-white"
                    onClick={() => setIsRecordingDua(!isRecordingDua)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Yeni Dua Ekle
                  </Button>
                </div>

                {isRecordingDua && (
                  <Card className="bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle>Yeni Dua Ekle</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Dua Başlığı
                        </label>
                        <Input placeholder="Dua için bir başlık girin" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Dua Metni
                        </label>
                        <Textarea
                          placeholder="Dua metnini buraya yazın..."
                          rows={4}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Kategori
                        </label>
                        <Input placeholder="Örn: Aile, İş, Sağlık" />
                      </div>
                      <div className="flex space-x-3">
                        <Button className="bg-spiritual-gradient text-white">
                          <Save className="w-4 h-4 mr-2" />
                          Kaydet
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setIsRecordingDua(false)}
                        >
                          İptal
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="grid gap-6">
                  {personalPrayers.length === 0 ? (
                    <Card className="bg-white/80 backdrop-blur-sm">
                      <CardContent className="p-8 text-center">
                        <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">
                          Henüz kişisel dua eklemediniz
                        </h3>
                        <p className="text-gray-600 mb-4">
                          Özel dualarınızı, niyetlerinizi ve isteklerinizi
                          kaydedin
                        </p>
                        <Button
                          className="bg-spiritual-gradient text-white"
                          onClick={() => setIsRecordingDua(true)}
                        >
                          İlk Duanızı Ekleyin
                        </Button>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="space-y-4">
                      {personalPrayers?.map((prayer, index) => (
                        <Card
                          key={index}
                          className="bg-white/80 backdrop-blur-sm"
                        >
                          <CardContent className="p-4">
                            <h4 className="font-semibold mb-2">
                              {prayer?.title || "İsimsiz Dua"}
                            </h4>
                            <p className="text-gray-600 text-sm">
                              {prayer?.content || ""}
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardContent className="p-8 text-center">
                  <Lock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    Kişisel Dua Defteri
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Özel dualarınızı kaydetmek ve takip etmek için üyelik
                    gereklidir
                  </p>
                  <Button className="bg-spiritual-gradient text-white">
                    Üye Ol
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Prayer Guidance */}
          <TabsContent value="guidance" className="space-y-8">
            <Card className="bg-spiritual-gradient text-white">
              <CardContent className="p-8 text-center">
                <Crown className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  Profesyonel Dua Rehberliği
                </h3>
                <p className="mb-6 text-white/90">
                  İslami kaynaklara dayalı kişiselleştirilmiş dua rehberliği.
                  Özel durumlarınız için uygun dualar öğrenin.
                </p>
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <MessageSquare className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm">Uzman Danışmanlar</div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <Star className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm">Özel Dua Programı</div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <Clock className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm">7/24 Destek</div>
                  </div>
                </div>
                <Button
                  className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100"
                  disabled={!user?.isActive}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Dua Danışmanlığı Al
                </Button>
              </CardContent>
            </Card>

            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Dua Edebim</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    İslam'da dua etmenin adabı ve sünnetleri
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li>• Abdest alarak temiz olmak</li>
                    <li>• Kıbleye dönmek</li>
                    <li>• Hamd ve sena ile başlamak</li>
                    <li>• Salavat getirmek</li>
                    <li>• Âmin ile bitirmek</li>
                  </ul>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    disabled={!user?.isActive}
                  >
                    Detaylı Rehber
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Dua Zamanları</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Duanın müstecab olduğu özel zamanlar
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li>• Ezan ile kamet arası</li>
                    <li>• Son 1/3 gece vakti</li>
                    <li>• Cuma günü</li>
                    <li>• Yağmur yağarken</li>
                    <li>• Oruçlu iken</li>
                  </ul>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    disabled={!user?.isActive}
                  >
                    Zaman Rehberi
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Özel Durumlar</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Farklı durumlar için özel dua önerileri
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li>• Sınav öncesi dualar</li>
                    <li>• Hastalık duaları</li>
                    <li>• Yolculuk duaları</li>
                    <li>• Evlilik duaları</li>
                    <li>• İş ve rızık duaları</li>
                  </ul>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    disabled={!user?.isActive}
                  >
                    Özel Danışmanlık
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default PrayerIntention;
