import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/contexts/AuthContext";
import {
  Moon,
  Star,
  Heart,
  BookOpen,
  Lock,
  MessageSquare,
  Calendar,
  Clock,
  Phone,
  Video,
  Mail,
  Crown,
  Eye,
  Brain,
  Compass,
  Shield,
  Sparkles,
  Target,
  Award,
  Users,
  Gift,
  Search,
  Filter,
  CheckCircle,
  AlertCircle,
  Plus,
  Send,
  FileText,
  Download,
  Headphones,
  Play,
} from "lucide-react";

const SpiritualGuidance = () => {
  const { user } = useAuth();
  const [dreamText, setDreamText] = useState("");
  const [selectedService, setSelectedService] = useState(null);
  const [consultationRequest, setConsultationRequest] = useState({
    topic: "",
    description: "",
    preferredTime: "",
    contactMethod: "video",
  });

  // Dream interpretation categories based on Islamic sources
  const dreamCategories = [
    {
      category: "Rüya Çeşitleri",
      description: "İslam'da rüyalar üç çeşittir",
      types: [
        {
          name: "Ru'ya (Gerçek Rüya)",
          description: "Allah'tan gelen doğru rüyalar",
          signs: ["Net ve canlı görüntüler", "Kalp huzuru", "Manevi mesaj"],
          interpretation:
            "Bu rüyalar Allah'ın kuluna verdiği müjde veya uyarıdır",
        },
        {
          name: "Hulum (Karışık Rüya)",
          description: "Günlük yaşamın yansıması",
          signs: [
            "Karışık görüntüler",
            "Günlük olayların karışımı",
            "Belirsizlik",
          ],
          interpretation:
            "Bu rüyaların özel anlamı yoktur, günlük yaşamın yansımasıdır",
        },
        {
          name: "Şeytani Rüya",
          description: "Şeytanın vesvesesi",
          signs: ["Korku verici", "Huzursuzluk", "Kötü duygular"],
          interpretation: "Bu rüyalardan Allah'a sığınılır ve önemsenmez",
        },
      ],
    },
  ];

  // Professional counseling services
  const counselingServices = [
    {
      id: 1,
      title: "Rüya Tabiri Danışmanlığı",
      description: "İslami kaynaklara dayalı profesyonel rüya yorumu",
      duration: "45 dakika",
      price: 75,
      specialist: "Rüya Uzmanı",
      features: [
        "İbn Sirin kaynaklı yorumlar",
        "Kur'an ve Sünnet çerçevesinde analiz",
        "Kişisel durum değerlendirmesi",
        "Manevi rehberlik önerileri",
        "Yazılı rapor dahil",
      ],
      availability: "7/24 Online",
      rating: 4.9,
      consultations: 2847,
      icon: Moon,
      color: "text-blue-600",
    },
    {
      id: 2,
      title: "Manevi Yaşam Koçluğu",
      description: "İslami değerlerle desteklenen ruhsal gelişim rehberliği",
      duration: "60 dakika",
      price: 120,
      specialist: "Manevi Koç",
      features: [
        "Ruhsal gelişim planı",
        "İbadet hayatı düzenleme",
        "Manevi krizlerde destek",
        "Ahlaki gelişim rehberliği",
        "Sürekli takip desteği",
      ],
      availability: "Randevu ile",
      rating: 4.8,
      consultations: 1923,
      icon: Heart,
      color: "text-red-600",
    },
    {
      id: 3,
      title: "İslami Psikolojik Danışmanlık",
      description: "Modern psikoloji ve İslami değerlerin birleşimi",
      duration: "50 dakika",
      price: 150,
      specialist: "İslami Psikolog",
      features: [
        "Kur'an terapisi",
        "Dua ve zikir ile şifa",
        "Manevi kriz müdahalesi",
        "Aile danışmanlığı",
        "Travma ve yas desteği",
      ],
      availability: "Acil durumda 24/7",
      rating: 4.9,
      consultations: 3156,
      icon: Brain,
      color: "text-purple-600",
    },
    {
      id: 4,
      title: "Aile ve İlişki Rehberliği",
      description: "İslami aile yapısı ve sağlıklı ilişkiler",
      duration: "90 dakika",
      price: 200,
      specialist: "Aile Danışmanı",
      features: [
        "Evlilik öncesi rehberlik",
        "Çift terapisi",
        "Ebeveynlik koçluğu",
        "Aile içi iletişim",
        "Boşanma sonrası destek",
      ],
      availability: "Hafta içi gündüz",
      rating: 4.7,
      consultations: 987,
      icon: Users,
      color: "text-green-600",
    },
    {
      id: 5,
      title: "Gençlik ve Ergenlik Rehberliği",
      description: "Gençlerin manevi ve sosyal gelişimi",
      duration: "45 dakika",
      price: 90,
      specialist: "Gençlik Uzmanı",
      features: [
        "Kimlik arayışı desteği",
        "Akran baskısı ile başa çıkma",
        "Değerler eğitimi",
        "Gelecek planlama",
        "Dijital çağ rehberliği",
      ],
      availability: "Hafta sonu dahil",
      rating: 4.8,
      consultations: 1654,
      icon: Target,
      color: "text-orange-600",
    },
    {
      id: 6,
      title: "Maneviyet ve Kariyeri Dengeleme",
      description: "İş hayatında İslami değerleri koruma",
      duration: "60 dakika",
      price: 130,
      specialist: "Kariyer Koçu",
      features: [
        "Helal kazanç yolları",
        "İş etiği rehberliği",
        "Stres yönetimi",
        "Zaman yönetimi",
        "Liderlik gelişimi",
      ],
      availability: "Esnek saatler",
      rating: 4.6,
      consultations: 756,
      icon: Compass,
      color: "text-indigo-600",
    },
  ];

  // Common dream symbols and meanings
  const dreamSymbols = [
    {
      symbol: "Su",
      meanings: [
        "Temiz su: Bereket, hidayet, temizlik",
        "Bulanık su: Sıkıntı, karışıklık",
        "Akan su: Hayırlı değişiklik",
      ],
      source: "İbn Sirin",
    },
    {
      symbol: "Ağaç",
      meanings: [
        "Meyveli ağaç: Hayırlı çocuk, bereket",
        "Kuru ağaç: Zorluk, hastalık",
        "Büyük ağaç: Uzun ömür, güçlü aile",
      ],
      source: "İslami Kaynaklar",
    },
    {
      symbol: "Kitap",
      meanings: [
        "Kur'an: Hidayet, ilim, bereket",
        "Açık kitap: İlim öğrenme",
        "Kapalı kitap: Gizli bilgi",
      ],
      source: "Tabir Kitapları",
    },
    {
      symbol: "Nur (Işık)",
      meanings: [
        "Parlak ışık: Hidayet, iman artışı",
        "Gökten inen nur: Manevi yükselme",
        "Evde nur: Aile huzuru",
      ],
      source: "Kur'an Yorumları",
    },
  ];

  // Specialist profiles
  const specialists = [
    {
      id: 1,
      name: "Dr. Ayşe Nur Yılmaz",
      title: "İslami Psikoloji Uzmanı",
      experience: "15 yıl",
      specialties: ["Rüya Tabiri", "Manevi Terapi", "Aile Danışmanlığı"],
      education: "Al-Azhar Üniversitesi, İstanbul Üniversitesi",
      languages: ["Türkçe", "Arapça", "İngilizce"],
      rating: 4.9,
      consultations: 3200,
      availability: "Pazartesi-Cuma 09:00-18:00",
      photo: "/images/specialists/ayse-nur.jpg",
    },
    {
      id: 2,
      name: "Hocaefendi Mehmet Ali Özkan",
      title: "Manevi Rehber",
      experience: "25 yıl",
      specialties: ["Tasavvuf", "Zikir Terapisi", "Manevi Koçluk"],
      education: "Darulfünun İlahiyat, Mekke Harem-i Şerif",
      languages: ["Türkçe", "Arapça", "Farsça"],
      rating: 5.0,
      consultations: 1850,
      availability: "Her gün 08:00-22:00",
      photo: "/images/specialists/mehmet-ali.jpg",
    },
    {
      id: 3,
      name: "Prof. Dr. Fatma Zehra Aydın",
      title: "Gençlik ve Aile Uzmanı",
      experience: "20 yıl",
      specialties: [
        "Gençlik Rehberliği",
        "Eğitim Psikolojisi",
        "Aile Terapisi",
      ],
      education: "Harvard Üniversitesi, İstanbul Medeniyet Üniversitesi",
      languages: ["Türkçe", "İngilizce", "Almanca"],
      rating: 4.8,
      consultations: 2750,
      availability: "Hafta içi 10:00-20:00",
      photo: "/images/specialists/fatma-zehra.jpg",
    },
  ];

  const handleDreamSubmit = () => {
    if (!user?.isActive) {
      alert("Rüya tabiri hizmeti için üyelik gereklidir.");
      return;
    }
    console.log("Dream interpretation request:", dreamText);
    alert(
      "Rüya tabiriniz uzmanlarımıza iletildi. 24 saat içinde yanıt alacaksınız.",
    );
  };

  const handleConsultationRequest = () => {
    if (!user?.isActive) {
      alert("Danışmanlık hizmeti için üyelik gereklidir.");
      return;
    }
    console.log("Consultation request:", consultationRequest);
    alert(
      "Danışmanlık talebiniz iletildi. En kısa sürede size dönüş yapacağız.",
    );
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Manevi Rehberlik & Danışmanlık
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            İslami kaynaklara dayalı profesyonel rüya tabiri, manevi danışmanlık
            ve ruhsal gelişim hizmetleri. Uzman rehberlerimizle maneviyatınızı
            güçlendirin.
          </p>
          <div className="flex justify-center space-x-4 mt-6">
            <Badge className="bg-spiritual-turquoise-100 text-spiritual-turquoise-700">
              6 Uzmanlık Alanı
            </Badge>
            <Badge className="bg-spiritual-purple-100 text-spiritual-purple-700">
              7/24 Destek
            </Badge>
            <Badge className="bg-spiritual-gold-100 text-spiritual-gold-700">
              15,000+ Başarılı Danışmanlık
            </Badge>
          </div>
        </div>

        {/* Membership Alert */}
        {!user?.isActive && (
          <Alert className="mb-8 border-orange-200 bg-orange-50">
            <Lock className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <strong>Önemli:</strong> Tüm manevi rehberlik hizmetleri, rüya
              tabiri ve uzman danışmanlık için aylık $10 abonelik gereklidir.
              Uzmanlarımızla görüşme ve kişisel rehberlik sadece üyeler için
              mevcuttur.{" "}
              <Button variant="link" className="text-orange-600 p-0 ml-2">
                Hemen üye ol
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="services" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="services">Hizmetlerimiz</TabsTrigger>
            <TabsTrigger value="dream">Rüya Tabiri</TabsTrigger>
            <TabsTrigger value="specialists">Uzmanlarımız</TabsTrigger>
            <TabsTrigger value="consultation">Danışmanlık Al</TabsTrigger>
            <TabsTrigger value="resources">Kaynak Merkezi</TabsTrigger>
          </TabsList>

          {/* Services */}
          <TabsContent value="services" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {counselingServices.map((service) => (
                <Card
                  key={service.id}
                  className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 ${
                    !user?.isActive ? "opacity-75" : ""
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <service.icon className={`w-6 h-6 ${service.color}`} />
                        <div>
                          <CardTitle className="text-lg">
                            {service.title}
                          </CardTitle>
                          <p className="text-sm text-gray-600">
                            {service.specialist}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-spiritual-turquoise-600">
                          ${service.price}
                        </div>
                        <div className="text-xs text-gray-500">
                          {service.duration}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700 text-sm">
                      {service.description}
                    </p>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="flex items-center space-x-1 mb-1">
                          <Star className="w-3 h-3 text-yellow-500" />
                          <span className="font-medium">{service.rating}</span>
                        </div>
                        <div className="text-gray-600 text-xs">
                          {service.consultations} danışmanlık
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center space-x-1 mb-1">
                          <Clock className="w-3 h-3 text-gray-500" />
                          <span className="font-medium text-xs">Müsaitlik</span>
                        </div>
                        <div className="text-gray-600 text-xs">
                          {service.availability}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                        Hizmet İçeriği:
                      </h4>
                      <ul className="space-y-1">
                        {service.features.slice(0, 3).map((feature, index) => (
                          <li
                            key={index}
                            className="flex items-center space-x-2 text-xs"
                          >
                            <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                        {service.features.length > 3 && (
                          <li className="text-xs text-gray-500">
                            +{service.features.length - 3} özellik daha...
                          </li>
                        )}
                      </ul>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        className="flex-1 bg-spiritual-gradient text-white"
                        disabled={!user?.isActive}
                        onClick={() => setSelectedService(service)}
                      >
                        <Calendar className="w-4 h-4 mr-2" />
                        Randevu Al
                      </Button>
                      <Button variant="outline" disabled={!user?.isActive}>
                        <MessageSquare className="w-4 h-4" />
                      </Button>
                    </div>

                    {!user?.isActive && (
                      <div className="text-center text-xs text-gray-500 bg-orange-50 p-2 rounded">
                        Bu hizmet için üyelik gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Dream Interpretation */}
          <TabsContent value="dream" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Dream Input */}
              <div className="lg:col-span-2">
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Moon className="w-6 h-6 text-blue-600" />
                      <span>Rüya Tabiri Talep Et</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Alert className="border-blue-200 bg-blue-50">
                      <Eye className="w-4 h-4 text-blue-600" />
                      <AlertDescription className="text-blue-800">
                        Rüyanızı mümkün olduğunca detaylı anlatın. Gördüğünüz
                        renkler, duygular ve semboller önemlidir.
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Rüyanızı Anlatın:
                        </label>
                        <Textarea
                          value={dreamText}
                          onChange={(e) => setDreamText(e.target.value)}
                          placeholder="Rüyanızı detaylı bir şekilde anlatın. Gördüğünüz yerler, kişiler, nesneler, renkler ve hissettiğiniz duyguları dahil edin..."
                          rows={6}
                          className="resize-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Rüya Tarihi:
                          </label>
                          <Input type="date" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Rüya Saati:
                          </label>
                          <Input type="time" />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Özel Durumunuz (Opsiyonel):
                        </label>
                        <Input placeholder="Hamilelik, hastalık, önemli karar vb." />
                      </div>
                    </div>

                    <Button
                      onClick={handleDreamSubmit}
                      disabled={!user?.isActive || !dreamText.trim()}
                      className="w-full bg-spiritual-gradient text-white"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Rüya Tabirini Gönder
                    </Button>

                    {!user?.isActive && (
                      <div className="text-center text-sm text-gray-500 bg-orange-50 p-3 rounded">
                        Rüya tabiri hizmeti için üyelik gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Dream Guide */}
              <div>
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-lg">Rüya Rehberi</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <h4 className="font-semibold text-gray-900 text-sm">
                        Rüya Türleri:
                      </h4>
                      {dreamCategories[0].types.map((type, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="font-medium text-sm mb-1">
                            {type.name}
                          </div>
                          <div className="text-xs text-gray-600">
                            {type.description}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="pt-4 border-t border-gray-200">
                      <h4 className="font-semibold text-gray-900 text-sm mb-3">
                        Yaygın Semboller:
                      </h4>
                      <div className="space-y-2">
                        {dreamSymbols.slice(0, 3).map((symbol, index) => (
                          <div key={index} className="text-xs">
                            <span className="font-medium">
                              {symbol.symbol}:
                            </span>
                            <div className="text-gray-600 ml-2">
                              {symbol.meanings[0]}
                            </div>
                          </div>
                        ))}
                        <Button variant="link" className="text-xs p-0 h-auto">
                          Tüm sembolleri gör →
                        </Button>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      className="w-full"
                      disabled={!user?.isActive}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Rüya Rehberi İndir
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Specialists */}
          <TabsContent value="specialists" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {specialists.map((specialist) => (
                <Card
                  key={specialist.id}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader className="text-center">
                    <div className="w-24 h-24 bg-spiritual-gradient rounded-full mx-auto mb-4 flex items-center justify-center">
                      <span className="text-white text-2xl font-bold">
                        {specialist.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </span>
                    </div>
                    <CardTitle className="text-lg">{specialist.name}</CardTitle>
                    <p className="text-sm text-gray-600">{specialist.title}</p>
                    <div className="flex items-center justify-center space-x-2">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="font-medium">{specialist.rating}</span>
                      <span className="text-sm text-gray-500">
                        ({specialist.consultations} danışmanlık)
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                        Uzmanlık Alanları:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {specialist.specialties.map((specialty, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="text-sm space-y-1">
                      <div className="flex items-center space-x-2">
                        <Award className="w-4 h-4 text-gray-500" />
                        <span>{specialist.experience} deneyim</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span className="text-xs">
                          {specialist.availability}
                        </span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1 text-sm">
                        Diller:
                      </h4>
                      <div className="text-xs text-gray-600">
                        {specialist.languages.join(", ")}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        className="flex-1 bg-spiritual-gradient text-white"
                        disabled={!user?.isActive}
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Görüşme
                      </Button>
                      <Button variant="outline" disabled={!user?.isActive}>
                        <MessageSquare className="w-4 h-4" />
                      </Button>
                    </div>

                    {!user?.isActive && (
                      <div className="text-center text-xs text-gray-500 bg-orange-50 p-2 rounded">
                        Uzmanlarla görüşmek için üyelik gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Consultation Request */}
          <TabsContent value="consultation" className="space-y-8">
            <div className="max-w-2xl mx-auto">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-center">
                    Manevi Danışmanlık Talep Et
                  </CardTitle>
                  <p className="text-center text-gray-600">
                    Uzman rehberlerimizden kişiselleştirilmiş manevi destek alın
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Danışmanlık Konusu:
                    </label>
                    <select
                      value={consultationRequest.topic}
                      onChange={(e) =>
                        setConsultationRequest({
                          ...consultationRequest,
                          topic: e.target.value,
                        })
                      }
                      className="w-full p-2 border border-gray-300 rounded-md"
                    >
                      <option value="">Konu seçin</option>
                      <option value="dream">Rüya Tabiri</option>
                      <option value="spiritual">Manevi Gelişim</option>
                      <option value="family">Aile ve İlişkiler</option>
                      <option value="psychology">Psikolojik Destek</option>
                      <option value="youth">Gençlik Rehberliği</option>
                      <option value="career">Kariyer ve Maneviyet</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Durumunuzu Açıklayın:
                    </label>
                    <Textarea
                      value={consultationRequest.description}
                      onChange={(e) =>
                        setConsultationRequest({
                          ...consultationRequest,
                          description: e.target.value,
                        })
                      }
                      placeholder="Danışmanlık almak istediğiniz konu hakkında detay verin..."
                      rows={4}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Tercih Edilen Görüşme:
                      </label>
                      <select
                        value={consultationRequest.contactMethod}
                        onChange={(e) =>
                          setConsultationRequest({
                            ...consultationRequest,
                            contactMethod: e.target.value,
                          })
                        }
                        className="w-full p-2 border border-gray-300 rounded-md"
                      >
                        <option value="video">Video Görüşme</option>
                        <option value="phone">Telefon</option>
                        <option value="message">Mesaj</option>
                        <option value="person">Yüz Yüze</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Tercih Edilen Zaman:
                      </label>
                      <Input
                        type="datetime-local"
                        value={consultationRequest.preferredTime}
                        onChange={(e) =>
                          setConsultationRequest({
                            ...consultationRequest,
                            preferredTime: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>

                  <Button
                    onClick={handleConsultationRequest}
                    disabled={
                      !user?.isActive ||
                      !consultationRequest.topic ||
                      !consultationRequest.description
                    }
                    className="w-full bg-spiritual-gradient text-white"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Danışmanlık Talep Et
                  </Button>

                  {!user?.isActive && (
                    <div className="text-center text-sm text-gray-500 bg-orange-50 p-3 rounded">
                      Danışmanlık hizmeti için üyelik gereklidir
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Resources */}
          <TabsContent value="resources" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Manevi Gelişim Kaynakları</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-spiritual-turquoise-50 rounded-lg">
                      <BookOpen className="w-5 h-5 text-spiritual-turquoise-600" />
                      <div>
                        <div className="font-medium text-sm">
                          Rüya Tabiri Rehberi
                        </div>
                        <div className="text-xs text-gray-600">
                          İbn Sirin kaynaklı
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={!user?.isActive}
                      >
                        <Download className="w-3 h-3" />
                      </Button>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-spiritual-purple-50 rounded-lg">
                      <Headphones className="w-5 h-5 text-spiritual-purple-600" />
                      <div>
                        <div className="font-medium text-sm">
                          Manevi Sohbetler
                        </div>
                        <div className="text-xs text-gray-600">
                          Sesli anlatım
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={!user?.isActive}
                      >
                        <Play className="w-3 h-3" />
                      </Button>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-spiritual-gold-50 rounded-lg">
                      <FileText className="w-5 h-5 text-spiritual-gold-600" />
                      <div>
                        <div className="font-medium text-sm">Aile Rehberi</div>
                        <div className="text-xs text-gray-600">
                          İslami aile yapısı
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={!user?.isActive}
                      >
                        <Download className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-spiritual-gradient text-white">
                <CardContent className="p-8 text-center">
                  <Crown className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-4">Premium Üyelik</h3>
                  <p className="mb-6 text-white/90">
                    Tüm rehberlik hizmetlerine tam erişim için üye olun
                  </p>
                  <div className="space-y-2 mb-6">
                    <div className="flex items-center justify-center space-x-2">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm">Uzman danışmanlık</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm">Sınırsız rüya tabiri</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-sm">Kişisel manevi plan</span>
                    </div>
                  </div>
                  <Button className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100">
                    Sadece $10/ay - Üye Ol
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SpiritualGuidance;
