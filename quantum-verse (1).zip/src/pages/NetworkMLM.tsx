import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/contexts/AuthContext";
import {
  Users,
  Star,
  Crown,
  TrendingUp,
  DollarSign,
  Target,
  Award,
  Shield,
  Heart,
  Zap,
  Gift,
  CheckCircle,
  AlertCircle,
  BookOpen,
  Compass,
  Flame,
  Sparkles,
  Eye,
  Lock,
  Calculator,
  BarChart,
  PieChart,
  Share2,
  Download,
  Upload,
  Mail,
  Phone,
  MessageSquare,
  Calendar,
  Clock,
  MapPin,
} from "lucide-react";

const NetworkMLM = () => {
  const { user } = useAuth();

  // 7 Nefs Levels with detailed information
  const nefsLevels = [
    {
      id: 1,
      name: "Nefs-i Emmare",
      turkish: "Kötülüğü Emreden Nefs",
      description:
        "Başlangıç seviyesi. Nefisle mücadele eden, kötü dürtüleri kontrol etmeye çalışan ruh hali.",
      color: "red",
      commission: "5%",
      requirements: "Kayıt ol, ilk ay tamamla",
      teamSize: 0,
      monthlyTarget: 100,
      spiritualFocus: "Tövbe ve pişmanlık",
      characteristics: [
        "Nefisle mücadele",
        "İlk farkındalık",
        "Değişim isteği",
        "Sabır öğrenme",
      ],
    },
    {
      id: 2,
      name: "Nefs-i Levvame",
      turkish: "Kendini Kınayan Nefs",
      description:
        "Hatalarını fark eden ve kendini eleştiren ruh seviyesi. Manevi uyanış başlar.",
      color: "orange",
      commission: "8%",
      requirements: "3 aktif üye, 2 ay süreklilik",
      teamSize: 3,
      monthlyTarget: 250,
      spiritualFocus: "Muhasebe ve öz-eleştiri",
      characteristics: [
        "Öz farkındalık",
        "Hata kabul etme",
        "Gelişim isteği",
        "İçsel muhasebe",
      ],
    },
    {
      id: 3,
      name: "Nefs-i Mülhime",
      turkish: "İlham Alan Nefs",
      description:
        "İlahi rehberlikle hareket eden, doğru yolu bulan ruh seviyesi.",
      color: "yellow",
      commission: "12%",
      requirements: "7 aktif üye, ekip lideri",
      teamSize: 7,
      monthlyTarget: 500,
      spiritualFocus: "İlham ve rehberlik",
      characteristics: [
        "İlahi rehberlik",
        "Doğru karar verme",
        "Liderlik başlangıcı",
        "Manevi büyüme",
      ],
    },
    {
      id: 4,
      name: "Nefs-i Mutmaine",
      turkish: "Huzur Bulan Nefs",
      description:
        "İç huzura kavuşan, dengeli ve sakin ruh hali. Gerçek güven duygusu.",
      color: "green",
      commission: "15%",
      requirements: "15 aktif üye, sürekli kazanç",
      teamSize: 15,
      monthlyTarget: 1000,
      spiritualFocus: "İç huzur ve güven",
      characteristics: [
        "İç huzur",
        "Ruhsal denge",
        "Güven duygusu",
        "Sabır ve tevekkül",
      ],
    },
    {
      id: 5,
      name: "Nefs-i Raziye",
      turkish: "Allah'tan Razı Olan Nefs",
      description: "Kadere rıza gösteren, Allah'tan memnun olan ruh seviyesi.",
      color: "blue",
      commission: "18%",
      requirements: "30 aktif üye, mentor sertifikası",
      teamSize: 30,
      monthlyTarget: 2000,
      spiritualFocus: "Rıza ve memnuniyet",
      characteristics: [
        "Kadere rıza",
        "Tam teslimiyet",
        "Mentor kabiliyeti",
        "Ruhsal olgunluk",
      ],
    },
    {
      id: 6,
      name: "Nefs-i Marziyye",
      turkish: "Allah'ın Razı Olduğu Nefs",
      description:
        "Allah'ın hoşnutluğunu kazanan, yüksek manevi seviyedeki ruh.",
      color: "purple",
      commission: "22%",
      requirements: "60 aktif üye, lider sertifikası",
      teamSize: 60,
      monthlyTarget: 4000,
      spiritualFocus: "İlahi hoşnutluk",
      characteristics: [
        "İlahi hoşnutluk",
        "Yüksek maneviyat",
        "Liderlik ustalığı",
        "Rehberlik verme",
      ],
    },
    {
      id: 7,
      name: "Nefs-i Kâmile",
      turkish: "Mükemmel Nefs",
      description:
        "En yüksek manevi seviye. Tam kemale ermiş, örnek insan seviyesi.",
      color: "gold",
      commission: "25%",
      requirements: "100+ aktif üye, master lider",
      teamSize: 100,
      monthlyTarget: 8000,
      spiritualFocus: "Kemal ve mükemmellik",
      characteristics: [
        "Ruhsal mükemmellik",
        "Tam kemal",
        "Master liderlik",
        "İnsan-ı kâmil",
      ],
    },
  ];

  const compensationPlans = [
    {
      name: "Sponsor Bonusu",
      description: "Direkt sponsor olduğunuz her kişiden kazanç",
      percentage: "15%",
      example: "Direkt: $10 → Kazancınız: $1.50",
      icon: Users,
      color: "spiritual-turquoise",
    },
    {
      name: "Eşleşme Bonusu",
      description: "Binary sistemde sol-sağ kolların eşleşmesinden bonus",
      percentage: "5-10%",
      example: "Sol: $100, Sağ: $80 → Bonus: $8",
      icon: Award,
      color: "spiritual-purple",
    },
    {
      name: "Seviye Bonusu",
      description: "Ekibinizdeki her seviyeden komisyon kazanın",
      percentage: "2-5%",
      example: "7 seviye derinliğinde kazanç",
      icon: BarChart,
      color: "spiritual-gold",
    },
    {
      name: "Liderlik Bonusu",
      description: "Lider seviyelerine ulaştığınızda özel bonuslar",
      percentage: "Değişken",
      example: "Aylık $500-$5000 arası",
      icon: Crown,
      color: "spiritual-turquoise",
    },
    {
      name: "Performans Bonusu",
      description: "Hedefleri aşan performans için ekstra ödüller",
      percentage: "10-20%",
      example: "Hedefi %150 geçme → %20 bonus",
      icon: Target,
      color: "spiritual-purple",
    },
    {
      name: "Yıllık Kar Payı",
      description: "Şirket kârından pay alma hakkı",
      percentage: "1-5%",
      example: "Top liderler için yıllık kar payı",
      icon: PieChart,
      color: "spiritual-gold",
    },
  ];

  const systemFeatures = [
    {
      title: "Binary Ağaç Sistemi",
      description:
        "Sol ve sağ kolda takım oluşturma sistemi. Dengeli büyüme teşvik edilir.",
      icon: Compass,
      benefits: [
        "Kolay takım yerleştirme",
        "Dengeli büyüme",
        "Spillover avantajı",
        "Maksimum kazanç",
      ],
    },
    {
      title: "Gerçek Zamanlı Takip",
      description:
        "Kazançlarınızı, takımınızı ve performansınızı anlık olarak görün.",
      icon: BarChart,
      benefits: [
        "Anlık raporlama",
        "Detaylı analizler",
        "Performans grafikleri",
        "Gelişim takibi",
      ],
    },
    {
      title: "Eğitim ve Destek",
      description: "Sürekli eğitimler, mentorluk ve destek sistemleri.",
      icon: BookOpen,
      benefits: [
        "Haftalık eğitimler",
        "Kişisel mentor",
        "Online akademi",
        "Başarı planları",
      ],
    },
    {
      title: "Pazarlama Araçları",
      description: "Profesyonel pazarlama materyalleri ve kişisel web sitesi.",
      icon: Share2,
      benefits: [
        "Kişisel web sitesi",
        "Pazarlama materyalleri",
        "Sosyal medya içeriği",
        "Otomatik sistem",
      ],
    },
  ];

  const [selectedLevel, setSelectedLevel] = useState(1);
  const currentLevel = nefsLevels.find((level) => level.id === selectedLevel);

  const successStories = [
    {
      name: "Ahmet Yılmaz",
      level: "Nefs-i Marziyye",
      monthlyIncome: "$8,500",
      teamSize: 147,
      story:
        "2 yıl önce işsizken başladım. Şimdi finansal özgürlüğüme kavuştum ve 100+ kişilik takımıma rehberlik ediyorum.",
      image: "/api/placeholder/150/150",
    },
    {
      name: "Fatma Demir",
      level: "Nefs-i Raziye",
      monthlyIncome: "$4,200",
      teamSize: 89,
      story:
        "Evhanımıydım ve ek gelir arıyordum. Hem manevi gelişim hem de ekonomik bağımsızlık kazandım.",
      image: "/api/placeholder/150/150",
    },
    {
      name: "Mehmet Kaya",
      level: "Nefs-i Mutmaine",
      monthlyIncome: "$2,100",
      teamSize: 34,
      story:
        "Emekli olduktan sonra katıldım. Hem sosyal çevrem genişledi hem de düzenli gelir elde ettim.",
      image: "/api/placeholder/150/150",
    },
  ];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Network MLM Sistemi
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            7 Seviyeli Nefs Mertebeleri ile Manevi Gelişim ve Finansal Başarı
          </p>
          <div className="flex justify-center mt-6">
            <Badge className="bg-spiritual-gradient text-white px-6 py-2 text-lg">
              10 Milyon Üye Kapasitesi
            </Badge>
          </div>
        </div>

        {/* Quick Start CTA */}
        {!user?.subscriptionActive && (
          <div className="bg-spiritual-gradient rounded-2xl p-8 text-white text-center mb-12">
            <Crown className="w-16 h-16 mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4">Hemen Başla!</h2>
            <p className="text-xl mb-6 opacity-90">
              Sadece $10/ay ile manevi gelişim yolculuğunuza başlayın ve MLM
              sisteminden kazanç elde edin
            </p>
            <div className="flex flex-col md:flex-row justify-center space-y-4 md:space-y-0 md:space-x-4">
              <Button className="bg-white text-spiritual-turquoise-600 hover:bg-gray-100 text-lg px-8 py-3">
                Aylık Plan - $10
              </Button>
              <Button className="bg-spiritual-gold-500 text-white hover:bg-spiritual-gold-600 text-lg px-8 py-3">
                Yıllık Plan - $100 (17% İndirim)
              </Button>
            </div>
          </div>
        )}

        {/* Main Tabs */}
        <Tabs defaultValue="levels" className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-white/80">
            <TabsTrigger value="levels" className="flex items-center space-x-2">
              <Star className="w-4 h-4" />
              <span>Nefs Seviyeleri</span>
            </TabsTrigger>
            <TabsTrigger
              value="compensation"
              className="flex items-center space-x-2"
            >
              <DollarSign className="w-4 h-4" />
              <span>Kazanç Planı</span>
            </TabsTrigger>
            <TabsTrigger value="system" className="flex items-center space-x-2">
              <Compass className="w-4 h-4" />
              <span>Sistem</span>
            </TabsTrigger>
            <TabsTrigger
              value="stories"
              className="flex items-center space-x-2"
            >
              <Users className="w-4 h-4" />
              <span>Başarı Hikayeleri</span>
            </TabsTrigger>
            <TabsTrigger
              value="calculator"
              className="flex items-center space-x-2"
            >
              <Calculator className="w-4 h-4" />
              <span>Kazanç Hesaplama</span>
            </TabsTrigger>
          </TabsList>

          {/* Nefs Levels */}
          <TabsContent value="levels">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-spiritual-turquoise-700 mb-4">
                  7 Seviyeli Nefs Mertebeleri
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  İslami gelenekte yer alan nefs mertebeleri ile hem manevi
                  gelişiminizi destekleyip hem de finansal başarı elde edin
                </p>
              </div>

              <div className="grid gap-6">
                {nefsLevels.map((level, index) => (
                  <Card
                    key={level.id}
                    className={`transition-all duration-300 hover:shadow-lg border-2 cursor-pointer ${
                      selectedLevel === level.id
                        ? "border-spiritual-turquoise-300 shadow-lg"
                        : "border-gray-200"
                    }`}
                    onClick={() => setSelectedLevel(level.id)}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div
                            className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl`}
                            style={{
                              background: `linear-gradient(135deg, var(--${level.color}-400), var(--${level.color}-600))`,
                            }}
                          >
                            {level.id}
                          </div>
                          <div>
                            <CardTitle className="text-xl">
                              {level.name}
                            </CardTitle>
                            <p className="text-gray-600">{level.turkish}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-spiritual-gold-600">
                            {level.commission}
                          </div>
                          <div className="text-sm text-gray-500">Komisyon</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <p className="text-gray-700 mb-4">
                            {level.description}
                          </p>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-600">
                                Takım Hedefi:
                              </span>
                              <Badge variant="outline">
                                {level.teamSize} kişi
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-600">
                                Aylık Hedef:
                              </span>
                              <Badge variant="outline">
                                ${level.monthlyTarget}
                              </Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-gray-600">
                                Manevi Odak:
                              </span>
                              <Badge className="bg-spiritual-purple-100 text-spiritual-purple-700">
                                {level.spiritualFocus}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-3">
                            Seviye Özellikleri:
                          </h4>
                          <div className="grid grid-cols-2 gap-2">
                            {level.characteristics.map((char, idx) => (
                              <div
                                key={idx}
                                className="flex items-center space-x-2"
                              >
                                <CheckCircle className="w-4 h-4 text-green-500" />
                                <span className="text-sm">{char}</span>
                              </div>
                            ))}
                          </div>
                          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                            <p className="text-sm font-medium text-gray-700">
                              Gereksinimler:
                            </p>
                            <p className="text-sm text-gray-600">
                              {level.requirements}
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Compensation Plan */}
          <TabsContent value="compensation">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-spiritual-turquoise-700 mb-4">
                  Kapsamlı Kazanç Planı
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Çoklu kazanç akışları ile sürdürülebilir gelir elde edin
                </p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {compensationPlans.map((plan, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-lg transition-all duration-300"
                  >
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-12 h-12 rounded-full flex items-center justify-center bg-${plan.color}-100`}
                        >
                          <plan.icon
                            className={`w-6 h-6 text-${plan.color}-600`}
                          />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{plan.name}</CardTitle>
                          <div className="text-2xl font-bold text-spiritual-gold-600">
                            {plan.percentage}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">{plan.description}</p>
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm font-medium text-gray-700 mb-1">
                          Örnek:
                        </p>
                        <p className="text-sm text-gray-600">{plan.example}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="bg-spiritual-gradient text-white">
                <CardHeader>
                  <CardTitle className="text-2xl text-center">
                    Toplam Kazanç Potansiyeli
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-4 gap-6 text-center">
                    <div>
                      <div className="text-3xl font-bold mb-2">$500</div>
                      <div className="text-sm opacity-90">Başlangıç Seviye</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold mb-2">$2,500</div>
                      <div className="text-sm opacity-90">Orta Seviye</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold mb-2">$8,000</div>
                      <div className="text-sm opacity-90">İleri Seviye</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold mb-2">$25,000+</div>
                      <div className="text-sm opacity-90">Master Seviye</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* System Features */}
          <TabsContent value="system">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-spiritual-turquoise-700 mb-4">
                  Gelişmiş MLM Sistemi
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  10 milyon üye kapasitesi ile teknoloji destekli güçlü sistem
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                {systemFeatures.map((feature, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-lg transition-all duration-300"
                  >
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 rounded-full bg-spiritual-turquoise-100 flex items-center justify-center">
                          <feature.icon className="w-6 h-6 text-spiritual-turquoise-600" />
                        </div>
                        <CardTitle className="text-xl">
                          {feature.title}
                        </CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">
                        {feature.description}
                      </p>
                      <div className="space-y-2">
                        {feature.benefits.map((benefit, idx) => (
                          <div
                            key={idx}
                            className="flex items-center space-x-2"
                          >
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            <span className="text-sm">{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="grid md:grid-cols-3 gap-6 mt-8">
                <Card className="text-center">
                  <CardContent className="p-6">
                    <Shield className="w-12 h-12 mx-auto mb-4 text-spiritual-turquoise-600" />
                    <h3 className="text-xl font-bold mb-2">Güvenli Sistem</h3>
                    <p className="text-gray-600">
                      SSL şifreleme ve güvenli ödeme sistemi
                    </p>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="p-6">
                    <Zap className="w-12 h-12 mx-auto mb-4 text-spiritual-gold-600" />
                    <h3 className="text-xl font-bold mb-2">Hızlı İşlem</h3>
                    <p className="text-gray-600">
                      Anlık komisyon hesaplama ve ödeme
                    </p>
                  </CardContent>
                </Card>
                <Card className="text-center">
                  <CardContent className="p-6">
                    <Heart className="w-12 h-12 mx-auto mb-4 text-spiritual-purple-600" />
                    <h3 className="text-xl font-bold mb-2">24/7 Destek</h3>
                    <p className="text-gray-600">
                      Her zaman ulaşılabilir teknik destek
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Success Stories */}
          <TabsContent value="stories">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-spiritual-turquoise-700 mb-4">
                  Başarı Hikayeleri
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Platformumuzda başarıya ulaşan üyelerimizin ilham verici
                  hikayeleri
                </p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {successStories.map((story, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-lg transition-all duration-300"
                  >
                    <CardHeader className="text-center">
                      <img
                        src={story.image}
                        alt={story.name}
                        className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                      />
                      <CardTitle className="text-xl">{story.name}</CardTitle>
                      <Badge className="bg-spiritual-gradient text-white">
                        {story.level}
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center mb-4">
                        <div className="text-2xl font-bold text-spiritual-gold-600">
                          {story.monthlyIncome}
                        </div>
                        <div className="text-sm text-gray-500">Aylık Gelir</div>
                        <div className="text-lg font-semibold text-spiritual-turquoise-600 mt-2">
                          {story.teamSize} kişilik takım
                        </div>
                      </div>
                      <blockquote className="text-gray-600 italic text-sm leading-relaxed">
                        "{story.story}"
                      </blockquote>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card className="bg-spiritual-turquoise-50 border-spiritual-turquoise-200">
                <CardContent className="p-8 text-center">
                  <Sparkles className="w-16 h-16 mx-auto mb-4 text-spiritual-turquoise-600" />
                  <h3 className="text-2xl font-bold mb-4 text-spiritual-turquoise-700">
                    Siz de Başarı Hikayesi Olun!
                  </h3>
                  <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                    Bugün binlerce üyemiz düzenli gelir elde ediyor ve manevi
                    gelişimlerini sürdürüyor. Sırada siz varsınız!
                  </p>
                  <Button className="bg-spiritual-gradient text-white text-lg px-8 py-3">
                    Hemen Başla
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Earnings Calculator */}
          <TabsContent value="calculator">
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-spiritual-turquoise-700 mb-4">
                  Kazanç Hesaplama
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Potansiyel kazancınızı hesaplayın ve hedeflerinizi belirleyin
                </p>
              </div>

              <Card className="max-w-4xl mx-auto">
                <CardHeader>
                  <CardTitle className="text-center flex items-center justify-center">
                    <Calculator className="w-6 h-6 mr-2" />
                    Gelir Hesaplayıcı
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Hedef Takım Boyutu
                        </label>
                        <select className="w-full p-3 border border-gray-300 rounded-lg">
                          <option value="5">5 kişi</option>
                          <option value="10">10 kişi</option>
                          <option value="25">25 kişi</option>
                          <option value="50">50 kişi</option>
                          <option value="100">100 kişi</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Aktif Seviye Sayısı
                        </label>
                        <select className="w-full p-3 border border-gray-300 rounded-lg">
                          <option value="3">3 seviye</option>
                          <option value="5">5 seviye</option>
                          <option value="7">7 seviye (Maksimum)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">
                          Aylık Aktivite Hedefi
                        </label>
                        <select className="w-full p-3 border border-gray-300 rounded-lg">
                          <option value="basic">Temel ($500)</option>
                          <option value="standard">Standart ($1,000)</option>
                          <option value="premium">Premium ($2,500)</option>
                          <option value="elite">Elite ($5,000)</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-spiritual-turquoise-50 p-6 rounded-lg">
                      <h3 className="text-xl font-bold mb-4 text-spiritual-turquoise-700">
                        Tahmini Aylık Gelir
                      </h3>
                      <div className="space-y-4">
                        <div className="flex justify-between">
                          <span>Sponsor Bonusu:</span>
                          <span className="font-bold">$150</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Eşleşme Bonusu:</span>
                          <span className="font-bold">$80</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Seviye Bonusu:</span>
                          <span className="font-bold">$200</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Liderlik Bonusu:</span>
                          <span className="font-bold">$100</span>
                        </div>
                        <div className="border-t pt-4">
                          <div className="flex justify-between text-xl font-bold text-spiritual-turquoise-700">
                            <span>Toplam:</span>
                            <span>$530</span>
                          </div>
                        </div>
                      </div>
                      <Alert className="mt-4">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription className="text-sm">
                          Bu hesaplama tahminidir. Gerçek kazançlar performansa
                          ve aktiviteye bağlıdır.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <Card className="bg-spiritual-gradient text-white max-w-4xl mx-auto">
            <CardContent className="p-12">
              <Crown className="w-20 h-20 mx-auto mb-6" />
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Manevi Gelişim Yolculuğunuza Başlayın
              </h2>
              <p className="text-xl mb-8 opacity-90">
                Hem kendinizi geliştirin hem de finansal başarı elde edin. 7
                seviyeli nefs mertebeleri sistemi ile binlerce kişiye katılın.
              </p>
              <div className="flex flex-col md:flex-row justify-center space-y-4 md:space-y-0 md:space-x-6">
                <Button className="bg-white text-spiritual-turquoise-600 hover:bg-gray-100 text-lg px-8 py-4">
                  <Users className="w-5 h-5 mr-2" />
                  Ücretsiz Bilgi Paketi
                </Button>
                <Button className="bg-spiritual-gold-500 text-white hover:bg-spiritual-gold-600 text-lg px-8 py-4">
                  <TrendingUp className="w-5 h-5 mr-2" />
                  Hemen Başla - $10/ay
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default NetworkMLM;
