import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Play, Pause, RotateCcw, Clock } from "lucide-react";
import { formatTime, DHIKR_FORMULAS } from "@/lib/spiritual";

const SpiritualTimer = () => {
  const [selectedDhikr, setSelectedDhikr] = useState(DHIKR_FORMULAS[0]);
  const [currentCount, setCurrentCount] = useState(0);
  const [targetCount, setTargetCount] = useState(selectedDhikr.count);
  const [timeInSeconds, setTimeInSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isActive && !isPaused) {
      interval = setInterval(() => {
        setTimeInSeconds((time) => time + 1);
      }, 1000);
    } else if (!isActive && timeInSeconds !== 0) {
      if (interval) clearInterval(interval);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, isPaused, timeInSeconds]);

  const handleStart = () => {
    setIsActive(true);
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const handleReset = () => {
    setIsActive(false);
    setIsPaused(false);
    setTimeInSeconds(0);
    setCurrentCount(0);
  };

  const handleCountIncrement = () => {
    if (currentCount < targetCount) {
      setCurrentCount((prev) => prev + 1);

      // Play a gentle sound effect (you can add actual audio here)
      if ("vibrate" in navigator) {
        navigator.vibrate(50);
      }

      // Auto-complete when target reached
      if (currentCount + 1 === targetCount) {
        setIsActive(false);
        setIsPaused(false);
        // You can add completion celebration here
      }
    }
  };

  const handleDhikrChange = (value: string) => {
    const dhikr = DHIKR_FORMULAS.find((d) => d.text === value);
    if (dhikr) {
      setSelectedDhikr(dhikr);
      setTargetCount(dhikr.count);
      handleReset();
    }
  };

  const progress = (currentCount / targetCount) * 100;
  const isCompleted = currentCount === targetCount;

  return (
    <Card className="w-full max-w-md mx-auto bg-gradient-to-br from-spiritual-turquoise-50 to-spiritual-purple-50 border-spiritual-turquoise-200">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center space-x-2 text-spiritual-turquoise-700">
          <Clock className="w-6 h-6" />
          <span>Zikir Zamanlayıcısı</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Dhikr Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-spiritual-turquoise-700">
            Zikir Seçin:
          </label>
          <Select value={selectedDhikr.text} onValueChange={handleDhikrChange}>
            <SelectTrigger className="border-spiritual-turquoise-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DHIKR_FORMULAS.map((dhikr) => (
                <SelectItem key={dhikr.text} value={dhikr.text}>
                  <div className="flex flex-col">
                    <span className="font-medium">{dhikr.text}</span>
                    <span className="text-xs text-gray-500">
                      {dhikr.translation}
                    </span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Timer Display */}
        <div className="text-center space-y-2">
          <div className="text-3xl font-bold text-spiritual-purple-700 font-mono">
            {formatTime(timeInSeconds)}
          </div>
          <div className="text-sm text-gray-600">Geçen Süre</div>
        </div>

        {/* Progress Display */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-spiritual-turquoise-700">
              İlerleme
            </span>
            <span className="text-sm text-gray-600">
              {currentCount} / {targetCount}
            </span>
          </div>

          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-spiritual-gradient h-3 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>

          {isCompleted && (
            <div className="text-center text-spiritual-gold-600 font-medium animate-pulse">
              ✨ Tebrikler! Zikrinizi tamamladınız ✨
            </div>
          )}
        </div>

        {/* Current Dhikr Display */}
        <div className="text-center p-4 bg-white/70 rounded-lg border border-spiritual-turquoise-100">
          <div className="text-xl font-bold text-spiritual-purple-700 mb-2">
            {selectedDhikr.text}
          </div>
          <div className="text-sm text-gray-600">
            {selectedDhikr.translation}
          </div>
        </div>

        {/* Count Button */}
        <Button
          onClick={handleCountIncrement}
          disabled={isCompleted}
          className="w-full h-16 text-lg font-semibold bg-spiritual-gradient hover:opacity-90 text-white transition-all duration-200 transform active:scale-95"
        >
          {isCompleted ? "✅ Tamamlandı" : "Saydım (+1)"}
        </Button>

        {/* Control Buttons */}
        <div className="flex space-x-2">
          <Button
            onClick={isActive ? handlePause : handleStart}
            variant="outline"
            className="flex-1 border-spiritual-turquoise-300 text-spiritual-turquoise-700 hover:bg-spiritual-turquoise-50"
          >
            {isActive && !isPaused ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Duraklat
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Başlat
              </>
            )}
          </Button>

          <Button
            onClick={handleReset}
            variant="outline"
            className="flex-1 border-spiritual-purple-300 text-spiritual-purple-700 hover:bg-spiritual-purple-50"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Sıfırla
          </Button>
        </div>

        {/* Status */}
        <div className="text-center text-sm text-gray-500">
          {isActive && !isPaused && "Zamanlayıcı çalışıyor..."}
          {isPaused && "Duraklatıldı"}
          {!isActive && timeInSeconds === 0 && "Başlamaya hazır"}
          {!isActive && timeInSeconds > 0 && "Tamamlandı"}
        </div>
      </CardContent>
    </Card>
  );
};

export default SpiritualTimer;
