import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/contexts/AuthContext";
import {
  Clock,
  Star,
  Heart,
  BookOpen,
  Lock,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Calendar,
  Sunrise,
  Moon,
  Sun,
  Compass,
  Gift,
  Crown,
  Zap,
  CheckCircle,
  AlertCircle,
  Timer,
  Target,
  Headphones,
  Users,
  TrendingUp,
  Award,
  Sparkles,
  Flame,
  MessageSquare,
} from "lucide-react";

const MeditationDhikr = () => {
  const { user } = useAuth();
  const [selectedDhikr, setSelectedDhikr] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentCount, setCurrentCount] = useState(0);
  const [sessionTime, setSessionTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [weeklyProgress, setWeeklyProgress] = useState(65);

  // Comprehensive Dhikr practices based on Islamic sources
  const dhikrPractices = [
    {
      id: 1,
      name: "Tesbih-i Fatıma",
      arabic:
        "سُبْحَانَ اللَّهِ ٣٣ - الْحَمْدُ لِلَّهِ ٣٣ - اللَّهُ أَكْبَرُ ٣٤",
      meaning: "SubhanAllah (33x) - Alhamdulillah (33x) - Allahu Akbar (34x)",
      totalCount: 100,
      duration: "10-15 dakika",
      level: "Başlangıç",
      benefits: [
        "Kalp huzuru ve rahatlık",
        "Günah affı ve temizlik",
        "Manevi güç artışı",
        "Stres azalması",
        "Allah'a yakınlaşma",
      ],
      technique: [
        "Abdest al ve temiz bir yerde otur",
        "Kıbleye dön ve niyetini belirt",
        "Derin nefes al ve odaklan",
        "Her dhikri kalbin ile söyle",
        "Sayacı kullan veya parmaklarınla say",
      ],
      rewards: "Her bir kelime için 10 sevap",
      time: "Her namaz sonrası",
      audio: "/audio/tesbih-fatima.mp3",
      background: "bg-spiritual-turquoise-50",
      color: "text-spiritual-turquoise-700",
    },
    {
      id: 2,
      name: "Esmaül Hüsna Dhikri",
      arabic: "الله - الرحمن - الرحيم - الملك - القدوس",
      meaning: "Allah'ın 99 güzel ismi ile zikir",
      totalCount: 99,
      duration: "20-30 dakika",
      level: "Orta",
      benefits: [
        "Manevi derinlik kazanma",
        "Allah'ın sıfatlarını öğrenme",
        "Kalp nurlanması",
        "Hikmet artışı",
        "Marifet kapılarının açılması",
      ],
      technique: [
        "Her ismin anlamını düşün",
        "O sıfatın tecellisini hisset",
        "Kalbinle bağlantı kur",
        "Yavaş ve anlamlı tekrarla",
        "Meditasyon halinde odaklan",
      ],
      rewards: "Her isim için büyük sevap",
      time: "Sabah ve akşam",
      audio: "/audio/esmaul-husna.mp3",
      background: "bg-spiritual-purple-50",
      color: "text-spiritual-purple-700",
    },
    {
      id: 3,
      name: "İstiğfar Dhikri",
      arabic:
        "أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ",
      meaning:
        "Allah'tan başka ilah olmayan, Diri ve Kayyum olan Allah'tan mağfiret dilerim",
      totalCount: 100,
      duration: "15-20 dakika",
      level: "Başlangıç",
      benefits: [
        "Günah affı ve temizlik",
        "Manevi arınma",
        "Kalp temizliği",
        "Tövbe kabul olması",
        "Rızık artışı",
      ],
      technique: [
        "Pişmanlık ile söyle",
        "Günahlarını hatırla",
        "Samimi tövbe et",
        "Allah'ın affını dile",
        "Tekrar etmeme kararı al",
      ],
      rewards: "Günahların silinmesi",
      time: "Herhangi bir zaman",
      audio: "/audio/istighfar.mp3",
      background: "bg-spiritual-gold-50",
      color: "text-spiritual-gold-700",
    },
    {
      id: 4,
      name: "Salavat Dhikri",
      arabic:
        "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَعَلَىٰ آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَىٰ إِبْرَاهِيمَ",
      meaning: "Allah'ım! Muhammed'e ve ailesine rahmet et",
      totalCount: 100,
      duration: "10-15 dakika",
      level: "Başlangıç",
      benefits: [
        "Hz. Muhammed'in şefaati",
        "Sevap katlanması",
        "Duaların kabulü",
        "Nur ve bereket",
        "Manevi yükselme",
      ],
      technique: [
        "Hz. Muhammed'i hatırla",
        "Sevgi ile söyle",
        "Şefaat dile",
        "Sünnetini düşün",
        "Örnek almaya niyet et",
      ],
      rewards: "10 kat sevap",
      time: "Özellikle Cuma günleri",
      audio: "/audio/salavat.mp3",
      background: "bg-green-50",
      color: "text-green-700",
    },
    {
      id: 5,
      name: "La Havle Dhikri",
      arabic: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ",
      meaning: "Yüce ve Azim Allah'tan başka güç ve kuvvet yoktur",
      totalCount: 100,
      duration: "12-18 dakika",
      level: "Orta",
      benefits: [
        "Güç ve kuvvet artışı",
        "Zorlukların kolaylaşması",
        "Sabır kazanma",
        "Allah'a güven artışı",
        "Manevi destek",
      ],
      technique: [
        "Zorluklarında söyle",
        "Allah'a güven",
        "Teslimiyet hali",
        "Sabır ile devam et",
        "Yardım dile",
      ],
      rewards: "Cennet hazinelerinden",
      time: "Sıkıntı zamanlarında",
      audio: "/audio/la-havle.mp3",
      background: "bg-blue-50",
      color: "text-blue-700",
    },
    {
      id: 6,
      name: "Tevhid Dhikri",
      arabic:
        "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ",
      meaning:
        "Allah'tan başka ilah yoktur, tektir, ortağı yoktur, mülk O'nundur, hamd O'nadır",
      totalCount: 100,
      duration: "20-25 dakika",
      level: "İleri",
      benefits: [
        "İman tazeleme",
        "Tevhid bilincini güçlendirme",
        "Şirk tehlikesinden korunma",
        "Kalp nurlanması",
        "Hakikat müşahedesi",
      ],
      technique: [
        "Tevhidin anlamını düşün",
        "Kalp ile tasdik et",
        "Şirk tehlikelerinden kaçın",
        "Allah'ın birliğini hisset",
        "Derinlemesine tefekkür et",
      ],
      rewards: "En büyük sevap",
      time: "Sabah-akşam",
      audio: "/audio/tevhid.mp3",
      background: "bg-purple-50",
      color: "text-purple-700",
    },
  ];

  // Modern meditation programs with Islamic context
  const meditationPrograms = [
    {
      id: 1,
      title: "Sabah Farkındalık Meditasyonu",
      subtitle: "İslami Mindfulness",
      duration: "15 dakika",
      difficulty: "Başlangıç",
      description: "Güne manevi bir başlangıç yaparak Allah bilinci ile uyanın",
      steps: [
        "Fecir namazından sonra temiz bir yerde oturun",
        "Kıbleye dönük oturum pozisyonu alın",
        "3 defa 'Euzubillah' okuyun",
        "10 defa derin nefes alıp verin",
        "Fatiha suresini yavaşça okuyun",
        "Bugünkü niyetlerinizi belirleyin",
        "Günün şükürlerini düşünün",
        "Sabah duasını yapın",
        "5 dakika sessiz zikir",
        "Günlük hedeflerinizi Allah'a emanet edin",
      ],
      benefits: [
        "Günün bereketli başlaması",
        "Zihinsel netlik",
        "Manevi enerji artışı",
        "Stres azalması",
        "Odaklanma artışı",
      ],
      icon: Sunrise,
      color: "text-yellow-500",
      background: "bg-yellow-50",
      audioGuide: "/audio/sabah-meditasyon.mp3",
      videoGuide: "/video/sabah-meditasyon.mp4",
    },
    {
      id: 2,
      title: "Öğle Dinginlik Meditasyonu",
      subtitle: "Gün Ortası Huzur",
      duration: "10 dakika",
      difficulty: "Başlangıç",
      description: "İş yoğunluğu arasında kalbi dinlendirme ve huzur bulma",
      steps: [
        "Öğle namazı öncesi veya sonrası",
        "Sessiz bir ortam bulun",
        "Ayakta veya oturarak başlayın",
        "Bismillah ile başlayın",
        "İş stresini bırakın",
        "5 dakika nefes farkındalığı",
        "Kalbinizi temizleyin",
        "İstiğfar çekin (10x)",
        "Salavat getirin (10x)",
        "Kısa bir şükür duası",
      ],
      benefits: [
        "İş stresi azalması",
        "Enerji yenilenmesi",
        "Konsantrasyon artışı",
        "İç huzur",
        "Verimlilik artışı",
      ],
      icon: Sun,
      color: "text-orange-500",
      background: "bg-orange-50",
      audioGuide: "/audio/ogle-meditasyon.mp3",
      videoGuide: "/video/ogle-meditasyon.mp4",
    },
    {
      id: 3,
      title: "Akşam Tefekkür Meditasyonu",
      subtitle: "Günün Değerlendirmesi",
      duration: "20 dakika",
      difficulty: "Orta",
      description: "Günü değerlendirme, şükür ve tövbe ile kalbi temizleme",
      steps: [
        "Akşam namazından sonra",
        "Rahat bir pozisyonda oturun",
        "Günün yaşadıklarını gözden geçirin",
        "İyilikleriniz için şükredin",
        "Hatalarınız için tövbe edin",
        "Öğrendiğiniz dersleri değerlendirin",
        "Yarın için plan yapın",
        "Aile ve dostlarınız için dua edin",
        "Akşam duasını yapın",
        "10 dakika sessiz tefekkür",
      ],
      benefits: [
        "Günün huzurlu kapanması",
        "Vicdan muhasebesi",
        "Manevi temizlik",
        "Gelecek motivasyonu",
        "Kaliteli uyku",
      ],
      icon: Moon,
      color: "text-blue-500",
      background: "bg-blue-50",
      audioGuide: "/audio/aksam-meditasyon.mp3",
      videoGuide: "/video/aksam-meditasyon.mp4",
    },
    {
      id: 4,
      title: "Kur'an Meditasyonu",
      subtitle: "Ayetlerle Tefekkür",
      duration: "25 dakika",
      difficulty: "Orta",
      description: "Kur'an ayetlerini tefekkür ederek manevi derinlik kazanma",
      steps: [
        "Abdest alın ve temiz bir yer seçin",
        "Mushafa açın veya ezberden başlayın",
        "Euzubillah ve Bismillah okuyun",
        "Seçtiğiniz sureyi yavaşça okuyun",
        "Her ayetin anlamını düşünün",
        "Allah'ın mesajını kalbe nakşedin",
        "Hayatınızla bağlantı kurun",
        "Dua ile bitirin",
        "10 dakika sessiz düşünce",
        "Amel planı yapın",
      ],
      benefits: [
        "Kur'an anlayışı artışı",
        "Hidayet nuru",
        "Manevi olgunluk",
        "Kalp şifası",
        "Yaşam rehberliği",
      ],
      icon: BookOpen,
      color: "text-green-500",
      background: "bg-green-50",
      audioGuide: "/audio/kuran-meditasyon.mp3",
      videoGuide: "/video/kuran-meditasyon.mp4",
    },
  ];

  // Advanced breathing techniques
  const breathingTechniques = [
    {
      name: "4-7-8 İslami Nefes",
      description: "Zikir ile desteklenen nefes tekniği",
      steps: [
        "4 saniye nefes alırken 'SubhanAllah' say",
        "7 saniye tutarken 'Alhamdulillah' tekrarla",
        "8 saniye verirken 'Allahu Akbar' say",
      ],
      duration: "5-10 dakika",
      benefits: ["Stres azalması", "Uykuya dalmayı kolaylaştırma", "Huzur"],
    },
    {
      name: "Tasbih Nefes",
      description: "Tasbih ile senkronize nefes",
      steps: [
        "Her nefes alışta bir tasbih tanesi çek",
        "Nefes tutarken dhikr yap",
        "Nefes verirken bir sonraki taneye geç",
      ],
      duration: "10-15 dakika",
      benefits: ["Odaklanma", "Zikir devamlılığı", "Kalp huzuru"],
    },
  ];

  // Spiritual development levels
  const spiritualLevels = [
    {
      level: 1,
      name: "Başlangıç",
      requirements: "Günlük 100 dhikr",
      benefits: "Temel huzur",
      color: "bg-green-100",
    },
    {
      level: 2,
      name: "Gelişen",
      requirements: "Günlük 300 dhikr",
      benefits: "Artan bereket",
      color: "bg-blue-100",
    },
    {
      level: 3,
      name: "İlerleyen",
      requirements: "Günlük 500 dhikr",
      benefits: "Manevi güç",
      color: "bg-purple-100",
    },
    {
      level: 4,
      name: "Uzman",
      requirements: "Günl��k 1000 dhikr",
      benefits: "Kalp nurlanması",
      color: "bg-gold-100",
    },
  ];

  const handleDhikrClick = () => {
    setCurrentCount((prev) => prev + 1);
    if ("vibrate" in navigator) {
      navigator.vibrate(50);
    }
  };

  const resetCounter = () => {
    setCurrentCount(0);
    setSessionTime(0);
  };

  useEffect(() => {
    if (isPlaying) {
      const timer = setInterval(() => {
        setSessionTime((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isPlaying]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const selectedDhikrData = dhikrPractices[selectedDhikr];
  const progress = selectedDhikrData
    ? (currentCount / selectedDhikrData.totalCount) * 100
    : 0;

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            Dhikr & İslami Meditasyon
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Kur'an ve Sünnet rehberliğinde kalp temizliği, manevi gelişim ve
            modern mindfulness pratikleri. Allah'ı zikretme sanatı ile iç huzur
            ve manevi güç kazanın.
          </p>
          <div className="flex justify-center space-x-4 mt-6">
            <Badge className="bg-spiritual-turquoise-100 text-spiritual-turquoise-700">
              6 Farklı Dhikr Çeşidi
            </Badge>
            <Badge className="bg-spiritual-purple-100 text-spiritual-purple-700">
              4 Meditasyon Programı
            </Badge>
            <Badge className="bg-spiritual-gold-100 text-spiritual-gold-700">
              Rehberli Seanslar
            </Badge>
          </div>
        </div>

        {/* Membership Alert */}
        {!user?.isActive && (
          <Alert className="mb-8 border-orange-200 bg-orange-50">
            <Lock className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <strong>Önemli:</strong> Bu dhikr ve meditasyon rehberlerine tam
              erişim için aylık $10 abonelik gereklidir. Sesli rehberlik,
              ilerleme takibi ve kişisel programlar sadece üyeler için
              mevcuttur.{" "}
              <Button variant="link" className="text-orange-600 p-0 ml-2">
                Hemen üye ol
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Quick Stats */}
        {user?.isActive && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-white/80 backdrop-blur-sm text-center p-4">
              <Timer className="w-6 h-6 text-spiritual-turquoise-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {Math.floor(sessionTime / 60)}m
              </div>
              <div className="text-xs text-gray-500">Bu Seans</div>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm text-center p-4">
              <Target className="w-6 h-6 text-spiritual-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {currentCount}
              </div>
              <div className="text-xs text-gray-500">Sayım</div>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm text-center p-4">
              <TrendingUp className="w-6 h-6 text-spiritual-gold-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {weeklyProgress}%
              </div>
              <div className="text-xs text-gray-500">Haftalık</div>
            </Card>
            <Card className="bg-white/80 backdrop-blur-sm text-center p-4">
              <Award className="w-6 h-6 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">47</div>
              <div className="text-xs text-gray-500">Gün Sırası</div>
            </Card>
          </div>
        )}

        <Tabs defaultValue="dhikr" className="space-y-8">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="dhikr">Dhikr Pratikleri</TabsTrigger>
            <TabsTrigger value="meditation">Meditasyon</TabsTrigger>
            <TabsTrigger value="breathing">Nefes Teknikleri</TabsTrigger>
            <TabsTrigger value="progress">İlerleme</TabsTrigger>
            <TabsTrigger value="guidance">Rehberlik</TabsTrigger>
          </TabsList>

          {/* Dhikr Practices */}
          <TabsContent value="dhikr" className="space-y-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Dhikr Selection */}
              <div className="lg:col-span-1">
                <Card className="bg-white/80 backdrop-blur-sm sticky top-4">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Star className="w-6 h-6 text-spiritual-gold-600" />
                      <span>Dhikr Seçimi</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {dhikrPractices.map((dhikr, index) => (
                      <button
                        key={dhikr.id}
                        onClick={() => setSelectedDhikr(index)}
                        className={`w-full text-left p-3 rounded-lg border transition-all duration-200 ${
                          selectedDhikr === index
                            ? "border-spiritual-turquoise-300 bg-spiritual-turquoise-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="font-medium text-sm">{dhikr.name}</div>
                        <div className="text-xs text-gray-500 flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {dhikr.level}
                          </Badge>
                          <span>{dhikr.duration}</span>
                        </div>
                      </button>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Main Dhikr Interface */}
              <div className="lg:col-span-2">
                <Card
                  className={`bg-white/80 backdrop-blur-sm ${
                    !user?.isActive ? "opacity-75" : ""
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className={selectedDhikrData.color}>
                        {selectedDhikrData.name}
                      </span>
                      <Badge className={selectedDhikrData.background}>
                        {selectedDhikrData.level}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Arabic Text */}
                    <div
                      className={`text-center p-6 rounded-lg ${selectedDhikrData.background}`}
                    >
                      <div className="text-2xl arabic-text mb-4 leading-relaxed">
                        {selectedDhikrData.arabic}
                      </div>
                      <div className="text-sm text-gray-700">
                        {selectedDhikrData.meaning}
                      </div>
                    </div>

                    {/* Progress */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>İlerleme</span>
                        <span>
                          {currentCount} / {selectedDhikrData.totalCount}
                        </span>
                      </div>
                      <Progress value={progress} className="h-3" />
                      <div className="text-center">
                        <span className="text-2xl font-bold text-spiritual-turquoise-600">
                          {progress.toFixed(1)}%
                        </span>
                      </div>
                    </div>

                    {/* Timer Display */}
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-3xl font-mono font-bold text-gray-800">
                        {formatTime(sessionTime)}
                      </div>
                      <div className="text-sm text-gray-600">Geçen Süre</div>
                    </div>

                    {/* Count Button */}
                    <Button
                      onClick={handleDhikrClick}
                      disabled={!user?.isActive}
                      className="w-full h-20 text-xl font-bold bg-spiritual-gradient hover:opacity-90 text-white transition-all duration-200 transform active:scale-95"
                    >
                      {currentCount >= selectedDhikrData.totalCount ? (
                        <>
                          <CheckCircle className="w-6 h-6 mr-2" />
                          Tamamlandı - MaşaAllah!
                        </>
                      ) : (
                        <>
                          <Heart className="w-6 h-6 mr-2" />
                          Dhikr Yap (+1)
                        </>
                      )}
                    </Button>

                    {/* Controls */}
                    <div className="flex space-x-3">
                      <Button
                        onClick={() => setIsPlaying(!isPlaying)}
                        variant="outline"
                        className="flex-1"
                        disabled={!user?.isActive}
                      >
                        {isPlaying ? (
                          <>
                            <Pause className="w-4 h-4 mr-2" />
                            Duraklat
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Başlat
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={resetCounter}
                        variant="outline"
                        disabled={!user?.isActive}
                      >
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setIsMuted(!isMuted)}
                        disabled={!user?.isActive}
                      >
                        {isMuted ? (
                          <VolumeX className="w-4 h-4" />
                        ) : (
                          <Volume2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>

                    {!user?.isActive && (
                      <div className="text-center text-sm text-gray-500 bg-orange-50 p-3 rounded">
                        Dhikr zamanlayıcısı ve sesli rehberlik için üyelik
                        gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Benefits & Technique */}
                <div className="grid md:grid-cols-2 gap-6 mt-6">
                  <Card className="bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Faydaları</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {selectedDhikrData.benefits.map((benefit, index) => (
                          <li
                            key={index}
                            className="flex items-center space-x-2 text-sm"
                          >
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-white/80 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-lg">Teknik</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ol className="space-y-2">
                        {selectedDhikrData.technique.map((step, index) => (
                          <li
                            key={index}
                            className="flex items-start space-x-2 text-sm"
                          >
                            <span className="flex-shrink-0 w-5 h-5 bg-spiritual-turquoise-100 text-spiritual-turquoise-600 rounded-full flex items-center justify-center text-xs font-medium">
                              {index + 1}
                            </span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Meditation Programs */}
          <TabsContent value="meditation" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {meditationPrograms.map((program) => (
                <Card
                  key={program.id}
                  className={`bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 ${
                    !user?.isActive ? "opacity-75" : ""
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <program.icon className={`w-6 h-6 ${program.color}`} />
                      <div>
                        <div>{program.title}</div>
                        <div className="text-sm font-normal text-gray-600">
                          {program.subtitle}
                        </div>
                      </div>
                    </CardTitle>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <span className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{program.duration}</span>
                      </span>
                      <Badge variant="outline">{program.difficulty}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700 text-sm">
                      {program.description}
                    </p>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                        Program Adımları:
                      </h4>
                      <div className="space-y-1 max-h-32 overflow-y-auto">
                        {program.steps.slice(0, 5).map((step, index) => (
                          <div
                            key={index}
                            className="flex items-start space-x-2 text-xs"
                          >
                            <span className="flex-shrink-0 w-4 h-4 bg-spiritual-turquoise-100 text-spiritual-turquoise-600 rounded-full flex items-center justify-center text-xs">
                              {index + 1}
                            </span>
                            <span>{step}</span>
                          </div>
                        ))}
                        {program.steps.length > 5 && (
                          <div className="text-xs text-gray-500 ml-6">
                            +{program.steps.length - 5} adım daha...
                          </div>
                        )}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                        Beklenen Faydalar:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {program.benefits.map((benefit, index) => (
                          <Badge
                            key={index}
                            variant="outline"
                            className="text-xs"
                          >
                            {benefit}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        className="flex-1 bg-spiritual-gradient text-white"
                        disabled={!user?.isActive}
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Başlat
                      </Button>
                      <Button
                        variant="outline"
                        disabled={!user?.isActive}
                        className="flex items-center space-x-1"
                      >
                        <Headphones className="w-4 h-4" />
                        <span className="hidden sm:inline">Sesli</span>
                      </Button>
                    </div>

                    {!user?.isActive && (
                      <div className="text-center text-xs text-gray-500 bg-orange-50 p-2 rounded">
                        Rehberli meditasyon için üyelik gereklidir
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Breathing Techniques */}
          <TabsContent value="breathing" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {breathingTechniques.map((technique, index) => (
                <Card
                  key={index}
                  className="bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
                >
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Flame className="w-6 h-6 text-red-500" />
                      <span>{technique.name}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700 text-sm">
                      {technique.description}
                    </p>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Adımlar:
                      </h4>
                      <ol className="space-y-2">
                        {technique.steps.map((step, stepIndex) => (
                          <li
                            key={stepIndex}
                            className="flex items-start space-x-2 text-sm"
                          >
                            <span className="flex-shrink-0 w-5 h-5 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-xs font-medium">
                              {stepIndex + 1}
                            </span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Süre: {technique.duration}</span>
                    </div>
                    <Button
                      className="w-full bg-red-500 text-white hover:bg-red-600"
                      disabled={!user?.isActive}
                    >
                      Tekniği Uygula
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Progress Tracking */}
          <TabsContent value="progress" className="space-y-8">
            {user?.isActive ? (
              <div className="grid lg:grid-cols-2 gap-8">
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Manevi Gelişim Seviyen</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {spiritualLevels.map((level) => (
                      <div
                        key={level.level}
                        className={`p-3 rounded-lg ${level.color} flex items-center justify-between`}
                      >
                        <div>
                          <div className="font-semibold">{level.name}</div>
                          <div className="text-sm text-gray-600">
                            {level.requirements}
                          </div>
                        </div>
                        <div className="text-sm text-gray-600">
                          {level.benefits}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Haftalık Aktivite</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-spiritual-turquoise-600">
                          {weeklyProgress}%
                        </div>
                        <div className="text-sm text-gray-600">
                          Bu hafta tamamlanan
                        </div>
                      </div>
                      <Progress value={weeklyProgress} className="h-3" />
                      <div className="grid grid-cols-7 gap-1">
                        {Array.from({ length: 7 }, (_, i) => (
                          <div
                            key={i}
                            className={`h-8 rounded flex items-center justify-center text-xs ${
                              i < 5
                                ? "bg-spiritual-turquoise-500 text-white"
                                : "bg-gray-200"
                            }`}
                          >
                            {["P", "S", "Ç", "P", "C", "C", "P"][i]}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardContent className="p-8 text-center">
                  <Lock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    İlerleme Takibi
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Manevi gelişim ilerlemenizi takip etmek için üyelik
                    gereklidir
                  </p>
                  <Button className="bg-spiritual-gradient text-white">
                    Üye Ol
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Spiritual Guidance */}
          <TabsContent value="guidance" className="space-y-8">
            <Card className="bg-spiritual-gradient text-white">
              <CardContent className="p-8 text-center">
                <Crown className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-4">
                  Kişisel Manevi Rehberlik
                </h3>
                <p className="mb-6 text-white/90">
                  Uzman manevi rehberlerimizden birebir destek alın. İslami
                  kaynaklara dayalı kişiselleştirilmiş dhikr ve meditasyon
                  programları.
                </p>
                <div className="grid md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-white/10 p-4 rounded-lg">
                    <Users className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm">Uzman Rehberler</div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <Star className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm">Kişisel Program</div>
                  </div>
                  <div className="bg-white/10 p-4 rounded-lg">
                    <MessageSquare className="w-6 h-6 mx-auto mb-2" />
                    <div className="text-sm">24/7 Destek</div>
                  </div>
                </div>
                <Button
                  className="bg-white text-spiritual-turquoise-700 hover:bg-gray-100"
                  disabled={!user?.isActive}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Rehberlik Talep Et
                </Button>
              </CardContent>
            </Card>

            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Dhikr Danışmanlığı</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Kişisel durumunuza uygun dhikr programı oluşturma
                  </p>
                  <ul className="space-y-1 text-xs">
                    <li>• Kişisel manevi değerlendirme</li>
                    <li>• Özel dhikr kombinasyonları</li>
                    <li>• Haftalık gelişim takibi</li>
                    <li>• Teknik rehberlik</li>
                  </ul>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    disabled={!user?.isActive}
                  >
                    Danışmanlık Al
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-lg">
                    Meditasyon Rehberliği
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    İslami meditasyon teknikleri öğretimi ve uygulaması
                  </p>
                  <ul className="space-y-1 text-xs">
                    <li>• Kişisel meditasyon planı</li>
                    <li>• Canlı rehberli seanslar</li>
                    <li>• Nefes teknikleri eğitimi</li>
                    <li>• Grup meditasyonlar��</li>
                  </ul>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    disabled={!user?.isActive}
                  >
                    Rehberlik Al
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-lg">Manevi Koçluk</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Günlük yaşamda manevi pratiklerin uygulanması
                  </p>
                  <ul className="space-y-1 text-xs">
                    <li>• Yaşam tarzı entegrasyonu</li>
                    <li>• Manevi hedef belirleme</li>
                    <li>• İlerleme değerlendirmesi</li>
                    <li>• Motivasyon desteği</li>
                  </ul>
                  <Button
                    className="w-full mt-4"
                    variant="outline"
                    disabled={!user?.isActive}
                  >
                    Koçluk Al
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MeditationDhikr;
