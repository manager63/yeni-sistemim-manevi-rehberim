import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";
import {
  Shield,
  Users,
  DollarSign,
  Settings,
  BarChart,
  FileText,
  Upload,
  Download,
  Edit,
  Trash2,
  Plus,
  Save,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Globe,
  Database,
  Image,
  Video,
  Mail,
  Bell,
  Palette,
  Code,
  Monitor,
  Lock,
  Key,
  Zap,
  Crown,
  Star,
  Gift,
  Target,
  Search,
  Filter,
  MoreHorizontal,
  Eye,
  Calendar,
  Clock,
  MapPin,
  Phone,
  MessageSquare,
  BookOpen,
  Music,
  Package,
  CreditCard,
  UserPlus,
  UserMinus,
  UserCheck,
  UserX,
} from "lucide-react";

interface User {
  id: number;
  name: string;
  email: string;
  phone?: string;
  subscriptionActive: boolean;
  subscriptionType: "monthly" | "yearly" | "free";
  registrationDate: string;
  lastLogin: string;
  totalEarnings: number;
  teamSize: number;
  nefsLevel: number;
  sponsorId?: number;
  isAdmin: boolean;
  status: "active" | "inactive" | "suspended";
}

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  inStock: boolean;
  sales: number;
  status: "active" | "inactive";
}

interface ContentItem {
  id: number;
  title: string;
  type: "quote" | "prayer" | "dhikr" | "article";
  content: string;
  author?: string;
  category: string;
  isActive: boolean;
  lastUpdated: string;
}

const EnhancedAdminPanel = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect if not admin
  useEffect(() => {
    if (!user || !user.isAdmin) {
      navigate("/");
    }
  }, [user, navigate]);

  // Sample Data
  const [users, setUsers] = useState<User[]>([
    {
      id: 1,
      name: "Ahmet Yılmaz",
      email: "ahmet@email.com",
      phone: "+90 532 123 4567",
      subscriptionActive: true,
      subscriptionType: "monthly",
      registrationDate: "2024-01-15",
      lastLogin: "2024-01-20",
      totalEarnings: 1250,
      teamSize: 15,
      nefsLevel: 3,
      sponsorId: undefined,
      isAdmin: false,
      status: "active",
    },
    {
      id: 2,
      name: "Fatma Demir",
      email: "fatma@email.com",
      phone: "+90 534 567 8901",
      subscriptionActive: true,
      subscriptionType: "yearly",
      registrationDate: "2024-01-10",
      lastLogin: "2024-01-19",
      totalEarnings: 2100,
      teamSize: 28,
      nefsLevel: 4,
      sponsorId: undefined,
      isAdmin: false,
      status: "active",
    },
    {
      id: 3,
      name: "Mehmet Kaya",
      email: "mehmet@email.com",
      subscriptionActive: false,
      subscriptionType: "free",
      registrationDate: "2024-01-18",
      lastLogin: "2024-01-18",
      totalEarnings: 0,
      teamSize: 0,
      nefsLevel: 1,
      sponsorId: 1,
      isAdmin: false,
      status: "inactive",
    },
  ]);

  const [products, setProducts] = useState<Product[]>([
    {
      id: 1,
      name: "Kur'an-ı Kerim - Özel Cilt",
      description: "Altın varaklı, el sanatı ciltli Kur'an-ı Kerim",
      price: 299,
      category: "books",
      inStock: true,
      sales: 45,
      status: "active",
    },
    {
      id: 2,
      name: "Zikir Meditasyonu Rehberi",
      description: "Ses rehberli zikir meditasyonu",
      price: 79,
      category: "audio",
      inStock: true,
      sales: 123,
      status: "active",
    },
  ]);

  const [contentItems, setContentItems] = useState<ContentItem[]>([
    {
      id: 1,
      title: "Günün Duası",
      type: "prayer",
      content:
        "Rabbena atina fi'd dünya haseneten ve fi'l ahirati haseneten ve kına azabin nar.",
      author: "Kur'an-ı Kerim",
      category: "daily",
      isActive: true,
      lastUpdated: "2024-01-20",
    },
    {
      id: 2,
      title: "Sabır Üzerine",
      type: "quote",
      content: "Sabır, iman nısfıdır.",
      author: "Hz. Muhammed (SAV)",
      category: "spiritual",
      isActive: true,
      lastUpdated: "2024-01-19",
    },
  ]);

  // State for new user/product/content forms
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    phone: "",
    subscriptionType: "free" as "free" | "monthly" | "yearly",
    isAdmin: false,
  });

  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    inStock: true,
  });

  const [newContent, setNewContent] = useState({
    title: "",
    type: "quote" as "quote" | "prayer" | "dhikr" | "article",
    content: "",
    author: "",
    category: "",
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [userFilter, setUserFilter] = useState("all");

  // User Management Functions
  const addUser = () => {
    if (newUser.name && newUser.email) {
      const user: User = {
        id: Date.now(),
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        subscriptionActive: newUser.subscriptionType !== "free",
        subscriptionType: newUser.subscriptionType,
        registrationDate: new Date().toISOString().split("T")[0],
        lastLogin: new Date().toISOString().split("T")[0],
        totalEarnings: 0,
        teamSize: 0,
        nefsLevel: 1,
        isAdmin: newUser.isAdmin,
        status: "active",
      };
      setUsers([...users, user]);
      setNewUser({
        name: "",
        email: "",
        phone: "",
        subscriptionType: "free",
        isAdmin: false,
      });
    }
  };

  const updateUserStatus = (
    userId: number,
    status: "active" | "inactive" | "suspended",
  ) => {
    setUsers(
      users.map((user) => (user.id === userId ? { ...user, status } : user)),
    );
  };

  const updateUserSubscription = (
    userId: number,
    subscriptionType: "monthly" | "yearly" | "free",
  ) => {
    setUsers(
      users.map((user) =>
        user.id === userId
          ? {
              ...user,
              subscriptionType,
              subscriptionActive: subscriptionType !== "free",
            }
          : user,
      ),
    );
  };

  const deleteUser = (userId: number) => {
    setUsers(users.filter((user) => user.id !== userId));
  };

  // Product Management Functions
  const addProduct = () => {
    if (newProduct.name && newProduct.description && newProduct.price) {
      const product: Product = {
        id: Date.now(),
        name: newProduct.name,
        description: newProduct.description,
        price: parseFloat(newProduct.price),
        category: newProduct.category,
        inStock: newProduct.inStock,
        sales: 0,
        status: "active",
      };
      setProducts([...products, product]);
      setNewProduct({
        name: "",
        description: "",
        price: "",
        category: "",
        inStock: true,
      });
    }
  };

  const updateProductStatus = (
    productId: number,
    status: "active" | "inactive",
  ) => {
    setProducts(
      products.map((product) =>
        product.id === productId ? { ...product, status } : product,
      ),
    );
  };

  const deleteProduct = (productId: number) => {
    setProducts(products.filter((product) => product.id !== productId));
  };

  // Content Management Functions
  const addContent = () => {
    if (newContent.title && newContent.content) {
      const content: ContentItem = {
        id: Date.now(),
        title: newContent.title,
        type: newContent.type,
        content: newContent.content,
        author: newContent.author,
        category: newContent.category,
        isActive: true,
        lastUpdated: new Date().toISOString().split("T")[0],
      };
      setContentItems([...contentItems, content]);
      setNewContent({
        title: "",
        type: "quote",
        content: "",
        author: "",
        category: "",
      });
    }
  };

  const toggleContentStatus = (contentId: number) => {
    setContentItems(
      contentItems.map((item) =>
        item.id === contentId ? { ...item, isActive: !item.isActive } : item,
      ),
    );
  };

  const deleteContent = (contentId: number) => {
    setContentItems(contentItems.filter((item) => item.id !== contentId));
  };

  // Filter functions
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter =
      userFilter === "all" ||
      (userFilter === "active" && user.subscriptionActive) ||
      (userFilter === "inactive" && !user.subscriptionActive) ||
      (userFilter === "admin" && user.isAdmin);
    return matchesSearch && matchesFilter;
  });

  // Statistics
  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter((u) => u.subscriptionActive).length,
    totalRevenue: users.reduce((sum, u) => sum + u.totalEarnings, 0),
    totalProducts: products.length,
    activeProducts: products.filter((p) => p.status === "active").length,
    totalContent: contentItems.length,
    activeContent: contentItems.filter((c) => c.isActive).length,
  };

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-spiritual-gradient bg-clip-text text-transparent mb-4">
            <Shield className="w-8 h-8 inline-block mr-2" />
            Admin Yönetim Paneli
          </h1>
          <p className="text-gray-600">Sistem yönetimi ve içerik kontrolü</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center">
            <CardContent className="p-4">
              <Users className="w-8 h-8 mx-auto mb-2 text-spiritual-turquoise-600" />
              <div className="text-2xl font-bold text-spiritual-turquoise-600">
                {stats.totalUsers}
              </div>
              <div className="text-sm text-gray-600">Toplam Üye</div>
              <div className="text-xs text-green-600">
                {stats.activeUsers} aktif
              </div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <DollarSign className="w-8 h-8 mx-auto mb-2 text-spiritual-gold-600" />
              <div className="text-2xl font-bold text-spiritual-gold-600">
                ${stats.totalRevenue}
              </div>
              <div className="text-sm text-gray-600">Toplam Gelir</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <Package className="w-8 h-8 mx-auto mb-2 text-spiritual-purple-600" />
              <div className="text-2xl font-bold text-spiritual-purple-600">
                {stats.totalProducts}
              </div>
              <div className="text-sm text-gray-600">Toplam Ürün</div>
              <div className="text-xs text-green-600">
                {stats.activeProducts} aktif
              </div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="p-4">
              <FileText className="w-8 h-8 mx-auto mb-2 text-spiritual-turquoise-600" />
              <div className="text-2xl font-bold text-spiritual-turquoise-600">
                {stats.totalContent}
              </div>
              <div className="text-sm text-gray-600">İçerik</div>
              <div className="text-xs text-green-600">
                {stats.activeContent} aktif
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 bg-white/80">
            <TabsTrigger value="users" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Üye Yönetimi</span>
            </TabsTrigger>
            <TabsTrigger
              value="products"
              className="flex items-center space-x-2"
            >
              <Package className="w-4 h-4" />
              <span>Ürün Yönetimi</span>
            </TabsTrigger>
            <TabsTrigger
              value="content"
              className="flex items-center space-x-2"
            >
              <FileText className="w-4 h-4" />
              <span>İçerik Yönetimi</span>
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="flex items-center space-x-2"
            >
              <Settings className="w-4 h-4" />
              <span>Sistem Ayarları</span>
            </TabsTrigger>
          </TabsList>

          {/* User Management */}
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <CardTitle className="flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Üye Yönetimi
                  </CardTitle>
                  <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Üye ara..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-full md:w-64"
                      />
                    </div>
                    <Select value={userFilter} onValueChange={setUserFilter}>
                      <SelectTrigger className="w-full md:w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tümü</SelectItem>
                        <SelectItem value="active">Aktif</SelectItem>
                        <SelectItem value="inactive">Pasif</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="bg-spiritual-gradient text-white">
                          <UserPlus className="w-4 h-4 mr-2" />
                          Yeni Üye
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Yeni Üye Ekle</DialogTitle>
                          <DialogDescription>
                            Sisteme yeni bir üye ekleyin
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="name">Ad Soyad</Label>
                            <Input
                              id="name"
                              value={newUser.name}
                              onChange={(e) =>
                                setNewUser({ ...newUser, name: e.target.value })
                              }
                            />
                          </div>
                          <div>
                            <Label htmlFor="email">E-posta</Label>
                            <Input
                              id="email"
                              type="email"
                              value={newUser.email}
                              onChange={(e) =>
                                setNewUser({
                                  ...newUser,
                                  email: e.target.value,
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label htmlFor="phone">Telefon</Label>
                            <Input
                              id="phone"
                              value={newUser.phone}
                              onChange={(e) =>
                                setNewUser({
                                  ...newUser,
                                  phone: e.target.value,
                                })
                              }
                            />
                          </div>
                          <div>
                            <Label htmlFor="subscription">Abonelik Türü</Label>
                            <Select
                              value={newUser.subscriptionType}
                              onValueChange={(value: any) =>
                                setNewUser({
                                  ...newUser,
                                  subscriptionType: value,
                                })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="free">Ücretsiz</SelectItem>
                                <SelectItem value="monthly">
                                  Aylık ($10)
                                </SelectItem>
                                <SelectItem value="yearly">
                                  Yıllık ($100)
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch
                              id="admin"
                              checked={newUser.isAdmin}
                              onCheckedChange={(checked) =>
                                setNewUser({ ...newUser, isAdmin: checked })
                              }
                            />
                            <Label htmlFor="admin">Admin yetkisi</Label>
                          </div>
                          <Button
                            onClick={addUser}
                            className="w-full bg-spiritual-gradient text-white"
                          >
                            <UserPlus className="w-4 h-4 mr-2" />
                            Üye Ekle
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Üye</TableHead>
                        <TableHead>İletişim</TableHead>
                        <TableHead>Abonelik</TableHead>
                        <TableHead>Kazanç</TableHead>
                        <TableHead>Ekip</TableHead>
                        <TableHead>Durum</TableHead>
                        <TableHead>İşlemler</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium flex items-center">
                                {user.name}
                                {user.isAdmin && (
                                  <Crown className="w-4 h-4 ml-2 text-yellow-500" />
                                )}
                              </div>
                              <div className="text-sm text-gray-500">
                                Seviye {user.nefsLevel} •{" "}
                                {user.registrationDate}
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{user.email}</div>
                              {user.phone && (
                                <div className="text-gray-500">
                                  {user.phone}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={user.subscriptionType}
                              onValueChange={(value: any) =>
                                updateUserSubscription(user.id, value)
                              }
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="free">Ücretsiz</SelectItem>
                                <SelectItem value="monthly">Aylık</SelectItem>
                                <SelectItem value="yearly">Yıllık</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">
                              ${user.totalEarnings}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium">
                              {user.teamSize} kişi
                            </div>
                          </TableCell>
                          <TableCell>
                            <Select
                              value={user.status}
                              onValueChange={(value: any) =>
                                updateUserStatus(user.id, value)
                              }
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="active">Aktif</SelectItem>
                                <SelectItem value="inactive">Pasif</SelectItem>
                                <SelectItem value="suspended">
                                  Askıya Alınmış
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline">
                                <Eye className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteUser(user.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Product Management */}
          <TabsContent value="products">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Package className="w-5 h-5 mr-2" />
                    Ürün Yönetimi
                  </CardTitle>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="bg-spiritual-gradient text-white">
                        <Plus className="w-4 h-4 mr-2" />
                        Yeni Ürün
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Yeni Ürün Ekle</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="productName">Ürün Adı</Label>
                          <Input
                            id="productName"
                            value={newProduct.name}
                            onChange={(e) =>
                              setNewProduct({
                                ...newProduct,
                                name: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label htmlFor="productDescription">Açıklama</Label>
                          <Textarea
                            id="productDescription"
                            value={newProduct.description}
                            onChange={(e) =>
                              setNewProduct({
                                ...newProduct,
                                description: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label htmlFor="productPrice">Fiyat ($)</Label>
                          <Input
                            id="productPrice"
                            type="number"
                            value={newProduct.price}
                            onChange={(e) =>
                              setNewProduct({
                                ...newProduct,
                                price: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label htmlFor="productCategory">Kategori</Label>
                          <Input
                            id="productCategory"
                            value={newProduct.category}
                            onChange={(e) =>
                              setNewProduct({
                                ...newProduct,
                                category: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            id="inStock"
                            checked={newProduct.inStock}
                            onCheckedChange={(checked) =>
                              setNewProduct({ ...newProduct, inStock: checked })
                            }
                          />
                          <Label htmlFor="inStock">Stokta mevcut</Label>
                        </div>
                        <Button
                          onClick={addProduct}
                          className="w-full bg-spiritual-gradient text-white"
                        >
                          Ürün Ekle
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ürün</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Fiyat</TableHead>
                      <TableHead>Satış</TableHead>
                      <TableHead>Stok</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{product.name}</div>
                            <div className="text-sm text-gray-500">
                              {product.description}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{product.category}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">${product.price}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{product.sales}</div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              product.inStock ? "default" : "destructive"
                            }
                          >
                            {product.inStock ? "Mevcut" : "Tükendi"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Switch
                            checked={product.status === "active"}
                            onCheckedChange={(checked) =>
                              updateProductStatus(
                                product.id,
                                checked ? "active" : "inactive",
                              )
                            }
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteProduct(product.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Management */}
          <TabsContent value="content">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    İçerik Yönetimi
                  </CardTitle>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="bg-spiritual-gradient text-white">
                        <Plus className="w-4 h-4 mr-2" />
                        Yeni İçerik
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Yeni İçerik Ekle</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="contentTitle">Başlık</Label>
                          <Input
                            id="contentTitle"
                            value={newContent.title}
                            onChange={(e) =>
                              setNewContent({
                                ...newContent,
                                title: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label htmlFor="contentType">Tür</Label>
                          <Select
                            value={newContent.type}
                            onValueChange={(value: any) =>
                              setNewContent({ ...newContent, type: value })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="quote">Söz</SelectItem>
                              <SelectItem value="prayer">Dua</SelectItem>
                              <SelectItem value="dhikr">Zikir</SelectItem>
                              <SelectItem value="article">Makale</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="contentContent">İçerik</Label>
                          <Textarea
                            id="contentContent"
                            rows={4}
                            value={newContent.content}
                            onChange={(e) =>
                              setNewContent({
                                ...newContent,
                                content: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label htmlFor="contentAuthor">Yazar</Label>
                          <Input
                            id="contentAuthor"
                            value={newContent.author}
                            onChange={(e) =>
                              setNewContent({
                                ...newContent,
                                author: e.target.value,
                              })
                            }
                          />
                        </div>
                        <div>
                          <Label htmlFor="contentCategory">Kategori</Label>
                          <Input
                            id="contentCategory"
                            value={newContent.category}
                            onChange={(e) =>
                              setNewContent({
                                ...newContent,
                                category: e.target.value,
                              })
                            }
                          />
                        </div>
                        <Button
                          onClick={addContent}
                          className="w-full bg-spiritual-gradient text-white"
                        >
                          İçerik Ekle
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Başlık</TableHead>
                      <TableHead>Tür</TableHead>
                      <TableHead>Yazar</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Güncelleme</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contentItems.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{item.title}</div>
                            <div className="text-sm text-gray-500 line-clamp-2">
                              {item.content}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{item.type}</Badge>
                        </TableCell>
                        <TableCell>{item.author}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>{item.lastUpdated}</TableCell>
                        <TableCell>
                          <Switch
                            checked={item.isActive}
                            onCheckedChange={() => toggleContentStatus(item.id)}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteContent(item.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Settings */}
          <TabsContent value="settings">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="w-5 h-5 mr-2" />
                    Sistem Ayarları
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="siteName">Site Adı</Label>
                      <Input id="siteName" defaultValue="Manevi Rehberim" />
                    </div>
                    <div>
                      <Label htmlFor="adminEmail">Admin E-posta</Label>
                      <Input
                        id="adminEmail"
                        defaultValue="admin@manevireberim.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="monthlyPrice">Aylık Fiyat ($)</Label>
                      <Input
                        id="monthlyPrice"
                        type="number"
                        defaultValue="10"
                      />
                    </div>
                    <div>
                      <Label htmlFor="yearlyPrice">Yıllık Fiyat ($)</Label>
                      <Input
                        id="yearlyPrice"
                        type="number"
                        defaultValue="100"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">
                      Sistem Kontrolleri
                    </h3>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Yeni Kayıtlar</div>
                        <div className="text-sm text-gray-500">
                          Yeni üye kayıtlarına izin ver
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">E-posta Bildirimleri</div>
                        <div className="text-sm text-gray-500">
                          Otomatik e-posta gönderimi
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Bakım Modu</div>
                        <div className="text-sm text-gray-500">
                          Siteyi bakım moduna al
                        </div>
                      </div>
                      <Switch />
                    </div>
                  </div>

                  <Button className="bg-spiritual-gradient text-white">
                    <Save className="w-4 h-4 mr-2" />
                    Ayarları Kaydet
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="w-5 h-5 mr-2" />
                    Veri Yönetimi
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <Button variant="outline" className="flex items-center">
                      <Download className="w-4 h-4 mr-2" />
                      Verileri Dışa Aktar
                    </Button>
                    <Button variant="outline" className="flex items-center">
                      <Upload className="w-4 h-4 mr-2" />
                      Verileri İçe Aktar
                    </Button>
                    <Button variant="outline" className="flex items-center">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Veritabanını Temizle
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default EnhancedAdminPanel;
