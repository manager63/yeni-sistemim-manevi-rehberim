import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  MessageSquare,
  Send,
  Bot,
  User,
  Loader2,
  Sparkles,
  X,
  RefreshCw,
  Copy,
  ThumbsUp,
  ThumbsDown,
} from "lucide-react";

interface Message {
  id: number;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
  isTyping?: boolean;
}

const AiChat = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: "ai",
      content:
        "Merhaba! Ben Manevi Rehberim AI asistanıyım. Size İslami konularda, manevi gelişim hakkında ve platform kullanımıyla ilgili sorularınızda yardımcı olabilirim. Nasıl yardımcı olabilirim?",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Simulated AI responses based on keywords
  const getAiResponse = async (userMessage: string): Promise<string> => {
    const message = userMessage.toLowerCase();

    // İslami konular
    if (message.includes("dua") || message.includes("prayer")) {
      return "Dua konusunda size yardımcı olabilirim. Platformumuzda günlük dualar, özel durumlar için dualar ve dua öğrenme bölümleri bulunmaktadır. Hangi konuda dua arıyorsunuz? Sabah duaları, akşam duaları, sıkıntı duası veya başka bir konu mu?";
    }

    if (message.includes("zikir") || message.includes("dhikr")) {
      return "Zikir, kalbin Allah ile bağlantısını güçlendiren en güzel ibadetlerden biridir. Platformumuzda interaktif zikir sayacı, zamanlayıcı ve farklı zikir türleri bulunmaktadır. Hangi zikri yapmak istiyorsunuz? Subhanallah, Alhamdulillah, Allahu Akbar zikirleri en temel zikirlerdir.";
    }

    if (message.includes("seviye") || message.includes("nefs")) {
      return "Nefs mertebeleri sistemimiz 7 seviyeden oluşur: 1-Nefs-i Emmare, 2-Nefs-i Levvame, 3-Nefs-i Mülhime, 4-Nefs-i Mutmaine, 5-Nefs-i Raziye, 6-Nefs-i Marziyye, 7-Nefs-i Kâmile. Şu anda hangi seviyedesiniz? Her seviye farklı manevi özellikler ve MLM avantajları sunar.";
    }

    if (
      message.includes("mlm") ||
      message.includes("network") ||
      message.includes("kazanç")
    ) {
      return "MLM sistemimiz 7 seviyeli binary yapıda çalışır. Her yeni üye getirdiğinizde komisyon kazanırsınız. Ayrıca ekibinizdeki aktif üyelerden de gelir elde edersiniz. Aylık $10 veya yıllık $100 üyelikle başlayabilirsiniz. Daha detaylı bilgi almak ister misiniz?";
    }

    if (
      message.includes("üyelik") ||
      message.includes("ödeme") ||
      message.includes("abonelik")
    ) {
      return "Üyelik türlerimiz: Aylık $10, Yıllık $100 (% 17 tasarruf). Üye olarak tüm premium içeriklere erişim, MLM sistemine katılım, özel eğitimler ve kişisel mentörlük hizmetlerinden faydalanırsınız. Hangi üyelik türü hakkında bilgi almak istiyorsunuz?";
    }

    if (message.includes("yaşam koçluğu") || message.includes("coaching")) {
      return "Yaşam koçluğu hizmetlerimiz İslami değerlerle harmanlanmıştır. Kişisel gelişim, kariyer danışmanlığı, aile danışmanlığı, finansal planlama gibi alanlarda uzman koçlarımızla çalışabilirsiniz. Hangi alanda destek almak istiyorsunuz?";
    }

    if (message.includes("meditasyon") || message.includes("meditation")) {
      return "İslami meditasyon ve tefekkür pratiklerimiz, modern mindfulness teknikleriyle birleştirilmiştir. Nefes teknikleri, zikir meditasyonu, sabah-akşam programları mevcuttur. Günde sadece 10-20 dakika ayırarak manevi huzurunuzu artırabilirsiniz.";
    }

    // Platform kullanımı
    if (message.includes("nasıl") && message.includes("başla")) {
      return "Platforma başlamak çok kolay! 1) Önce kayıt olun, 2) Üyeliğinizi aktifleştirin ($10/ay), 3) Dashboard'unuzdan daily görevlerinizi takip edin, 4) Zikir ve dua pratiklerinizi yapın, 5) MLM sistemiyle ekip oluşturun. Hangi adımda yardım istiyorsunuz?";
    }

    if (message.includes("ürün") || message.includes("satın")) {
      return "Manevi ürünler mağazamızda İslami kitaplar, ses kayıtları, dua seccadeleri, tesbihler ve dijital içerikler bulunur. Üyeler özel indirimlerden yararlanır. Hangi tür ürün arıyorsunuz?";
    }

    // Genel sorular
    if (message.includes("merhaba") || message.includes("selam")) {
      return "Aleykümselam ve merhaba! Size nasıl yardımcı olabilirim? İslami konularda, manevi gelişim hakkında veya platform kullanımıyla ilgili sorularınız varsa çekinmeden sorabilirsiniz.";
    }

    if (message.includes("teşekkür")) {
      return "Rica ederim! Size yardımcı olabildiysem ne mutlu bana. Başka sorularınız olursa her zaman buradayım. Manevi yolculuğunuzda Allah kolaylıklar versin. 🤲";
    }

    // Varsayılan cevap
    const defaultResponses = [
      "Bu konuda size yardımcı olmaya çalışayım. Lütfen sorunuzu biraz daha detaylandırabilir misiniz? Böylece size daha spesifik bilgiler verebilirim.",
      "İlginç bir soru! Bu konuda platformumuzun farklı bölümlerinden bilgiler bulabilirsiniz. Hangi alanda daha detaylı bilgi istiyorsunuz?",
      "Bu konu hakkında size yardımcı olabilmek için biraz daha açıklama yapabilir misiniz? İslami konular, manevi gelişim veya platform kullanımı ile ilgili mi?",
      "Sorunuzu anlayabilmek için biraz daha detay verebilir misiniz? Size en doğru bilgiyi vermek istiyorum.",
    ];

    return defaultResponses[
      Math.floor(Math.random() * defaultResponses.length)
    ];
  };

  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      type: "user",
      content: inputMessage,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(async () => {
      const aiResponse = await getAiResponse(inputMessage);
      const aiMessage: Message = {
        id: Date.now() + 1,
        type: "ai",
        content: aiResponse,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: 1,
        type: "ai",
        content:
          "Merhaba! Ben Manevi Rehberim AI asistanıyım. Size nasıl yardımcı olabilirim?",
        timestamp: new Date(),
      },
    ]);
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("tr-TR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Card className="cursor-pointer hover:shadow-lg transition-all duration-300 bg-gradient-to-r from-purple-50 to-blue-50 border-2 border-purple-200">
          <CardContent className="p-6 text-center">
            <div className="mb-4">
              <div className="w-16 h-16 mx-auto bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mb-3">
                <Sparkles className="w-8 h-8 text-white animate-pulse" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">
                AI Manevi Rehber
              </h3>
              <p className="text-sm text-gray-600">
                İslami sorularınız için yapay zeka asistanı
              </p>
            </div>
            <Badge className="bg-purple-100 text-purple-700 animate-bounce">
              <Bot className="w-3 h-3 mr-1" />
              Sohbet Başlat
            </Badge>
          </CardContent>
        </Card>
      </DialogTrigger>

      <DialogContent className="max-w-4xl h-[80vh] p-0">
        <DialogHeader className="p-6 pb-3 border-b">
          <DialogTitle className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span>AI Manevi Rehber</span>
            <Badge className="bg-green-100 text-green-700">Çevrimiçi</Badge>
          </DialogTitle>
          <DialogDescription>
            İslami konularda, manevi gelişim ve platform kullanımında size
            yardımcı olacak AI asistanı
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col h-full">
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] ${
                    message.type === "user"
                      ? "bg-spiritual-gradient text-white"
                      : "bg-gray-100 text-gray-800"
                  } rounded-2xl px-4 py-3 relative group`}
                >
                  <div className="flex items-start space-x-2">
                    {message.type === "ai" && (
                      <Bot className="w-4 h-4 mt-1 text-purple-600" />
                    )}
                    {message.type === "user" && (
                      <User className="w-4 h-4 mt-1 text-white" />
                    )}
                    <div className="flex-1">
                      <p className="text-sm leading-relaxed">
                        {message.content}
                      </p>
                      <span
                        className={`text-xs mt-2 block ${
                          message.type === "user"
                            ? "text-white/70"
                            : "text-gray-500"
                        }`}
                      >
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                  </div>

                  {/* Message Actions */}
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyMessage(message.content)}
                      className="h-6 w-6 p-0 text-gray-500 hover:text-gray-700"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-2xl px-4 py-3 flex items-center space-x-2">
                  <Bot className="w-4 h-4 text-purple-600" />
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200"></div>
                  </div>
                  <span className="text-sm text-gray-600">Yazıyor...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <div className="border-t p-4">
            <div className="flex items-center space-x-2 mb-2">
              <Button
                variant="outline"
                size="sm"
                onClick={clearChat}
                className="text-gray-600"
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Temizle
              </Button>
              <div className="flex-1"></div>
              <Badge variant="outline" className="text-xs">
                Ücretsiz AI Asistan
              </Badge>
            </div>
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Sorunuzu yazın... (örn: 'Sabah duası nedir?' veya 'MLM nasıl çalışır?')"
                className="flex-1"
                disabled={isTyping}
              />
              <Button
                onClick={sendMessage}
                disabled={!inputMessage.trim() || isTyping}
                className="bg-spiritual-gradient text-white"
              >
                {isTyping ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
            <div className="text-xs text-gray-500 mt-2 text-center">
              AI asistan tarafından sağlanan bilgiler genel nitelikli olup,
              kişisel dini danışmanlık yerine geçmez.
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AiChat;
