// Enhanced MLM System with Hybrid Binary Architecture
// Based on modern MLM best practices from research

export interface EnhancedNetworkMember {
  id: string;
  name: string;
  email: string;
  sponsorId?: string;
  referralCode: string;
  level: number;
  nefsLevel: number; // 1-7 Islamic spiritual levels
  joinDate: Date;
  isActive: boolean;
  subscriptionType: "monthly" | "yearly" | null;
  subscriptionExpiry: Date | null;

  // Financial data
  personalSales: number;
  teamSales: number;
  totalEarnings: number;
  monthlyCommission: number;

  // Network structure - Hybrid Binary
  leftLeg: EnhancedNetworkMember[];
  rightLeg: EnhancedNetworkMember[];
  unilevelChildren: EnhancedNetworkMember[]; // Direct referrals
  matrixPosition: { x: number; y: number };

  // Performance metrics
  teamSize: number;
  activeTeamSize: number;
  monthlyPV: number; // Personal Volume
  monthlyGV: number; // Group Volume

  // Achievements and status
  achievements: string[];
  rank: string;
  qualifiedForBonus: boolean;
  lastActivity: Date;

  // Clone page data
  hasClonePage: boolean;
  clonePageUrl: string;
  clonePageViews: number;
  clonePageConversions: number;
}

export interface CommissionCalculation {
  memberId: string;
  type: "sponsor" | "binary" | "unilevel" | "matrix" | "rank" | "special";
  amount: number;
  sourceTransaction: string;
  level: number;
  percentage: number;
  date: Date;
  status: "pending" | "paid" | "cancelled";
  description: string;
}

export interface HybridMLMSettings {
  // Commission rates by level
  sponsorCommissions: number[]; // [10, 8, 6, 4, 3, 2, 1] for levels 1-7
  binaryMatchingBonus: number; // 5%
  unilevelCommissions: number[]; // [15, 10, 8, 5, 3, 2, 1] for levels 1-7
  matrixCommissions: number[]; // [20, 15, 10, 5] for 4x4 matrix

  // Volume requirements
  personalVolumeRequirement: number; // $100/month
  teamVolumeRequirement: number; // $500/month

  // Subscription fees
  monthlyFee: number; // $10
  yearlyFee: number; // $100

  // System limits
  maxDepth: number; // 7
  maxWidth: number; // Unlimited for unilevel
  matrixSize: { width: number; height: number }; // 4x4

  // Bonus qualifications
  minActiveMembers: number; // 3 direct actives
  minMonthlyVolume: number; // $300

  // Rank advancement
  rankRequirements: {
    [key: string]: {
      teamSize: number;
      monthlyVolume: number;
      directActives: number;
      nefsLevel: number;
    };
  };
}

export const DEFAULT_HYBRID_SETTINGS: HybridMLMSettings = {
  sponsorCommissions: [10, 8, 6, 4, 3, 2, 1],
  binaryMatchingBonus: 5,
  unilevelCommissions: [15, 10, 8, 5, 3, 2, 1],
  matrixCommissions: [20, 15, 10, 5],

  personalVolumeRequirement: 100,
  teamVolumeRequirement: 500,

  monthlyFee: 10,
  yearlyFee: 100,

  maxDepth: 7,
  maxWidth: -1, // Unlimited
  matrixSize: { width: 4, height: 4 },

  minActiveMembers: 3,
  minMonthlyVolume: 300,

  rankRequirements: {
    "Nefs-i Emmare": {
      teamSize: 0,
      monthlyVolume: 0,
      directActives: 0,
      nefsLevel: 1,
    },
    "Nefs-i Levvame": {
      teamSize: 3,
      monthlyVolume: 1000,
      directActives: 2,
      nefsLevel: 2,
    },
    "Nefs-i Mülhime": {
      teamSize: 10,
      monthlyVolume: 3000,
      directActives: 3,
      nefsLevel: 3,
    },
    "Nefs-i Mutmainne": {
      teamSize: 25,
      monthlyVolume: 6000,
      directActives: 4,
      nefsLevel: 4,
    },
    "Nefs-i Râziye": {
      teamSize: 50,
      monthlyVolume: 12500,
      directActives: 5,
      nefsLevel: 5,
    },
    "Nefs-i Mardiyye": {
      teamSize: 100,
      monthlyVolume: 25000,
      directActives: 6,
      nefsLevel: 6,
    },
    "Nefs-i Kâmile": {
      teamSize: 250,
      monthlyVolume: 50000,
      directActives: 8,
      nefsLevel: 7,
    },
  },
};

export class HybridMLMSystem {
  private members: Map<string, EnhancedNetworkMember> = new Map();
  private commissions: CommissionCalculation[] = [];
  private settings: HybridMLMSettings;
  private weakestUplineCache: string | null = null;

  constructor(settings: HybridMLMSettings = DEFAULT_HYBRID_SETTINGS) {
    this.settings = settings;
  }

  // Enhanced member management
  addMember(memberData: Partial<EnhancedNetworkMember>): EnhancedNetworkMember {
    const newMember: EnhancedNetworkMember = {
      id: memberData.id || Date.now().toString(),
      name: memberData.name || "",
      email: memberData.email || "",
      sponsorId: memberData.sponsorId,
      referralCode: memberData.referralCode || `REF${Date.now()}`,
      level: 1,
      nefsLevel: 1,
      joinDate: new Date(),
      isActive: false,
      subscriptionType: null,
      subscriptionExpiry: null,

      personalSales: 0,
      teamSales: 0,
      totalEarnings: 0,
      monthlyCommission: 0,

      leftLeg: [],
      rightLeg: [],
      unilevelChildren: [],
      matrixPosition: { x: 0, y: 0 },

      teamSize: 0,
      activeTeamSize: 0,
      monthlyPV: 0,
      monthlyGV: 0,

      achievements: [],
      rank: "Nefs-i Emmare",
      qualifiedForBonus: false,
      lastActivity: new Date(),

      hasClonePage: true,
      clonePageUrl: `${window.location.origin}/clone/${memberData.referralCode || `REF${Date.now()}`}`,
      clonePageViews: 0,
      clonePageConversions: 0,

      ...memberData,
    };

    this.members.set(newMember.id, newMember);

    // Add to sponsor's network using hybrid placement
    if (newMember.sponsorId) {
      this.addToSponsorNetwork(newMember);
    } else {
      // Find weakest upline for spillover placement
      const weakestUpline = this.findWeakestUpline();
      if (weakestUpline) {
        newMember.sponsorId = weakestUpline;
        this.addToSponsorNetwork(newMember);
      }
    }

    return newMember;
  }

  private addToSponsorNetwork(member: EnhancedNetworkMember): void {
    if (!member.sponsorId) return;

    const sponsor = this.members.get(member.sponsorId);
    if (!sponsor) return;

    // Add to unilevel (direct referrals)
    sponsor.unilevelChildren.push(member);

    // Binary placement - balanced left/right
    if (sponsor.leftLeg.length <= sponsor.rightLeg.length) {
      sponsor.leftLeg.push(member);
    } else {
      sponsor.rightLeg.push(member);
    }

    // Matrix placement (4x4)
    this.placeInMatrix(member, sponsor);

    // Update team sizes
    this.updateTeamMetrics(sponsor.id);
  }

  private placeInMatrix(
    member: EnhancedNetworkMember,
    sponsor: EnhancedNetworkMember,
  ): void {
    // Find next available position in 4x4 matrix
    for (let y = 0; y < this.settings.matrixSize.height; y++) {
      for (let x = 0; x < this.settings.matrixSize.width; x++) {
        if (!this.isMatrixPositionOccupied(sponsor.id, x, y)) {
          member.matrixPosition = { x, y };
          return;
        }
      }
    }
  }

  private isMatrixPositionOccupied(
    sponsorId: string,
    x: number,
    y: number,
  ): boolean {
    // Check if matrix position is occupied
    const members = Array.from(this.members.values());
    return members.some(
      (m) =>
        m.sponsorId === sponsorId &&
        m.matrixPosition.x === x &&
        m.matrixPosition.y === y,
    );
  }

  // Enhanced commission calculation
  processTransaction(
    memberId: string,
    amount: number,
    transactionType: string,
  ): void {
    const member = this.members.get(memberId);
    if (!member) return;

    // Update member's personal volume
    member.monthlyPV += amount;
    member.personalSales += amount;

    // Calculate various commission types
    this.calculateSponsorCommissions(memberId, amount, transactionType);
    this.calculateBinaryCommissions(memberId, amount, transactionType);
    this.calculateUnilevelCommissions(memberId, amount, transactionType);
    this.calculateMatrixCommissions(memberId, amount, transactionType);

    // Update team metrics
    this.updateTeamMetrics(memberId);

    // Check for rank advancement
    this.checkRankAdvancement(memberId);
  }

  private calculateSponsorCommissions(
    memberId: string,
    amount: number,
    transactionType: string,
  ): void {
    const member = this.members.get(memberId);
    if (!member || !member.sponsorId) return;

    let currentSponsorId = member.sponsorId;
    let level = 0;

    while (currentSponsorId && level < this.settings.maxDepth) {
      const sponsor = this.members.get(currentSponsorId);
      if (!sponsor || !sponsor.isActive) break;

      const commissionRate = this.settings.sponsorCommissions[level] || 0;
      const commissionAmount = (amount * commissionRate) / 100;

      if (
        commissionAmount > 0 &&
        this.isQualifiedForCommission(sponsor, level)
      ) {
        this.addCommission({
          memberId: sponsor.id,
          type: "sponsor",
          amount: commissionAmount,
          sourceTransaction: transactionType,
          level: level + 1,
          percentage: commissionRate,
          date: new Date(),
          status: "pending",
          description: `Level ${level + 1} sponsor commission from ${member.name}`,
        });

        sponsor.totalEarnings += commissionAmount;
        sponsor.monthlyCommission += commissionAmount;
      }

      currentSponsorId = sponsor.sponsorId;
      level++;
    }
  }

  private calculateBinaryCommissions(
    memberId: string,
    amount: number,
    transactionType: string,
  ): void {
    const member = this.members.get(memberId);
    if (!member || !member.sponsorId) return;

    const sponsor = this.members.get(member.sponsorId);
    if (!sponsor || !sponsor.isActive) return;

    // Calculate binary matching bonus
    const leftVolume = this.calculateLegVolume(sponsor.leftLeg);
    const rightVolume = this.calculateLegVolume(sponsor.rightLeg);
    const matchingVolume = Math.min(leftVolume, rightVolume);

    if (matchingVolume > 0 && this.isQualifiedForCommission(sponsor, 0)) {
      const bonusAmount =
        (matchingVolume * this.settings.binaryMatchingBonus) / 100;

      this.addCommission({
        memberId: sponsor.id,
        type: "binary",
        amount: bonusAmount,
        sourceTransaction: transactionType,
        level: 1,
        percentage: this.settings.binaryMatchingBonus,
        date: new Date(),
        status: "pending",
        description: `Binary matching bonus - Left: $${leftVolume}, Right: $${rightVolume}`,
      });

      sponsor.totalEarnings += bonusAmount;
      sponsor.monthlyCommission += bonusAmount;
    }
  }

  private calculateUnilevelCommissions(
    memberId: string,
    amount: number,
    transactionType: string,
  ): void {
    const member = this.members.get(memberId);
    if (!member || !member.sponsorId) return;

    let currentSponsorId = member.sponsorId;
    let level = 0;

    while (currentSponsorId && level < this.settings.maxDepth) {
      const sponsor = this.members.get(currentSponsorId);
      if (!sponsor || !sponsor.isActive) break;

      const commissionRate = this.settings.unilevelCommissions[level] || 0;
      const commissionAmount = (amount * commissionRate) / 100;

      if (
        commissionAmount > 0 &&
        this.isQualifiedForCommission(sponsor, level)
      ) {
        this.addCommission({
          memberId: sponsor.id,
          type: "unilevel",
          amount: commissionAmount,
          sourceTransaction: transactionType,
          level: level + 1,
          percentage: commissionRate,
          date: new Date(),
          status: "pending",
          description: `Unilevel commission level ${level + 1} from ${member.name}`,
        });

        sponsor.totalEarnings += commissionAmount;
        sponsor.monthlyCommission += commissionAmount;
      }

      currentSponsorId = sponsor.sponsorId;
      level++;
    }
  }

  private calculateMatrixCommissions(
    memberId: string,
    amount: number,
    transactionType: string,
  ): void {
    const member = this.members.get(memberId);
    if (!member || !member.sponsorId) return;

    // Calculate matrix commissions based on position
    const matrixLevel = member.matrixPosition.y;
    if (matrixLevel < this.settings.matrixCommissions.length) {
      const commissionRate = this.settings.matrixCommissions[matrixLevel];
      const commissionAmount = (amount * commissionRate) / 100;

      const sponsor = this.members.get(member.sponsorId);
      if (
        sponsor &&
        sponsor.isActive &&
        this.isQualifiedForCommission(sponsor, matrixLevel)
      ) {
        this.addCommission({
          memberId: sponsor.id,
          type: "matrix",
          amount: commissionAmount,
          sourceTransaction: transactionType,
          level: matrixLevel + 1,
          percentage: commissionRate,
          date: new Date(),
          status: "pending",
          description: `Matrix commission from position (${member.matrixPosition.x}, ${member.matrixPosition.y})`,
        });

        sponsor.totalEarnings += commissionAmount;
        sponsor.monthlyCommission += commissionAmount;
      }
    }
  }

  private isQualifiedForCommission(
    member: EnhancedNetworkMember,
    level: number,
  ): boolean {
    // Check if member meets qualification criteria
    return (
      member.isActive &&
      member.monthlyPV >= this.settings.personalVolumeRequirement &&
      member.monthlyGV >= this.settings.teamVolumeRequirement &&
      member.activeTeamSize >= this.settings.minActiveMembers
    );
  }

  private calculateLegVolume(leg: EnhancedNetworkMember[]): number {
    return leg.reduce((total, member) => {
      return (
        total +
        member.monthlyPV +
        this.calculateLegVolume([...member.leftLeg, ...member.rightLeg])
      );
    }, 0);
  }

  private updateTeamMetrics(memberId: string): void {
    const member = this.members.get(memberId);
    if (!member) return;

    // Calculate team size and volumes
    member.teamSize = this.calculateTeamSize(member);
    member.activeTeamSize = this.calculateActiveTeamSize(member);
    member.monthlyGV = this.calculateGroupVolume(member);

    // Update qualification status
    member.qualifiedForBonus = this.isQualifiedForCommission(member, 0);

    // Recursively update upline
    if (member.sponsorId) {
      this.updateTeamMetrics(member.sponsorId);
    }
  }

  private calculateTeamSize(member: EnhancedNetworkMember): number {
    const countTeam = (m: EnhancedNetworkMember): number => {
      return (
        m.unilevelChildren.length +
        m.unilevelChildren.reduce((sum, child) => sum + countTeam(child), 0)
      );
    };
    return countTeam(member);
  }

  private calculateActiveTeamSize(member: EnhancedNetworkMember): number {
    const countActiveTeam = (m: EnhancedNetworkMember): number => {
      const activeChildren = m.unilevelChildren.filter(
        (child) => child.isActive,
      );
      return (
        activeChildren.length +
        activeChildren.reduce((sum, child) => sum + countActiveTeam(child), 0)
      );
    };
    return countActiveTeam(member);
  }

  private calculateGroupVolume(member: EnhancedNetworkMember): number {
    const calculateVolume = (m: EnhancedNetworkMember): number => {
      return (
        m.monthlyPV +
        m.unilevelChildren.reduce(
          (sum, child) => sum + calculateVolume(child),
          0,
        )
      );
    };
    return calculateVolume(member);
  }

  private checkRankAdvancement(memberId: string): void {
    const member = this.members.get(memberId);
    if (!member) return;

    for (const [rank, requirements] of Object.entries(
      this.settings.rankRequirements,
    )) {
      if (
        member.teamSize >= requirements.teamSize &&
        member.monthlyGV >= requirements.monthlyVolume &&
        member.activeTeamSize >= requirements.directActives &&
        member.nefsLevel >= requirements.nefsLevel
      ) {
        if (member.rank !== rank) {
          member.rank = rank;
          member.nefsLevel = requirements.nefsLevel;
          member.achievements.push(`Rank advancement to ${rank}`);
        }
      }
    }
  }

  private findWeakestUpline(): string | null {
    if (this.weakestUplineCache) {
      const cached = this.members.get(this.weakestUplineCache);
      if (cached && cached.isActive && cached.teamSize < 100) {
        return this.weakestUplineCache;
      }
    }

    let weakestMember: EnhancedNetworkMember | null = null;
    let smallestTeam = Infinity;

    this.members.forEach((member) => {
      if (member.isActive && member.teamSize < smallestTeam) {
        smallestTeam = member.teamSize;
        weakestMember = member;
      }
    });

    this.weakestUplineCache = weakestMember?.id || null;
    return this.weakestUplineCache;
  }

  private addCommission(commission: Omit<CommissionCalculation, "id">): void {
    const newCommission: CommissionCalculation = {
      ...commission,
    };
    this.commissions.push(newCommission);
  }

  // Public methods for external access
  public getMember(memberId: string): EnhancedNetworkMember | undefined {
    return this.members.get(memberId);
  }

  public getTeamNetwork(memberId: string): EnhancedNetworkMember | null {
    return this.members.get(memberId) || null;
  }

  public getMemberCommissions(memberId: string): CommissionCalculation[] {
    return this.commissions.filter((c) => c.memberId === memberId);
  }

  public updateMemberSubscription(
    memberId: string,
    type: "monthly" | "yearly",
  ): void {
    const member = this.members.get(memberId);
    if (member) {
      member.isActive = true;
      member.subscriptionType = type;
      member.subscriptionExpiry =
        type === "monthly"
          ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);

      // Process subscription payment as transaction
      const subscriptionAmount =
        type === "monthly" ? this.settings.monthlyFee : this.settings.yearlyFee;

      this.processTransaction(
        memberId,
        subscriptionAmount,
        "Subscription Payment",
      );
    }
  }

  public generateClonePageUrl(memberId: string): string {
    const member = this.members.get(memberId);
    return member?.clonePageUrl || "";
  }

  public trackClonePageView(referralCode: string): void {
    const member = Array.from(this.members.values()).find(
      (m) => m.referralCode === referralCode,
    );

    if (member) {
      member.clonePageViews++;
    }
  }

  public trackClonePageConversion(referralCode: string): void {
    const member = Array.from(this.members.values()).find(
      (m) => m.referralCode === referralCode,
    );

    if (member) {
      member.clonePageConversions++;
    }
  }

  public getSystemStats(): {
    totalMembers: number;
    activeMembers: number;
    totalCommissions: number;
    monthlyVolume: number;
  } {
    const members = Array.from(this.members.values());

    return {
      totalMembers: members.length,
      activeMembers: members.filter((m) => m.isActive).length,
      totalCommissions: this.commissions.reduce((sum, c) => sum + c.amount, 0),
      monthlyVolume: members.reduce((sum, m) => sum + m.monthlyPV, 0),
    };
  }

  public exportSystemData(): any {
    return {
      members: Array.from(this.members.values()),
      commissions: this.commissions,
      settings: this.settings,
      stats: this.getSystemStats(),
      exportDate: new Date().toISOString(),
    };
  }
}

// Global enhanced MLM instance
export const enhancedMLMSystem = new HybridMLMSystem();
