import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/contexts/AuthContext";
import { NEFS_LEVELS } from "@/lib/spiritual";
import {
  User,
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  Share,
  Download,
  MessageSquare,
  Star,
  Crown,
  Copy,
  Check,
  AlertCircle,
} from "lucide-react";

const UserDashboard = () => {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [copiedLink, setCopiedLink] = useState(false);

  if (!user) {
    navigate("/giriş");
    return null;
  }

  const currentLevel = NEFS_LEVELS.find((level) => level.id === user.level);
  const nextLevel = NEFS_LEVELS.find((level) => level.id === user.level + 1);

  const referralLink = `${window.location.origin}/kayıt?sponsor=${user.referralCode}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (err) {
      console.error("Link kopyalanamadı:", err);
    }
  };

  const handleActivateSubscription = (type: "monthly" | "yearly") => {
    updateUser({
      isActive: true,
      subscriptionType: type,
      subscriptionExpiry:
        type === "monthly"
          ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          : new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
    });
  };

  const stats = [
    {
      title: "Toplam Kazanç",
      value: `$${user.totalEarnings.toFixed(2)}`,
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "Ekip Büyüklüğü",
      value: user.teamSize.toString(),
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "Mevcut Seviye",
      value: `${user.level}/7`,
      icon: Crown,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
    {
      title: "Üyelik Durumu",
      value: user.isActive ? "Aktif" : "Beklemede",
      icon: Star,
      color: user.isActive ? "text-green-600" : "text-orange-600",
      bgColor: user.isActive ? "bg-green-50" : "bg-orange-50",
    },
  ];

  return (
    <div className="min-h-screen bg-peaceful-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-spiritual-gradient rounded-full flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Hoş geldin, {user.name}!
              </h1>
              <p className="text-gray-600">
                {currentLevel?.emoji} {currentLevel?.name} seviyesindesin
              </p>
            </div>
          </div>

          {/* Subscription Alert */}
          {!user.isActive && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
              <div className="flex items-center space-x-2 text-orange-700 mb-2">
                <AlertCircle className="w-5 h-5" />
                <h3 className="font-medium">Aboneliğinizi Aktifleştirin</h3>
              </div>
              <p className="text-orange-600 text-sm mb-4">
                Tüm özelliklere erişmek için aylık veya yıllık abonelik
                planlarından birini seçin.
              </p>
              <div className="flex space-x-3">
                <Button
                  onClick={() => handleActivateSubscription("monthly")}
                  size="sm"
                  className="bg-orange-600 text-white hover:bg-orange-700"
                >
                  Aylık $10
                </Button>
                <Button
                  onClick={() => handleActivateSubscription("yearly")}
                  size="sm"
                  className="bg-spiritual-gradient text-white"
                >
                  Yıllık $100 (%17 indirim)
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
            <TabsTrigger value="overview">Genel Bakış</TabsTrigger>
            <TabsTrigger value="referral">Referans</TabsTrigger>
            <TabsTrigger value="earnings">Kazançlar</TabsTrigger>
            <TabsTrigger value="tools">Araçlar</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Current Level Info */}
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Crown className="w-6 h-6 text-spiritual-purple-600" />
                    <span>Mevcut Seviyeniz</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {currentLevel && (
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-4xl mb-2">
                          {currentLevel.emoji}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">
                          {currentLevel.name}
                        </h3>
                        <p className="text-gray-600 text-sm mt-2">
                          {currentLevel.description}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-medium text-gray-900">
                          Seviye Avantajları:
                        </h4>
                        <ul className="space-y-1">
                          {currentLevel.benefits.map((benefit, index) => (
                            <li
                              key={index}
                              className="flex items-center space-x-2 text-sm text-gray-600"
                            >
                              <div className="w-1.5 h-1.5 bg-spiritual-turquoise-500 rounded-full" />
                              <span>{benefit}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Next Level */}
              {nextLevel && (
                <Card className="bg-white/80 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <TrendingUp className="w-6 h-6 text-spiritual-gold-600" />
                      <span>Bir Sonraki Seviye</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-4xl mb-2">{nextLevel.emoji}</div>
                        <h3 className="text-xl font-bold text-gray-900">
                          {nextLevel.name}
                        </h3>
                        <p className="text-gray-600 text-sm mt-2">
                          {nextLevel.description}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-medium text-gray-900">
                          Gereksinimler:
                        </h4>
                        <p className="text-sm text-gray-600">
                          {nextLevel.requirements}
                        </p>
                      </div>

                      <Button
                        onClick={() => navigate("/network")}
                        className="w-full bg-spiritual-gradient text-white"
                      >
                        Seviye Atlama Rehberi
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="referral" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Share className="w-6 h-6 text-spiritual-turquoise-600" />
                  <span>Referans Linkiniz</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">
                    Özel Referans Linkiniz:
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={referralLink}
                      readOnly
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                    <Button
                      onClick={handleCopyLink}
                      variant="outline"
                      size="sm"
                      className="flex items-center space-x-1"
                    >
                      {copiedLink ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                      <span>{copiedLink ? "Kopyalandı" : "Kopyala"}</span>
                    </Button>
                  </div>
                </div>

                <div className="bg-spiritual-turquoise-50 p-4 rounded-lg">
                  <h4 className="font-medium text-spiritual-turquoise-700 mb-2">
                    Referans Sistemi Nasıl Çalışır?
                  </h4>
                  <ul className="space-y-1 text-sm text-spiritual-turquoise-600">
                    <li>• Linkinizi paylaşın</li>
                    <li>• Yeni üyeler kaydolsun</li>
                    <li>• Her seviyeden komisyon kazanın</li>
                    <li>• Ekibiniz büyüdükçe seviye atlayın</li>
                  </ul>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-spiritual-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-spiritual-purple-700">
                      {user.teamSize}
                    </p>
                    <p className="text-sm text-spiritual-purple-600">
                      Toplam Ekip
                    </p>
                  </div>
                  <div className="text-center p-4 bg-spiritual-gold-50 rounded-lg">
                    <p className="text-2xl font-bold text-spiritual-gold-700">
                      ${user.totalEarnings.toFixed(0)}
                    </p>
                    <p className="text-sm text-spiritual-gold-600">
                      Referans Geliri
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="earnings" className="space-y-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <DollarSign className="w-6 h-6 text-green-600" />
                  <span>Kazanç Detayları</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-700">
                        ${(user.totalEarnings * 0.6).toFixed(2)}
                      </p>
                      <p className="text-sm text-green-600">
                        Sponsor Komisyonu
                      </p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-700">
                        ${(user.totalEarnings * 0.25).toFixed(2)}
                      </p>
                      <p className="text-sm text-blue-600">Eşleşme Bonusu</p>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <p className="text-2xl font-bold text-purple-700">
                        ${(user.totalEarnings * 0.15).toFixed(2)}
                      </p>
                      <p className="text-sm text-purple-600">Satış Primi</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-2">
                      Son Kazançlar
                    </h4>
                    <div className="space-y-2 text-sm text-gray-600">
                      <p>• Henüz kazanç kaydı bulunmuyor</p>
                      <p>• Ekip oluşturmaya başlayın</p>
                      <p>• İlk kazancınız otomatik olarak burada görünecek</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="tools" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Download className="w-6 h-6 text-spiritual-turquoise-600" />
                    <span>Dökümanlar</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    MLM Rehberi İndir
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Pazarlama Materyalleri
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    disabled={!user.isActive}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Eğitim Videoları
                  </Button>
                  {!user.isActive && (
                    <p className="text-xs text-gray-500">
                      Abonelik aktivasyonu sonrası erişilebilir
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="w-6 h-6 text-spiritual-purple-600" />
                    <span>AI Sohbet</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-gray-600">
                    Yapay zeka destekli rehberlik sistemi
                  </p>
                  <Button
                    className="w-full bg-spiritual-gradient text-white"
                    disabled={!user.isActive}
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    AI Rehber ile Sohbet Et
                  </Button>
                  {!user.isActive && (
                    <p className="text-xs text-gray-500">
                      Abonelik aktivasyonu sonrası erişilebilir
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UserDashboard;
